--- Page 1 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 16-Oct-2023
12-Oct-2023 10:37:50 AM
This document is provided by Computershare Trust Company, N.A., or one or more of its affiliates (collectively, "Computershare"), in its named capacity or as agent of or successor to Wells Fargo Bank, N.A., or
one or more of its affiliates ("Wells Fargo"), by virtue of the acquisition by Computershare of substantially all the assets of the corporate trust services business of Wells Fargo. This report is compiled by
Computershare Trust Company, N.A. from information provided by third parties. Computershare Trust Company, N.A. has not independently confirmed the accuracy of the information.
Effective March 1, 2023 our Computershare Corporate Trust office located at 600 S 4th Street Minneapolis, MN 55415 has moved and our new address is 1505 Energy Park Drive St. Paul, Minnesota 55108. Please
update your records to reflect the new address.
All Record Dates are based upon the governing documents and logic set forth as of closing.
© 2021 Computershare. All rights reserved. Confidential. Page 1 of 43

Stanwich Mortgage Loan Trust
Asset Backed Pass-Through Certificates
Series 2020-11

| Certificateholder Distribution Summary |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Class | CUSIP | Record Date | Certificate Pass- Through Rate | Beginning Certificate Balance | Interest Distribution | Principal Distribution | Current Realized Loss/Write Down | Ending Certificate Balance | Total Distribution | Cumulative Realized Losses/Write Down |
| A | SM0057610093 | 09/29/2023 | 0.00000 % | 0.00 | 0.00 | 60,048.68 | 0.00 | 0.00 | 60,048.68 | 0.00 |
| B | SM0057610095 | 09/29/2023 | 0.00000 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| Totals |  |  |  | 0.00 | 0.00 | 60,048.68 | 0.00 | 0.00 | 60,048.68 | 0.00 |

--- Page 2 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 16-Oct-2023
12-Oct-2023 10:37:50 AM
(1) Amount also includes Coupon Cap or Basis Risk Shortfalls, if applicable.
© 2021 Computershare. All rights reserved. Confidential. Page 3 of 43

Stanwich Mortgage Loan Trust
Asset Backed Pass-Through Certificates
Series 2020-11

Interest Distribution Statement

| Class | Accrual Dates | Accrual Days | Current Certificate Rate | Beginning Certificate/Notional Balance | Current Accrued Interest | Payment of Unpaid Interest Shortfall(1) | Basis Risk Shortfall | Interest Shortfall | Non- Supported Interest Shortfall | Total Interest Distribution | Remaining Unpaid Interest Shortfall(1) | Ending Certificate/ Notional Balance |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| A | N/A | N/A | 0.00000 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| B | N/A | N/A | 0.00000 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| Totals |  |  |  |  | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |  |

--- Page 3 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 16-Oct-2023
12-Oct-2023 10:37:50 AM
(1) Amount also includes Coupon Cap or Basis Risk Shortfalls, if applicable.
NOTE: All classes per $1,000 denomination.
© 2021 Computershare. All rights reserved. Confidential. Page 4 of 43

Stanwich Mortgage Loan Trust
Asset Backed Pass-Through Certificates
Series 2020-11

Interest Distribution Factors Statement

| Class | Original Face Amount | Current Certificate Rate | Beginning Certificate/Notional Balance | Current Accrued Interest | Payment of Unpaid Interest Shortfall(1) | Basis Risk Shortfall | Interest Shortfall | Non- Supported Interest Shortfall | Total Interest Distribution | Remaining Unpaid Interest Shortfall(1) | Ending Certificate/ Notional Balance |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| A | 0.00 | 0.00000 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 |
| B | 0.00 | 0.00000 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 |

--- Page 4 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 16-Oct-2023
12-Oct-2023 10:37:50 AM
Certificateholder Account Statement
*Servicer Payees include: CARRINGTON MORTGAGE SERVICES, LLC
Servicer Advances are calculated as delinquent scheduled principal and interest.
© 2021 Computershare. All rights reserved. Confidential. Page 5 of 43

Stanwich Mortgage Loan Trust
Asset Backed Pass-Through Certificates
Series 2020-11

CERTIFICATE ACCOUNT
Beginning Balance 0.00 Deposits Payments of Interest and Principal (1,256.46) Reserve Funds and Credit Enhancements 0.00 Proceeds from Repurchased Loans 0.00 Servicer Advances 64,658.11 Gains & Subsequent Recoveries (Realized Losses) 0.00 Total Deposits 63,401.65 Withdrawals Reserve Funds and Credit Enhancements 0.00 Reimbursement for Servicer Advances (628.23) Total Administration Fees 3,981.20 Payment of Interest and Principal 60,048.68 Total Withdrawals (Pool Distribution Amount) 63,401.65 Ending Balance 0.00

PREPAYMENT/CURTAILMENT INTEREST SHORTFALL
Total Prepayment/Curtailment Interest Shortfall 0.00 Servicing Fee Support 0.00 Non-Supported Prepayment/Curtailment Interest Shortfall 0.00

| ADMINISTRATION FEES |  |  |
| --- | --- | --- |
| Gross Servicing Fee* 0.00 Class A Paying Agent Fee - Wells Fargo Bank, N.A. 2,700.00 Class A Servicing Fee - Carrington Mortgage Services 281.20 Class A Trustee Fee - Wilmington Savings Fund Society 1,000.00 Class B Paying Agent Fee - Wells Fargo Bank, N.A. 0.00 Class B Servicing Fee - Carrington Mortgage Services 0.00 Class B Trustee Fee - Wilmington Savings Fund Society 0.00 Supported Prepayment/Curtailment Interest Shortfall 0.00 |  |  |
| Total Administration Fees | 3,981.20 |  |

--- Page 5 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 16-Oct-2023
12-Oct-2023 10:37:50 AM
Collateral Statement
NOTE: The Collateral Balances shown are Trust Balances unless otherwise designated.
© 2021 Computershare. All rights reserved. Confidential. Page 6 of 43

Stanwich Mortgage Loan Trust
Asset Backed Pass-Through Certificates
Series 2020-11

| Group | Total |  |
| --- | --- | --- |
| Collateral Description | Mixed Fixed & Arm |  |
| Weighted Average Coupon Rate | 0.000000 |  |
| Weighted Average Net Rate | 0.000000 |  |
| Weighted Average Pass-Through Rate | 0.000000 |  |
| Weighted Average Remaining Term | 79 |  |
| Principal and Interest Constant | 60,825.08 |  |
| Beginning Loan Count | 2 |  |
| Loans Paid in Full | 0 |  |
| Ending Loan Count | 2 |  |
| Beginning Actual Balance | 168,725.64 |  |
| Actual Ending Collateral Balance | 107,900.56 |  |
| Scheduled Principal | 60,825.08 |  |
| Unscheduled Principal | 0.00 |  |
| Negative Amortized Principal | 0.00 |  |
| Interest Received | 0.00 |  |
| Actual Interest | 0.00 |  |
| Servicing Fees | 0.00 |  |
| Master Servicing Fees | 0.00 |  |
| Trustee Fee | 0.00 |  |
| Special Hazard Fee | 0.00 |  |
| Other Fee | 0.00 |  |
| Net Interest | 0.00 |  |
| Realized Loss Amount | 0.00 |  |
| Cumulative Realized Loss | (7,362,738.49) |  |
| Percentage of Cumulative Losses | (3.7344) |  |
| Special Servicing Fee | 0.00 |  |

--- Page 6 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 16-Oct-2023
12-Oct-2023 10:37:50 AM
Additional Reporting - Deal Level
© 2021 Computershare. All rights reserved. Confidential. Page 7 of 43

Stanwich Mortgage Loan Trust
Asset Backed Pass-Through Certificates
Series 2020-11

| Informational Reporting |  |
| --- | --- |
| Class A Available Distribution Amount | 60,048.68 |
| Class A Ending Principal Balance | 107,900.56 |
| Class A Principal Prepayments | 0.00 |
| Class A Extraordinary Trust Fund Expenses | 0.00 |
| Class A Paying Agent Fee Due | 1,350.00 |
| Class A Paying Agent Fee Shortfall | 0.00 |
| Class A Servicing Fee Due | 140.60 |
| Class A Servicing Fee Shortfall | 0.00 |
| Class A Trustee Fee Due | 500.00 |
| Class A Trustee Fee Shortfall | 0.00 |
| Class B Available Distribution Amount | 0.00 |
| Class B Ending Principal Balance | 0.00 |
| Class B Principal Prepayments | 0.00 |
| Class B Extraordinary Trust Fund Expenses | 0.00 |
| Class B Paying Agent Fee Due | 0.00 |
| Class B Paying Agent Fee Shortfall | 0.00 |
| Class B Servicing Fee Due | 0.00 |
| Class B Servicing Fee Shortfall | 0.00 |
| Class B Trustee Fee Due | 0.00 |
| Class B Trustee Fee Shortfall | 0.00 |

--- Page 7 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 16-Oct-2023
12-Oct-2023 10:37:50 AM
Delinquency Status
Please refer to CTSLink.com for a list of delinquency code descriptions.
Current Period Class A Insufficient Funds 0.00 Principal Balance of Contaminated Properties 0.00 Periodic Advance 64,658.11
© 2021 Computershare. All rights reserved. Confidential. Page 8 of 43

Stanwich Mortgage Loan Trust
Asset Backed Pass-Through Certificates
Series 2020-11

| DELINQUENT |  |  | BANKRUPTCY |  |  | FORECLOSURE |  |  | REO |  |  | TOTAL |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | No. of Loans | Actual Balance |  | No. of Loans | Actual Balance |  | No. of Loans | Actual Balance |  | No. of Loans | Actual Balance |  | No. of Loans | Actual Balance |
|  |  |  | 0-29 Days | 0 | 0.00 | 0-29 Days | 0 | 0.00 | 0-29 Days | 0 | 0.00 | 0-29 Days | 0 | 0.00 |
| 30 Days | 0 | 0.00 | 30 Days | 0 | 0.00 | 30 Days | 0 | 0.00 | 30 Days | 0 | 0.00 | 30 Days | 0 | 0.00 |
| 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 |
| 90 Days | 0 | 0.00 | 90 Days | 0 | 0.00 | 90 Days | 0 | 0.00 | 90 Days | 0 | 0.00 | 90 Days | 0 | 0.00 |
| 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 |
| 150 Days | 0 | 0.00 | 150 Days | 0 | 0.00 | 150 Days | 0 | 0.00 | 150 Days | 0 | 0.00 | 150 Days | 0 | 0.00 |
| 180+ Days | 1 | 7,500.00 | 180+ Days | 0 | 0.00 | 180+ Days | 1 | 100,400.56 | 180+ Days | 0 | 0.00 | 180+ Days | 2 | 107,900.56 |
| 1 7,500.00 |  |  | 0 0.00 |  |  | 1 100,400.56 |  |  | 0 0.00 |  |  | 2 107,900.56 |  |  |
|  |  |  | 0-29 Days | 0.000000 % | 0.000000 % | 0-29 Days | 0.000000 % | 0.000000 % | 0-29 Days | 0.000000 % | 0.000000 % | 0-29 Days | 0.000000 % | 0.000000 % |
| 30 Days | 0.000000 % | 0.000000 % | 30 Days | 0.000000 % | 0.000000 % | 30 Days | 0.000000 % | 0.000000 % | 30 Days | 0.000000 % | 0.000000 % | 30 Days | 0.000000 % | 0.000000 % |
| 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % |
| 90 Days | 0.000000 % | 0.000000 % | 90 Days | 0.000000 % | 0.000000 % | 90 Days | 0.000000 % | 0.000000 % | 90 Days | 0.000000 % | 0.000000 % | 90 Days | 0.000000 % | 0.000000 % |
| 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % |
| 150 Days | 0.000000 % | 0.000000 % | 150 Days | 0.000000 % | 0.000000 % | 150 Days | 0.000000 % | 0.000000 % | 150 Days | 0.000000 % | 0.000000 % | 150 Days | 0.000000 % | 0.000000 % |
| 180+ Days | 50.000000 % | 6.950844 % | 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 50.000000 % | 93.049156 % | 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 100.000000 % | 100.000000 % |
| 50.000000 % 6.950844 % |  |  | 0.000000 % 0.000000 % |  |  | 50.000000 % 93.049156 % |  |  | 0.000000 % 0.000000 % |  |  | 100.000000 % 100.000000 % |  |  |

--- Page 8 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 16-Oct-2023
12-Oct-2023 10:37:50 AM
180+ Delinquency Summary
This report includes all loans greater than 180 days delinquent regardless of status (REO, Foreclosure, Bankruptcy)
© 2021 Computershare. All rights reserved. Confidential. Page 9 of 43

Stanwich Mortgage Loan Trust
Asset Backed Pass-Through Certificates
Series 2020-11

|  | Summary |  |  |
| --- | --- | --- | --- |
| Days Delinquent | Number of Loans | Outstanding Actual Balance($) | Percentage Of Balance(%) |
| 1920 - 1949 | 1 | 100,400.56 | 93.049 |
| 5130 - 5159 | 1 | 7,500.00 | 6.951 |
| Total | 2 | 107,900.56 | 100.000 |

--- Page 9 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 16-Oct-2023
12-Oct-2023 10:37:50 AM
Realized Loss Detail Report - Loans with Losses during Current Period
© 2021 Computershare. All rights reserved. Confidential. Page 13 of 43

Stanwich Mortgage Loan Trust
Asset Backed Pass-Through Certificates
Series 2020-11

|  |  | Inactive |  |  |  |  |  |  | Active |  |  |  |  |  |  | Totals |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  |  | # Loans with Losses | Liquidated Actual Balance |  | Realized Loss/(Gain) Amount |  | Current Loss Percentage |  | # Loans with Losses |  | Ending Actual Balance |  | Realized Loss/(Gain) Amount |  | Current Loss Percentage | # Loans with Losses |  | Liquidated or Ending Actual Balance |  | Realized Loss/(Gain) Amount |  | Current Loss Percentage |
| No Losses this Period |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Realized Loss Loan Detail Report - Loans with Losses during Current Period |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

| Group | Loan Number | Original Securitized Balance | Current Note Rate | State | LTV at Origination | Original Term | Liquidated or Ending Actual Balance | Liquidation Effective Date | Realized Loss/(Gain) | Cumulative Realized Loss/(Gain) |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| No Losses this Period |  |  |  |  |  |  |  |  |  |  |

--- Page 10 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 16-Oct-2023
12-Oct-2023 10:37:50 AM
Calculation Methodology:
Monthly Default Rate (MDR): Sum(Beg Scheduled Balance of Liquidated Loans) / Sum(Beg Scheduled Balance).
Conditional Default Rate (CDR): 1-((1-MDR)^12)
SDA Standard Default Assumption: If WAS ≤ 30 then CDR / (WAS * 0.02) else if 30 < WAS ≤ 60 then CDR / 0.6 else if 60 < WAS ≤ 120 then CDR / (0.6 - ((WAS - 60) * 0.0095)) else if WAS > 120 then CDR /
0.03
Cumulative Loss Severity: Sum(All Active & Inactive Realized Losses) / Sum(Active Loans or loans without a loss passed on or after liquidation: the Actual Ending Principal Balance as of the most recent cycle in
which a Realized Loss was passed; loans with a loss passed on or after the month of liquidation: the Actual Beginning Principal Balance from the cycle in which the loan was liquidated).
3 Month Average and 12 Month Average will not have values until the 3rd and 12th month respectively.
© 2021 Computershare. All rights reserved. Confidential. Page 14 of 43

Stanwich Mortgage Loan Trust
Asset Backed Pass-Through Certificates
Series 2020-11

Realized Loss Report - Collateral
Summary
MDR SDA Current Month 0.000 % Current Month 0.000 % 3 Month Average 0.000 % 3 Month Average 0.000 % 12 Month Average 0.910 % 12 Month Average 208.427 %
CDR | Loss Severity
Current Month | 0.000 % | Current Month (Cumulative) | (5.795) %
3 Month Average | 0.000 % | 3 Month Average (Cumulative) | (5.795) %
12 Month Average | 6.253 % | 12 Month Average (Cumulative) | (5.798) %

--- Page 11 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 16-Oct-2023
12-Oct-2023 10:37:50 AM
Prepayment Detail - Prepayments during Current Period
Prepayment Loan Detail - Prepayments during Current Period
© 2021 Computershare. All rights reserved. Confidential. Page 15 of 43

Stanwich Mortgage Loan Trust
Asset Backed Pass-Through Certificates
Series 2020-11

| Summary |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | Loans Paid in Full |  |  | Repurchased Loans |  |  | Substitution Loans |  |  | Liquidated Loans |  |  | Curtailments |
|  | Count | Original Securitized Balance | Current Scheduled Balance | Count | Original Securitized Balance | Current Scheduled Balance | Count | Original Securitized Balance | Current Scheduled Balance | Count | Original Securitized Balance | Current Scheduled Balance | Curtailment Amount |
| Total | 0 | 0.00 | 0.00 | 0 | 0.00 | 0.00 | 0 | 0.00 | 0.00 | 0 | 0.00 | 0.00 | 0.00 |

| Group | Loan Number | State | LTV at Origination | First Payment Date | Original Securitized Balance | Prepayment Amount | Resolution Type | Months Delinquent | Current Loan Rate | Original Term | Seasoning |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| No Prepayments in Full this Period |  |  |  |  |  |  |  |  |  |  |  |

--- Page 12 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 16-Oct-2023
12-Oct-2023 10:37:50 AM
Prepayment Penalty Loan Detail - Prepayment Penalty Paid during Current Period
© 2021 Computershare. All rights reserved. Confidential. Page 16 of 43

Stanwich Mortgage Loan Trust
Asset Backed Pass-Through Certificates
Series 2020-11

Prepayment Penalty Detail - Prepayment Penalty Paid during Current Period

| Summary | Loan Count | Prior Balance | Prepayment Penalty Amount | Prepayment Penalty Waived |
| --- | --- | --- | --- | --- |
| Total | 0 | 0.00 | 0.00 | 0.00 |

| Group | Loan Number | Paid In Full Date | Prior Balance | Prepayment Penalty Amount | Prepayment Penalty Waived |
| --- | --- | --- | --- | --- | --- |
| No Prepayment Penalties this period |  |  |  |  |  |

--- Page 13 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 16-Oct-2023
12-Oct-2023 10:37:50 AM
Prepayment Rates
Calculation Methodology:
Single Month Mortality (SMM): (Partial and full prepayments + Repurchases) / (Beginning Scheduled Balance - Scheduled Principal)
Conditional PrePayment Rate (CPR): 1 - ((1 - SMM)^12)
PSA Standard Prepayment Model: 100 * CPR / (0.2 * MIN(30,WAS))
Weighted Average Seasoning (WAS): sum((Original Term - Remaining Term)*(Current Scheduled Balance/Deal Scheduled Principal Balance))
© 2021 Computershare. All rights reserved. Confidential. Page 17 of 43

Stanwich Mortgage Loan Trust
Asset Backed Pass-Through Certificates
Series 2020-11

Summary
SMM CPR PSA Current Month 0.000 % Current Month 0.000 % Current Month 0.000 % 3 Month Average 15.062 % 3 Month Average 33.309 % 3 Month Average 555.147 % 12 Month Average 7.835 % 12 Month Average 22.886 % 12 Month Average 381.434 %

--- Page 14 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 16-Oct-2023
12-Oct-2023 10:37:51 AM
© 2021 Computershare. All rights reserved. Confidential. Page 19 of 43

Stanwich Mortgage Loan Trust
Asset Backed Pass-Through Certificates
Series 2020-11

Modification Detail

| Modification Detail Summary |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | Current |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Cumulative |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Groups | Loan Count |  |  | Original Securitized Balance |  |  | Current Scheduled Balance |  |  | Capitalized Amount |  |  | Capitalized Reimbursement Amount |  |  |  |  | Total Forgiveness |  |  | Loan Count |  | Original Securitized Balance |  |  | Current Scheduled Balance |  |  | Capitalized Amount |  | Capitalized Reimbursement Amount |  |  | Total Forgiveness |  |
| Total | 0 |  |  | 0.00 |  |  | 0.00 |  |  | 0.00 |  |  | 0.00 |  |  |  |  | 0.00 |  |  | 110 |  | 18,345,621.00 |  |  | 0.00 |  |  | 2,783,277.18 |  | (3,377,011.71) |  |  | 0.00 |  |
| Current Month Modification Detail |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Loan Number/ Original Balance |  |  | Mod Appr Date/Mod Effective Date |  |  | Total Capitalized Amount |  |  | Total Capitalized Reimb. Amount |  |  | Total Forgiveness |  |  | No of Times Loan Modified |  |  |  | No of Months Delinq. |  | Loan Status |  |  | Next Due Date |  |  | Interest Rate | Payment Amount |  | Maturity Date |  | Balloon Amount | Balloon Date |  | Scheduled Balance |
| No Modifications this Period |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Historical Modification Detail |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Loan Number/ Original Balance |  | Mod Appr Date/Mod Effective Date |  |  | Total Capitalized Amount |  |  | Total Capitalized Reimb. Amount |  |  | Total Forgiveness |  |  | No of Times Loan Modified |  |  |  |  |  | No of Months Delinq. |  | Loan Status |  |  | Next Due Date |  | Interest Rate | Payment Amount |  | Maturity Date |  | Balloon Amount | Balloon Date |  | Scheduled Balance |
| 7000265758 |  | 03/09/2021 |  |  |  |  |  |  |  |  |  |  |  |  |  | Pre Mod |  |  |  | 87 |  | Bankruptcy |  |  | 11/01/2013 |  | 5.500 | 998.96 |  | 08/01/2033 |  | * | * |  | 142,973.15 |
| 175,937.00 |  | 03/01/2021 |  |  | * |  |  | (114,789.43) |  |  | * |  |  |  |  | Post Mod |  |  |  | 0 |  | Bankruptcy |  |  | 02/01/2021 |  | 3.125 | 1,107.45 |  | 12/01/2050 |  | * | * |  | 257,762.58 |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  | Current Values |  |  |  |  |  | INACTIVE |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 7000265774 |  | 12/08/2021 |  |  |  |  |  |  |  |  |  |  |  |  |  | Pre Mod |  |  |  | 16 |  | No Action |  |  | 06/01/2020 |  | 6.500 | 755.73 |  | 01/01/2030 |  | * | * |  | 79,991.11 |
| 115,760.00 |  | 11/01/2021 |  |  | 11,750.49 |  |  | (11,743.83) |  |  | * |  |  |  |  | Post Mod |  |  |  | 0 |  | No Action |  |  | 11/01/2021 |  | 2.875 | 375.69 |  | 10/01/2051 |  | * | * |  | 91,734.94 |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  | Current Values |  |  |  |  |  | INACTIVE |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 7000265786 |  | 04/09/2021 |  |  |  |  |  |  |  |  |  |  |  |  |  | Pre Mod |  |  |  | 15 |  | Foreclosure |  |  | 11/01/2019 |  | 5.875 | 1,184.85 |  | 07/01/2033 |  | * | * |  | 133,750.35 |
| 200,300.00 |  | 04/01/2021 |  |  | * |  |  | (20,781.16) |  |  | * |  |  |  |  | Post Mod |  |  |  | (1) |  | No Action |  |  | 05/01/2021 |  | 2.750 | 1,239.42 |  | 07/01/2033 |  | * | * |  | 154,531.51 |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  | Current Values |  |  |  |  |  | INACTIVE |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 7000265790 |  | 12/09/2020 |  |  |  |  |  |  |  |  |  |  |  |  |  | Pre Mod |  |  |  | 12 |  | No Action |  |  | 10/01/2019 |  | 3.625 | 507.05 |  | 08/01/2034 |  | * | * |  | 104,380.06 |
| 97,231.00 |  | 11/01/2020 |  |  | 6,591.47 |  |  | (6,591.47) |  |  | * |  |  |  |  | Post Mod |  |  |  | 0 |  | No Action |  |  | 12/01/2020 |  | 3.375 | 490.61 |  | 11/01/2050 |  | * | * |  | 110,971.53 |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  | Current Values |  |  |  |  |  | INACTIVE |  |  |  |  |  |  |  |  |  |  |  |  |  |

--- Page 15 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 16-Oct-2023
12-Oct-2023 10:37:51 AM
Collateral Balance Detail
Balance Methodology:
IB: Interest Bearing
NIB: Non-Interest Bearing
NIB Non-Loss Balance: current balance of NIB amounts that were not treated as a loss at the time of the related modification
Trust Balance = IB Balance + NIB Non-Loss Balance
NIB Loss Balance: current balance of NIB amounts that were treated as a loss at the time of the related modification
TDO: Total Debt Owed = IB Balance + NIB Non-Loss Balance + NIB Loss Balance
© 2021 Computershare. All rights reserved. Confidential. Page 36 of 43

Stanwich Mortgage Loan Trust
Asset Backed Pass-Through Certificates
Series 2020-11

| Group | Total |
| --- | --- |
| Beginning Scheduled Balance: IB | 168,725.64 |
| Beginning NIB Non-Loss Balance | 0.00 |
| Beginning Scheduled Balance: Trust | 168,725.64 |
| Beginning NIB Loss Balance | 0.00 |
| Beginning Scheduled Balance: TDO | 168,725.64 |

| Ending Scheduled Balance: IB | 107,900.56 |
| --- | --- |
| Ending NIB Non-Loss Balance | 0.00 |
| Ending Scheduled Balance: Trust | 107,900.56 |
| Ending NIB Loss Balance | 0.00 |
| Ending Scheduled Balance: TDO | 107,900.56 |

| Ending Actual Balance: IB | 107,900.56 |
| --- | --- |
| Ending NIB Non-Loss Balance | 0.00 |
| Ending Actual Balance: Trust | 107,900.56 |
| Ending NIB Loss Balance | 0.00 |
| Ending Actual Balance: TDO | 107,900.56 |

--- Page 16 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 16-Oct-2023
12-Oct-2023 10:37:51 AM
Cumulative Repurchases Due To Breaches
© 2021 Computershare. All rights reserved. Confidential. Page 37 of 43

Stanwich Mortgage Loan Trust
Asset Backed Pass-Through Certificates
Series 2020-11

| Substitutions |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | Loans Repurchased |  |  |  |  | Loans Substituted |  |  |
| Loan Number | Current Scheduled Balance | Current Rate | Current Payment |  | Loan Number | Current Scheduled Balance | Current Rate | Current Payment |
| No Substitutions this Period |  |  |  |  |  |  |  |  |

| Current Repurchases Due To Breaches |  |  |  |  |
| --- | --- | --- | --- | --- |
| Loan Number | Beginning Scheduled Balance | Payoff Balance | Current Rate | Current Payment |
| No Repurchases Due to Breaches this Period |  |  |  |  |

| Count of Loans Repurchased Due To Breaches | Total Cumulative UPB of Loans Repurchased Due To Breaches |
| --- | --- |
| No Cumulative Repurchases |  |