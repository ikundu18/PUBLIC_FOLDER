--- Page 1 ---

Contact: Customer Service - CTSLink
Deephaven Residential Mortgage Trust
Wells Fargo Bank, N.A.
Mortgage-Backed Notes
Deephaven Residential Mortgage Trust Securities Administration Services
Distribution Date: 25-Jan-2021
8480 Stagecoach Circle
Mortgage-Backed Notes
Frederick, MD 21701-4747
Series 2018-1
www.ctslink.com
20-Jan-2021 02:49:10 PM Telephone: 1-866-846-4526
Certificateholder Distribution Summary
This report is compiled by Wells Fargo Bank, N.A. from information provided by third parties. Wells Fargo Bank, N.A. has not independently confirmed the accuracy of the information.
All Record Dates are based upon the governing documents and logic set forth as of closing.
Page 1

| Class | CUSIP | Record Date | Certificate Pass-Through Rate | Beginning Certificate Balance | Interest Distribution | Principal Distribution | Current Realized Loss | Ending Certificate Balance | Total Distribution | Cumulative Realized Losses |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| A-1 A-2 A-3 M-1 B-1 B-2 B-3 A-IO-S XS R | 24380PAA2 24380PAB0 24380PAC8 24380PAD6 24380PAE4 24380PAF1 24380PAG9 24380PAH7 24380PAJ3 24380PAK0 | 12/31/2020 12/31/2020 12/31/2020 12/31/2020 12/31/2020 12/31/2020 12/31/2020 12/31/2020 12/31/2020 12/31/2020 | 2.97600 % 3.02700 % 3.20200 % 3.93900 % 4.34000 % 5.79300 % 6.07293 % 0.50000 % 2.16819 % 0.00000 % | 33,440,627.61 3,596,853.97 6,073,010.38 20,804,000.00 16,797,000.00 12,945,000.00 2,774,425.00 0.00 0.00 0.00 | 82,932.76 9,073.06 16,204.82 68,289.13 60,749.15 62,491.99 14,040.74 40,179.55 119,513.46 0.00 | 4,261,423.05 458,356.12 773,898.95 0.00 0.00 0.00 0.00 0.00 0.00 0.00 | 0.00 0.00 0.00 0.00 0.00 0.00 0.00 0.00 0.00 0.00 | 29,179,204.56 3,138,497.85 5,299,111.44 20,804,000.00 16,797,000.00 12,945,000.00 2,774,425.00 0.00 0.00 0.00 | 4,344,355.81 467,429.18 790,103.77 68,289.13 60,749.15 62,491.99 14,040.74 40,179.55 119,513.46 0.00 | 0.00 0.00 0.00 0.00 0.00 0.00 0.00 0.00 0.00 0.00 |
| Totals |  |  |  | 96,430,916.96 | 473,474.66 | 5,493,678.12 | 0.00 | 90,937,238.85 | 5,967,152.78 | 0.00 |

--- Page 2 ---

Contact: Customer Service - CTSLink
Deephaven Residential Mortgage Trust
Wells Fargo Bank, N.A.
Mortgage-Backed Notes
Deephaven Residential Mortgage Trust Securities Administration Services
Distribution Date: 25-Jan-2021
8480 Stagecoach Circle
Mortgage-Backed Notes
Frederick, MD 21701-4747
Series 2018-1
www.ctslink.com
20-Jan-2021 02:49:10 PM Telephone: 1-866-846-4526
Principal Distribution Statement
Page 2

| Class | Original Face Amount | Beginning Certificate Balance | Scheduled Unscheduled Principal Principal Realized Distribution Distribution Accretion Loss | Total Principal Reduction | Ending Certificate Balance | Ending Certificate Percentage | Total Principal Distribution |
| --- | --- | --- | --- | --- | --- | --- | --- |
| A-1 A-2 A-3 M-1 B-1 B-2 B-3 XS R | 197,714,000.00 21,266,000.00 35,906,000.00 20,804,000.00 16,797,000.00 12,945,000.00 2,774,425.00 0.00 0.00 | 33,440,627.61 3,596,853.97 6,073,010.38 20,804,000.00 16,797,000.00 12,945,000.00 2,774,425.00 0.00 0.00 | 0.00 4,261,423.05 0.00 0.00 0.00 458,356.12 0.00 0.00 0.00 773,898.95 0.00 0.00 0.00 0.00 0.00 0.00 0.00 0.00 0.00 0.00 0.00 0.00 0.00 0.00 0.00 0.00 0.00 0.00 0.00 0.00 0.00 0.00 0.00 0.00 0.00 0.00 | 4,261,423.05 458,356.12 773,898.95 0.00 0.00 0.00 0.00 0.00 0.00 | 29,179,204.56 3,138,497.85 5,299,111.44 20,804,000.00 16,797,000.00 12,945,000.00 2,774,425.00 0.00 0.00 | 0.14758290 0.14758290 0.14758290 1.00000000 1.00000000 1.00000000 1.00000000 0.00000000 0.00000000 | 4,261,423.05 458,356.12 773,898.95 0.00 0.00 0.00 0.00 0.00 0.00 |
| Totals | 308,206,425.00 | 96,430,916.96 | 0.00 5,493,678.12 0.00 0.00 | 5,493,678.12 | 90,937,238.85 | 0.29505303 | 5,493,678.12 |

--- Page 3 ---

Contact: Customer Service - CTSLink
Deephaven Residential Mortgage Trust
Wells Fargo Bank, N.A.
Mortgage-Backed Notes
Deephaven Residential Mortgage Trust Securities Administration Services
Distribution Date: 25-Jan-2021
8480 Stagecoach Circle
Mortgage-Backed Notes
Frederick, MD 21701-4747
Series 2018-1
www.ctslink.com
20-Jan-2021 02:49:10 PM Telephone: 1-866-846-4526
Principal Distribution Factors Statement
NOTE: All classes per $1,000 denomination.
Page 3

| Class | Original Face Amount | Beginning Certificate Balance | Scheduled Unscheduled Principal Principal Realized Distribution Distribution Accretion Loss | Total Principal Reduction | Ending Certificate Balance | Ending Certificate Percentage | Total Principal Distribution |
| --- | --- | --- | --- | --- | --- | --- | --- |
| A-1 A-2 A-3 M-1 B-1 B-2 B-3 A-IO-S XS R | 197,714,000.00 21,266,000.00 35,906,000.00 20,804,000.00 16,797,000.00 12,945,000.00 2,774,425.00 0.00 0.00 0.00 | 169.13636672 169.13636650 169.13636662 1000.00000000 1000.00000000 1000.00000000 1000.00000000 0.00000000 0.00000000 0.00000000 | 0.00000000 21.55347143 0.00000000 0.00000000 0.00000000 21.55347127 0.00000000 0.00000000 0.00000000 21.55347156 0.00000000 0.00000000 0.00000000 0.00000000 0.00000000 0.00000000 0.00000000 0.00000000 0.00000000 0.00000000 0.00000000 0.00000000 0.00000000 0.00000000 0.00000000 0.00000000 0.00000000 0.00000000 0.00000000 0.00000000 0.00000000 0.00000000 0.00000000 0.00000000 0.00000000 0.00000000 0.00000000 0.00000000 0.00000000 0.00000000 | 21.55347143 21.55347127 21.55347156 0.00000000 0.00000000 0.00000000 0.00000000 0.00000000 0.00000000 0.00000000 | 147.58289529 147.58289523 147.58289534 1000.00000000 1000.00000000 1000.00000000 1000.00000000 0.00000000 0.00000000 0.00000000 | 0.14758290 0.14758290 0.14758290 1.00000000 1.00000000 1.00000000 1.00000000 0.00000000 0.00000000 0.00000000 | 21.55347143 21.55347127 21.55347156 0.00000000 0.00000000 0.00000000 0.00000000 0.00000000 0.00000000 0.00000000 |

--- Page 4 ---

Contact: Customer Service - CTSLink
Deephaven Residential Mortgage Trust
Wells Fargo Bank, N.A.
Mortgage-Backed Notes
Deephaven Residential Mortgage Trust Securities Administration Services
Distribution Date: 25-Jan-2021
8480 Stagecoach Circle
Mortgage-Backed Notes
Frederick, MD 21701-4747
Series 2018-1
www.ctslink.com
20-Jan-2021 02:49:10 PM Telephone: 1-866-846-4526
Interest Distribution Statement
(1) Amount also includes Coupon Cap or Basis Risk Shortfalls, if applicable.
Page 4

| Class | Accrual Dates | Accrual Days | Current Certificate Rate | Beginning Certificate/ Notional Balance | Payment of Non- Current Unpaid Current Supported Accrued Interest Interest Interest Interest Shortfall(1) Shortfall(1) Shortfall | Total Interest Distribution | Remaining Unpaid Interest Shortfall(1) | Ending Certificate/ Notional Balance |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| A-1 A-2 A-3 M-1 B-1 B-2 B-3 A-IO-S XS R | 12/01/20 - 12/30/20 12/01/20 - 12/30/20 12/01/20 - 12/30/20 12/01/20 - 12/30/20 12/01/20 - 12/30/20 12/01/20 - 12/30/20 12/01/20 - 12/30/20 12/01/20 - 12/30/20 12/01/20 - 12/30/20 N/A | 30 30 30 30 30 30 30 30 30 N/A | 2.97600 % 3.02700 % 3.20200 % 3.93900 % 4.34000 % 5.79300 % 6.07293 % 0.50000 % 2.16819 % 0.00000 % | 33,440,627.61 3,596,853.97 6,073,010.38 20,804,000.00 16,797,000.00 12,945,000.00 2,774,425.00 96,430,917.17 96,430,917.17 0.00 | 82,932.76 0.00 0.00 0.00 9,073.06 0.00 0.00 0.00 16,204.82 0.00 0.00 0.00 68,289.13 0.00 0.00 0.00 60,749.15 0.00 0.00 0.00 62,491.99 0.00 0.00 0.00 14,040.74 0.00 0.00 0.00 40,179.55 0.00 0.00 0.00 174,233.41 0.00 54,719.95 0.00 0.00 0.00 0.00 0.00 | 82,932.76 9,073.06 16,204.82 68,289.13 60,749.15 62,491.99 14,040.74 40,179.55 119,513.46 0.00 | 0.00 0.00 0.00 0.00 0.00 0.00 0.00 0.32 445,573.22 0.00 | 29,179,204.56 3,138,497.85 5,299,111.44 20,804,000.00 16,797,000.00 12,945,000.00 2,774,425.00 90,937,239.05 90,937,239.05 0.00 |
| Totals |  |  |  |  | 528,194.61 0.00 54,719.95 0.00 | 473,474.66 | 445,573.54 |  |

--- Page 5 ---

Contact: Customer Service - CTSLink
Deephaven Residential Mortgage Trust
Wells Fargo Bank, N.A.
Mortgage-Backed Notes
Deephaven Residential Mortgage Trust Securities Administration Services
Distribution Date: 25-Jan-2021
8480 Stagecoach Circle
Mortgage-Backed Notes
Frederick, MD 21701-4747
Series 2018-1
www.ctslink.com
20-Jan-2021 02:49:10 PM Telephone: 1-866-846-4526
Interest Distribution Factors Statement
(1) Amount also includes Coupon Cap or Basis Risk Shortfalls, if applicable.
NOTE: All classes per $1,000 denomination.
Page 5

| Class | Original Face Amount | Current Certificate Rate | Beginning Certificate/ Notional Balance | Payment of Non- Current Current Unpaid Supported Accrued Interest Interest Interest Interest Shortfall(1) Shortfall(1) Shortfall | Total Interest Distribution | Remaining Unpaid Interest Shortfall(1) | Ending Certificate/ Notional Balance |
| --- | --- | --- | --- | --- | --- | --- | --- |
| A-1 A-2 A-3 M-1 B-1 B-2 B-3 A-IO-S XS R | 197,714,000.00 21,266,000.00 35,906,000.00 20,804,000.00 16,797,000.00 12,945,000.00 2,774,425.00 0.00 0.00 0.00 | 2.97600 % 3.02700 % 3.20200 % 3.93900 % 4.34000 % 5.79300 % 6.07293 % 0.50000 % 2.16819 % 0.00000 % | 169.13636672 169.13636650 169.13636662 1000.00000000 1000.00000000 1000.00000000 1000.00000000 312.87769932 312.87769932 0.00000000 | 0.41945821 0.00000000 0.00000000 0.00000000 0.42664629 0.00000000 0.00000000 0.00000000 0.45131232 0.00000000 0.00000000 0.00000000 3.28250000 0.00000000 0.00000000 0.00000000 3.61666667 0.00000000 0.00000000 0.00000000 4.82750019 0.00000000 0.00000000 0.00000000 5.06077476 0.00000000 0.00000000 0.00000000 0.13036571 0.00000000 0.00000000 0.00000000 0.56531401 0.00000000 0.17754318 0.00000000 0.00000000 0.00000000 0.00000000 0.00000000 | 0.41945821 0.42664629 0.45131232 3.28250000 3.61666667 4.82750019 5.06077476 0.13036571 0.38777083 0.00000000 | 0.00000000 0.00000000 0.00000000 0.00000000 0.00000000 0.00000000 0.00000000 0.00000104 1.44569738 0.00000000 | 147.58289529 147.58289523 147.58289534 1000.00000000 1000.00000000 1000.00000000 1000.00000000 295.05302834 295.05302834 0.00000000 |

--- Page 6 ---

Contact: Customer Service - CTSLink
Deephaven Residential Mortgage Trust
Wells Fargo Bank, N.A.
Mortgage-Backed Notes
Deephaven Residential Mortgage Trust Securities Administration Services
Distribution Date: 25-Jan-2021
8480 Stagecoach Circle
Mortgage-Backed Notes
Frederick, MD 21701-4747
Series 2018-1
www.ctslink.com
20-Jan-2021 02:49:10 PM Telephone: 1-866-846-4526
Certificateholder Account Statement
*Servicer Payees include: SHELLPOINT MORTGAGE SERVICING
Servicer Advances are calculated as delinquent scheduled principal and interest.
Page 6

CERTIFICATE ACCOUNT
Beginning Balance 0.00 Deposits Payments of Interest and Principal 6,100,123.22 Reserve Funds and Credit Enhancements 0.00 Proceeds from Repurchased Loans 0.00 Servicer Advances 47,637.96 Gains & Subsequent Recoveries (Realized Losses) 0.00 Total Deposits 6,147,761.18 Withdrawals Reserve Funds and Credit Enhancements 0.00 Reimbursement for Servicer Advances 134,970.51 Total Administration Fees 45,637.89 Payment of Interest and Principal 5,967,152.78 Total Withdrawals (Pool Distribution Amount) 6,147,761.18 Ending Balance 0.00

PREPAYMENT/CURTAILMENT INTEREST SHORTFALL
Total Prepayment/Curtailment Interest Shortfall 0.00 Servicing Fee Support 0.00 Non-Supported Prepayment/Curtailment Interest Shortfall 0.00

ADMINISTRATION FEES
Gross Servicing Fee* 40,179.56 Custodian Fee - Deutsche Bank National Trust Company 0.00 Indenture Trustee - Wilmington Trust, N.A. 708.33 Master Servicing Fee - Wells Fargo Bank, N.A. 3,500.00 Owner Trustee - Wilmington Savings Fund Society, FSB 1,250.00 Supported Prepayment/Curtailment Interest Shortfall 0.00 Total Administration Fees 45,637.89

Reserve and Guaranty Funds Beginning Current Current Ending Account Name Balance Withdrawals Deposits Balance
Cap Carryover Reserve Account 0.00 0.00 0.00 0.00

--- Page 7 ---

Contact: Customer Service - CTSLink
Deephaven Residential Mortgage Trust
Wells Fargo Bank, N.A.
Mortgage-Backed Notes
Deephaven Residential Mortgage Trust Securities Administration Services
Distribution Date: 25-Jan-2021
8480 Stagecoach Circle
Mortgage-Backed Notes
Frederick, MD 21701-4747
Series 2018-1
www.ctslink.com
20-Jan-2021 02:49:10 PM Telephone: 1-866-846-4526
NOTE: The Collateral Balances shown are Trust Balances unless otherwise designated.
Page 7

Collateral Statement
Group Total Collateral Description Mixed Fixed Weighted Average Coupon Rate 6.685676 Weighted Average Net Rate 6.185676 Weighted Average Pass-Through Rate 6.185676 Weighted Average Remaining Term 324 Principal and Interest Constant 635,561.59 Beginning Loan Count 265 Loans Paid in Full 13 Ending Loan Count 252 Beginning Scheduled Balance 96,430,917.17 Ending Scheduled Balance 90,937,239.05 Actual Ending Collateral Balance 91,067,347.92 Scheduled Principal 98,306.69 Unscheduled Principal 5,395,371.43 Negative Amortized Principal 0.00 Scheduled Interest 537,254.90 Servicing Fees 40,179.56 Master Servicing Fees 0.00 Trustee Fee 0.00 FRY Amount 0.00 Special Hazard Fee 0.00 Other Fee 0.00 Pool Insurance Fee 0.00 Spread 1 0.00 Spread 2 0.00 Spread 3 0.00 Net Interest 497,075.34 Realized Loss Amount 0.00 Cumulative Realized Loss 0.00 Percentage of Cumulative Losses 0.0000 Special Servicing Fee 0.00

--- Page 8 ---

Contact: Customer Service - CTSLink
Deephaven Residential Mortgage Trust
Wells Fargo Bank, N.A.
Mortgage-Backed Notes
Deephaven Residential Mortgage Trust Securities Administration Services
Distribution Date: 25-Jan-2021
8480 Stagecoach Circle
Mortgage-Backed Notes
Frederick, MD 21701-4747
Series 2018-1
www.ctslink.com
20-Jan-2021 02:49:10 PM Telephone: 1-866-846-4526
Additional Reporting - Deal Level
Page 8

Cash Reporting
Expenses Reimbursed to the Custodian 0.00 Expenses Reimbursed to the Indenture Trustee 0.00 Expenses Reimbursed to the Owner Trustee 0.00 Expenses Reimbursed to Wells Fargo Bank, N.A. 0.00 Compensating Interest Amount -1,288.19 Extraordinary Expenses Paid 0.00
Informational Reporting
Nonrecoverable Advances Made 213,036.31 Nonrecoverable Advances Outstanding 207,828.24 Nonrecoverable Advances Reimbursed 5,208.07 Escrow Advances Made 277,632.77 Escrow Advances Outstanding 274,070.03 Escorw Advances Reimbursed 3,562.74 Servicing Advances Made 70,479.41 Servicing Advances Outstanding 69,693.57 Servicing Advances Reimbursed 785.84
Structural Reporting
Net WAC Rate 6.072928%
Trigger Event Reporting
DelinqTest Trigger Result Pass Threshold Value 20.000000% Calculated Value 17.559222% CUMLOSS Trigger Result Pass Threshold Value 1.500000% Calculated Value 0.000000% Sequential Trigger Trigger Result Pass Threshold Value 0.000000% Calculated Value 0.000000%

--- Page 9 ---

Contact: Customer Service - CTSLink
Deephaven Residential Mortgage Trust
Wells Fargo Bank, N.A.
Mortgage-Backed Notes
Deephaven Residential Mortgage Trust Securities Administration Services
Distribution Date: 25-Jan-2021
8480 Stagecoach Circle
Mortgage-Backed Notes
Frederick, MD 21701-4747
Series 2018-1
www.ctslink.com
20-Jan-2021 02:49:10 PM Telephone: 1-866-846-4526
Delinquency Status - MBA Delinquency Calculation Method
Please refer to CTSLink.com for a list of delinquency code descriptions.
Current Period Class A Insufficient Funds 0.00 Principal Balance of Contaminated Properties 0.00 Periodic Advance 47,637.96
Page 9

| DELINQUENT | BANKRUPTCY | FORECLOSURE | REO | TOTAL |
| --- | --- | --- | --- | --- |
| No. of Actual Balance Loans 30 Days 7 2,883,540.59 60 Days 6 2,357,688.47 90 Days 3 2,547,714.17 120 Days 0 0.00 150 Days 0 0.00 180+ Days 22 9,948,937.49 38 17,737,880.72 No. of Actual Balance Loans 30 Days 2.777778 % 3.166383 % 60 Days 2.380952 % 2.588950 % 90 Days 1.190476 % 2.797615 % 120 Days 0.000000 % 0.000000 % 150 Days 0.000000 % 0.000000 % 180+ Days 8.730159 % 10.924813 % 15.079365 % 19.477761 % | No. of Actual Balance Loans 0-29 Days 0 0.00 30 Days 0 0.00 60 Days 0 0.00 90 Days 0 0.00 120 Days 0 0.00 150 Days 0 0.00 180+ Days 0 0.00 0 0.00 No. of Actual Balance Loans 0-29 Days 0.000000 % 0.000000 % 30 Days 0.000000 % 0.000000 % 60 Days 0.000000 % 0.000000 % 90 Days 0.000000 % 0.000000 % 120 Days 0.000000 % 0.000000 % 150 Days 0.000000 % 0.000000 % 180+ Days 0.000000 % 0.000000 % 0.000000 % 0.000000 % | No. of Actual Balance Loans 0-29 Days 0 0.00 30 Days 0 0.00 60 Days 0 0.00 90 Days 0 0.00 120 Days 0 0.00 150 Days 0 0.00 180+ Days 0 0.00 0 0.00 No. of Actual Balance Loans 0-29 Days 0.000000 % 0.000000 % 30 Days 0.000000 % 0.000000 % 60 Days 0.000000 % 0.000000 % 90 Days 0.000000 % 0.000000 % 120 Days 0.000000 % 0.000000 % 150 Days 0.000000 % 0.000000 % 180+ Days 0.000000 % 0.000000 % 0.000000 % 0.000000 % | No. of Actual Balance Loans 0-29 Days 0 0.00 30 Days 0 0.00 60 Days 0 0.00 90 Days 0 0.00 120 Days 0 0.00 150 Days 0 0.00 180+ Days 0 0.00 0 0.00 No. of Actual Balance Loans 0-29 Days 0.000000 % 0.000000 % 30 Days 0.000000 % 0.000000 % 60 Days 0.000000 % 0.000000 % 90 Days 0.000000 % 0.000000 % 120 Days 0.000000 % 0.000000 % 150 Days 0.000000 % 0.000000 % 180+ Days 0.000000 % 0.000000 % 0.000000 % 0.000000 % | No. of Actual Balance Loans 0-29 Days 0 0.00 30 Days 7 2,883,540.59 60 Days 6 2,357,688.47 90 Days 3 2,547,714.17 120 Days 0 0.00 150 Days 0 0.00 180+ Days 22 9,948,937.49 38 17,737,880.72 No. of Actual Balance Loans 0-29 Days 0.000000 % 0.000000 % 30 Days 2.777778 % 3.166383 % 60 Days 2.380952 % 2.588950 % 90 Days 1.190476 % 2.797615 % 120 Days 0.000000 % 0.000000 % 150 Days 0.000000 % 0.000000 % 180+ Days 8.730159 % 10.924813 % 15.079365 % 19.477761 % |

--- Page 10 ---

Contact: Customer Service - CTSLink
Deephaven Residential Mortgage Trust
Wells Fargo Bank, N.A.
Mortgage-Backed Notes
Deephaven Residential Mortgage Trust Securities Administration Services
Distribution Date: 25-Jan-2021
8480 Stagecoach Circle
Mortgage-Backed Notes
Frederick, MD 21701-4747
Series 2018-1
www.ctslink.com
20-Jan-2021 02:49:10 PM Telephone: 1-866-846-4526
180+ Delinquency Summary
This report includes all loans greater than 180 days delinquent regardless of status (REO, Foreclosure, Bankruptcy)
Page 10

|  | Summary |
| --- | --- |
|  | Number Outstanding Percentage Of Actual Of Loans Balance($) Balance(%) |
| 180 - 209 210 - 239 240 - 269 270 - 299 300 - 329 360 - 389 420 - 449 480 - 509 600 - 629 660 - 689 690 - 719 750 - 779 1080 - 1109 Total | 1 704,982.44 0.774 5 1,780,024.94 1.955 2 296,625.00 0.326 2 746,722.79 0.820 3 2,224,922.77 2.443 1 498,653.18 0.548 1 140,957.47 0.155 1 776,855.67 0.853 1 131,208.88 0.144 2 1,051,015.85 1.154 1 605,005.50 0.664 1 770,529.40 0.846 1 221,433.60 0.243 |
|  | 22 9,948,937.49 10.925 |

--- Page 11 ---

Contact: Customer Service - CTSLink
Deephaven Residential Mortgage Trust
Wells Fargo Bank, N.A.
Mortgage-Backed Notes
Deephaven Residential Mortgage Trust Securities Administration Services
Distribution Date: 25-Jan-2021
8480 Stagecoach Circle
Mortgage-Backed Notes
Frederick, MD 21701-4747
Series 2018-1
www.ctslink.com
20-Jan-2021 02:49:10 PM Telephone: 1-866-846-4526
REO Detail - All Mortgage Loans in REO during Current Period
Summary 12 Month REO History
New REO Loans
Loans in REO 0 1.60%
Original Principal Balance 0.00 1.40%
1.20%
Current Actual Balance 0.00
1.00%
0.80%
Current REO Total 0.60%
0.40%
Loans in REO 0
0.20%
Original Principal Balance 0.00 0.00%
Current Actual Balance 0.00
Feb-20 Mar-20 Apr-20 May-20 Jun-20 Jul-20 Aug-20 Sep-20 Oct-20 Nov-20 Dec-20 Jan-21
REO Loan Detail - All Mortgage Loans in REO during Current Period
Page 11

| Group | Loan Number | Month Loan Entered REO | First Payment Date | State | LTV at Origination | Original Principal Balance | Current Actual Balance | Paid To Date | Months Delinquent | Current Loan Rate | Approximate Delinquent Interest |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  | No | REO Loans | this Period |  |  |  |  |  |

--- Page 12 ---

Contact: Customer Service - CTSLink
Deephaven Residential Mortgage Trust
Wells Fargo Bank, N.A.
Mortgage-Backed Notes
Deephaven Residential Mortgage Trust Securities Administration Services
Distribution Date: 25-Jan-2021
8480 Stagecoach Circle
Mortgage-Backed Notes
Frederick, MD 21701-4747
Series 2018-1
www.ctslink.com
20-Jan-2021 02:49:10 PM Telephone: 1-866-846-4526
Foreclosure Detail - All Mortgage Loans in Foreclosure during Current Period
Summary 12 Month Foreclosure History
New Foreclosure Loans
Loans in Foreclosure 0 3.20%
Original Principal Balance 0.00 2.80%
2.40%
Current Actual Balance 0.00
2.00%
1.60%
Current Foreclosure Total 1.20%
0.80%
Loans in Foreclosure 0
0.40%
Original Principal Balance 0.00 0.00%
Current Actual Balance 0.00
Feb-20 Mar-20 Apr-20 May-20 Jun-20 Jul-20 Aug-20 Sep-20 Oct-20 Nov-20 Dec-20 Jan-21
Foreclosure Loan Detail - All Mortgage Loans in Foreclosure during Current Period
Page 12

| Group | Loan Number | Month Loan Entered FC | First Payment Date | State | LTV at Origination | Original Principal Balance | Current Actual Balance | Paid To Date | Months Delinquent | Current Loan Rate | Approximate Delinquent Interest |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  | No Forec | losure Loans this | Period |  |  |  |  |

--- Page 13 ---

Contact: Customer Service - CTSLink
Deephaven Residential Mortgage Trust
Wells Fargo Bank, N.A.
Mortgage-Backed Notes
Deephaven Residential Mortgage Trust Securities Administration Services
Distribution Date: 25-Jan-2021
8480 Stagecoach Circle
Mortgage-Backed Notes
Frederick, MD 21701-4747
Series 2018-1
www.ctslink.com
20-Jan-2021 02:49:10 PM Telephone: 1-866-846-4526
Bankruptcy Detail - All Mortgage Loans in Bankruptcy during Current Period
Summary 12 Month Bankruptcy History
New Bankruptcy Loans
Loans in Bankruptcy 0 2.00%
Original Principal Balance 0.00
1.60%
Current Actual Balance 0.00
1.20%
Current Bankruptcy Total
0.80%
Loans in Bankruptcy 0
0.40%
Original Principal Balance 0.00
Current Actual Balance 0.00 0.00% Feb-20 Mar-20 Apr-20 May-20 Jun-20 Jul-20 Aug-20 Sep-20 Oct-20 Nov-20 Dec-20 Jan-21
Bankruptcy Detail - All Mortgage Loans in Bankruptcy during Current Period
Page 13

| Group | Loan Number | Month Loan Entered Bankruptcy | First Payment Date | State | LTV at Origination | Original Principal Balance | Current Actual Balance | Paid To Date | Months Delinquent | Current Loan Rate | Approximate Delinquent Interest |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  | No Bankr | uptcy Loans thi | s Period |  |  |  |  |

--- Page 14 ---

Contact: Customer Service - CTSLink
Deephaven Residential Mortgage Trust
Wells Fargo Bank, N.A.
Mortgage-Backed Notes
Deephaven Residential Mortgage Trust Securities Administration Services
Distribution Date: 25-Jan-2021
8480 Stagecoach Circle
Mortgage-Backed Notes
Frederick, MD 21701-4747
Series 2018-1
www.ctslink.com
20-Jan-2021 02:49:10 PM Telephone: 1-866-846-4526
Realized Loss Detail Report - Loans with Losses during Current Period
Realized Loss Loan Detail Report - Loans with Losses during Current Period
Page 14

|  | Inactive |  |  |  | Active |  |  |  | Totals |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Group | # Loans with Losses | Liquidated Actual Balance | Realized Loss/(Gain) Amount | Current Loss Percentage | # Loans with Losses | Ending Actual Balance | Realized Loss/(Gain) Amount | Current Loss Percentage | # Loans with Losses | Liquidated or Ending Actual Balance | Realized Loss/(Gain) Amount | Current Loss Percentage |
| Total | 0 | 0.00 | 0.00 | 0.000 % | 0 | 0.00 | 0.00 | 0.000 % | 0 | 0.00 | 0.00 | 0.000 % |

| Group | Loan Number | Original Principal Balance | Current Note Rate | State | LTV at Origination | Original Term | Liquidated or Ending Actual Balance | Liquidation Effective Date | Realized Loss/(Gain) | Cumulative Realized Loss/(Gain) |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  | No L | osses this Peri | od |  |  |  |  |

--- Page 15 ---

Contact: Customer Service - CTSLink
Deephaven Residential Mortgage Trust
Wells Fargo Bank, N.A.
Mortgage-Backed Notes
Deephaven Residential Mortgage Trust Securities Administration Services
Distribution Date: 25-Jan-2021
8480 Stagecoach Circle
Mortgage-Backed Notes
Frederick, MD 21701-4747
Series 2018-1
www.ctslink.com
20-Jan-2021 02:49:10 PM Telephone: 1-866-846-4526
Realized Loss Report - Collateral
Calculation Methodology:
Monthly Default Rate (MDR): Sum(Beg Scheduled Balance of Liquidated Loans) / Sum(Beg Scheduled Balance).
Conditional Default Rate (CDR): 1-((1-MDR)^12)
SDA Standard Default Assumption: If WAS ≤ 30 then CDR / (WAS * 0.02) else if 30 < WAS ≤ 60 then CDR / 0.6 else if 60 < WAS ≤ 120 then CDR / (0.6 - ((WAS - 60) * 0.0095)) else if WAS > 120 then CDR / 0.03
Cumulative Loss Severity: Sum(All Active & Inactive Realized Losses) / Sum(Active Loans or loans without a loss passed on or after liquidation: the Actual Ending Principal Balance as of the most recent cycle in
which a Realized Loss was passed; loans with a loss passed on or after the month of liquidation: the Actual Beginning Principal Balance from the cycle in which the loan was liquidated).
3 Month Average and 12 Month Average will not have values until the 3rd and 12th month respectively.
Page 15

Summary
MDR SDA Current Month 0.000 % Current Month 0.000 % 3 Month Average 0.207 % 3 Month Average 4.004 % 12 Month Average 0.052 % 12 Month Average 1.001 % MDR: Current vs. 12mo Average SDA: Current vs. 12mo Average 0.70% 14.00% 0.60% 12.00% 0.50% 10.00% Current MDR Current SDA 0.40% 12 Month Avg MDR 8.00% 12 Month Avg SDA 0.30% 6.00% 0.20% 4.00% 0.10% 2.00% 0.00% Feb-20 Mar-20 Apr-20 May-20 Jun-20 Jul-20 Aug-20 Sep-20 Oct-20 Nov-20 Dec-20 Jan-21 0.00% Feb-20 Mar-20 Apr-20 May-20 Jun-20 Jul-20 Aug-20 Sep-20 Oct-20 Nov-20 Dec-20 Jan-21 CDR Loss Severity Current Month 0.000 % Current Month (Cumulative) 0.000 % 3 Month Average 2.403 % 3 Month Average (Cumulative) 0.000 % 12 Month Average 0.601 % 12 Month Average (Cumulative) 0.000 % CDR: Current vs. 12mo Average Loss Severity: Current Month (Cumulative) Severity vs. 12mo Average (Cumulative) Severity 500.00% 8.00% 400.00% 7.00% 300.00% 6.00% 200.00% 5.00% Current CDR 100.00% 4.00% 12 Month Avg CDR 0.00% C 12 u r M re o n n t t S h e A v v e g r it S y everity 3.00% -100.00% 2.00% -200.00% 1.00% -300.00% 0.00% Feb-20 Mar-20 Apr-20 May-20 Jun-20 Jul-20 Aug-20 Sep-20 Oct-20 Nov-20 Dec-20 Jan-21 -400.00% -500.00% Feb-20 Mar-20 Apr-20 May-20 Jun-20 Jul-20 Aug-20 Sep-20 Oct-20 Nov-20 Dec-20 Jan-21

--- Page 16 ---

Contact: Customer Service - CTSLink
Deephaven Residential Mortgage Trust
Wells Fargo Bank, N.A.
Mortgage-Backed Notes
Deephaven Residential Mortgage Trust Securities Administration Services
Distribution Date: 25-Jan-2021
8480 Stagecoach Circle
Mortgage-Backed Notes
Frederick, MD 21701-4747
Series 2018-1
www.ctslink.com
20-Jan-2021 02:49:10 PM Telephone: 1-866-846-4526
Prepayment Detail - Prepayments during Current Period
Prepayment Loan Detail - Prepayments during Current Period
Page 16

| Summary |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | Loans Paid in Full |  |  | Repurchased Loans |  |  | Substitution Loans |  |  | Liquidated Loans |  |  | Curtailments |
|  | Count | Original Principal Balance | Current Scheduled Balance | Count | Original Principal Balance | Current Scheduled Balance | Count | Original Principal Balance | Current Scheduled Balance | Count | Original Principal Balance | Current Scheduled Balance | Curtailment Amount |
| Total | 13 | 5,771,890.00 | 5,399,115.06 | 0 | 0.00 | 0.00 | 0 | 0.00 | 0.00 | 0 | 0.00 | 0.00 | 3,112.28 |

| Group | Loan Number | State | LTV at Origination | First Payment Date | Original Principal Balance | Prepayment Amount | PIF Type | Months Delinquent | Current Loan Rate | Original Term | Seasoning |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Summary Summary Summary Summary Summary Summary Summary Summary Summary Summary Summary Summary Summary | 1706500748 1706500778 1706500791 1706500861 1706500952 1707002823 1707800135 1708002886 1708800187 1710003456 1710003638 1710800213 1710800284 | FL CA AZ FL FL CA AZ FL CA NJ AZ CA MD | 80.00 62.68 50.39 75.00 75.00 75.00 80.00 85.00 70.00 80.00 80.00 80.00 80.00 | 01-Oct-2017 01-Oct-2017 01-Oct-2017 01-Nov-2017 01-Dec-2017 01-Sep-2017 01-Aug-2017 01-Oct-2017 01-Oct-2017 01-Dec-2017 01-Jan-2018 01-Aug-2017 01-Nov-2017 | 121,200.00 299,000.00 130,000.00 86,250.00 147,000.00 2,100,000.00 256,000.00 238,340.00 136,500.00 688,000.00 389,600.00 492,000.00 688,000.00 | 112,103.78 285,213.47 124,198.53 41,911.60 139,450.46 1,922,405.55 244,117.02 229,519.59 136,455.11 639,516.94 389,127.92 465,990.15 662,249.03 | Loan Paid in Full Loan Paid in Full Loan Paid in Full Loan Paid in Full Loan Paid in Full Loan Paid in Full Loan Paid in Full Loan Paid in Full Loan Paid in Full Loan Paid in Full Loan Paid in Full Loan Paid in Full Loan Paid in Full | 0 0 0 (1) 5 2 0 (1) 0 0 0 0 1 | 6.625 % 5.750 % 7.515 % 6.500 % 7.990 % 6.250 % 6.000 % 7.375 % 7.750 % 6.500 % 6.375 % 5.375 % 6.750 % | 360 360 360 360 360 360 360 360 360 360 360 360 360 | 39 39 39 38 37 40 41 39 39 37 36 41 38 |

--- Page 17 ---

Contact: Customer Service - CTSLink
Deephaven Residential Mortgage Trust
Wells Fargo Bank, N.A.
Mortgage-Backed Notes
Deephaven Residential Mortgage Trust Securities Administration Services
Distribution Date: 25-Jan-2021
8480 Stagecoach Circle
Mortgage-Backed Notes
Frederick, MD 21701-4747
Series 2018-1
www.ctslink.com
20-Jan-2021 02:49:10 PM Telephone: 1-866-846-4526
Prepayment Penalty Detail - Prepayment Penalty Paid during Current Period
Prepayment Penalty Loan Detail - Prepayment Penalty Paid during Current Period
Page 17

| Summary | Loan Count | Prior Balance | Prepayment Penalty Amount | Prepayment Penalty Waived |
| --- | --- | --- | --- | --- |
| Total | 0 | 0.00 | 0.00 | 0.00 |

| Group | Loan Number | Paid In Full Date | Prior Balance | Prepayment Penalty Amount | Prepayment Penalty Waived |
| --- | --- | --- | --- | --- | --- |
|  |  | No Prepay | ment Penalties this Per | iod |  |

--- Page 18 ---

Contact: Customer Service - CTSLink
Deephaven Residential Mortgage Trust
Wells Fargo Bank, N.A.
Mortgage-Backed Notes
Deephaven Residential Mortgage Trust Securities Administration Services
Distribution Date: 25-Jan-2021
8480 Stagecoach Circle
Mortgage-Backed Notes
Frederick, MD 21701-4747
Series 2018-1
www.ctslink.com
20-Jan-2021 02:49:10 PM Telephone: 1-866-846-4526
Prepayment Rates
Calculation Methodology:
Single Month Mortality (SMM): (Partial and full prepayments + Repurchases) / (Beginning Scheduled Balance - Scheduled Principal)
Conditional PrePayment Rate (CPR): 1 - ((1 - SMM)^12)
PSA Standard Prepayment Model: 100 * CPR / (0.2 * MIN(30,WAS))
Weighted Average Seasoning (WAS): sum((Original Term - Remaining Term)*(Current Scheduled Balance/Deal Scheduled Principal Balance))
Page 18

Summary
SMM CPR PSA Current Month 5.601 % Current Month 49.925 % Current Month 832.083 % 3 Month Average 3.944 % 3 Month Average 37.545 % 3 Month Average 625.751 % 12 Month Average 2.911 % 12 Month Average 28.937 % 12 Month Average 488.903 % CPR: Current vs 12mo Average PSA: Current vs. 12mo Average 50.00% 1000.00% 40.00% 800.00% 30.00% Current CPR 600.00% Current PSA 12mo Average CPR 12mo Average PSA 20.00% 400.00% 10.00% 200.00% 0.00% Feb-20 Mar-20 Apr-20 May-20 Jun-20 Jul-20 Aug-20 Sep-20 Oct-20 Nov-20 Dec-20 Jan-21 0.00% Feb-20 Mar-20 Apr-20 May-20 Jun-20 Jul-20 Aug-20 Sep-20 Oct-20 Nov-20 Dec-20 Jan-21

--- Page 19 ---

Contact: Customer Service - CTSLink
Deephaven Residential Mortgage Trust
Wells Fargo Bank, N.A.
Mortgage-Backed Notes
Deephaven Residential Mortgage Trust Securities Administration Services
Distribution Date: 25-Jan-2021
8480 Stagecoach Circle
Mortgage-Backed Notes
Frederick, MD 21701-4747
Series 2018-1
www.ctslink.com
20-Jan-2021 02:49:10 PM Telephone: 1-866-846-4526
Modification Summary
Delinquencies are classified based on the logic set forth in the governing documents.
If a loan is modified in the first month of the security it is assumed the loan is delinquent.
This summary excludes inactive loans.
Page 19

|  | Loan Count (Numerator) | Loan Count (Denominator) | Loan Count % | Current Scheduled Balance (Numerator) | Current Scheduled Balance (Denominator) | Current Scheduled Balance % |
| --- | --- | --- | --- | --- | --- | --- |
| Number of loans modified within the past 12 months that are currently delinquent (against the total number of loans delinquent within the deal) | 0 | 38 | 0.000 % | 0.00 | 17,662,806.93 | 0.000 % |
| Number of modified loans that have passed the loan modification performance test (against the total number of modified loans) | 0 | 4 | 0.000 % | 0.00 | 837,099.86 | 0.000 % |
| Number of loans modified in the current cycle (against the number of loans within the deal) | 2 | 252 | 0.794 % | 325,565.14 | 90,937,239.05 | 0.358 % |
| Number of modified loans (against the total number of loans within the deal) | 4 | 252 | 1.587 % | 837,099.86 | 90,937,239.05 | 0.921 % |
| Number of loans modified within the last 12 months (against the total number of modified loans within the deal) | 4 | 4 | 100.000 % | 837,099.86 | 837,099.86 | 100.000 % |
| Number of loans modified within the last 12 months (against the total number of loans within the deal) | 4 | 252 | 1.587 % | 837,099.86 | 90,937,239.05 | 0.921 % |
| Number of modified loans that are not currently delinquent after the modification (against the number of modified loans within the deal) | 4 | 4 | 100.000 % | 837,099.86 | 837,099.86 | 100.000 % |
| Number of loans modified in the current cycle that are not currently delinquent (against the number of loans modified in the current cycle) | 2 | 2 | 100.000 % | 325,565.14 | 325,565.14 | 100.000 % |
| Number of loans modified in the current cycle that are currently delinquent (against the number of loans modified in the current cycle) | 0 | 2 | 0.000 % | 0.00 | 325,565.14 | 0.000 % |
| Number of modified loans that were not delinquent at the time of the modification (against the number of loans modified within the deal) | 0 | 4 | 0.000 % | 0.00 | 837,099.86 | 0.000 % |
| Number of modified loans that were delinquent at the time of the modification (against the total number of loans modified within the deal) | 4 | 4 | 100.000 % | 837,099.86 | 837,099.86 | 100.000 % |
| Number of modified Loans (against the total number of loans within the deal as of Cut-off date) | 4 | 744 | 0.538 % | 837,099.86 | 303,863,484.31 | 0.275 % |

--- Page 20 ---

Contact: Customer Service - CTSLink
Deephaven Residential Mortgage Trust
Wells Fargo Bank, N.A.
Mortgage-Backed Notes
Deephaven Residential Mortgage Trust Securities Administration Services
Distribution Date: 25-Jan-2021
8480 Stagecoach Circle
Mortgage-Backed Notes
Frederick, MD 21701-4747
Series 2018-1
www.ctslink.com
20-Jan-2021 02:49:10 PM Telephone: 1-866-846-4526
Modification Detail
All Pre Mod values are from the cycle directly preceding the modification effective date, except for a modification with a prior effective date which will come from the cycle directly preceding the modification approval date.
Total Capitalized Reimbursement Amount is a projected value based upon the adjusted principal at the time of modification.
* This data is currently not provided for reporting.
All Pre Mod values are from the cycle directly preceding the modification effective date, except for a modification with a prior effective date which will come from the cycle directly preceding the modification approval date.
Total Capitalized Reimbursement Amount is a projected value based upon the adjusted principal at the time of modification.
* This data is currently not provided for reporting.
Page 20

| Modification Detail Summary |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Groups | Current |  |  |  |  |  | Cumulative |  |  |  |  |  |
|  | Loan Count | Original Principal Balance | Current Scheduled Balance | Capitalized Amount | Capitalized Reimbursement Amount | Total Forgiveness | Loan Count | Original Principal Balance | Current Scheduled Balance | Capitalized Amount | Capitalized Reimbursement Amount | Total Forgiveness |
| Total | 2 | 321,650.00 | 325,565.14 | 13,075.05 | (14,720.69) | 0.00 | 4 | 826,050.00 | 837,099.86 | 13,075.05 | (36,031.57) | 0.00 |

| Current Month Modification Detail |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Loan Number/ Original Balance | Mod Appr Date/Mod Effective Date | Total Capitalized Amount | Total Capitalized Reimb. Amount | Total Forgiveness | No of Times Loan Modified |  | No of Months Delinq. | Loan Status | Next Due Date | Interest Rate | Payment Amount | Maturity Date | Balloon Amount | Balloon Date | Scheduled Balance |
| 1706002409 | 01/18/2021 |  |  |  |  | Pre Mod | 6 | Loss Mitigation | 06/01/2020 | 7.2 50 | 857.15 | 07/01/2047 | * | * | 121,354.12 |
| 125,650.00 | 01/01/2021 | 66,,228800..6600 | (6,991.35) | * | 1 | Post Mod | 0 | No Action | 01/01/2021 | 7.2 50 | 908.10 | 07/01/2047 | * | * | 128,170.55 |
| 1710800332 | 01/13/2021 |  |  |  |  | Pre Mod | 4 | Loss Mitigation | 08/01/2020 | 7.6 25 | 1,387.28 | 10/01/2047 | * | * | 189,901.79 |
| 196,000.00 | 01/01/2021 | 66,,779944..4455 | (7,729.34) | * | 1 | Post Mod | 0 | No Action | 01/01/2021 | 7.6 25 | 1,443.21 | 10/01/2047 | * | * | 197,394.59 |

| Historical Modification Detail |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Loan Number/ Original Balance | Mod Appr Date/Mod Effective Date | Total Capitalized Amount | Total Capitalized Reimb. Amount | Total Forgiveness | No of Times Loan Modified |  | No of Months Delinq. | Loan Status | Next Due Date | Interest Rate | Payment Amount | Maturity Date | Balloon Amount | Balloon Date | Scheduled Balance |
| 1708003075 | 11/17/2020 |  |  |  |  | Pre Mod | 4 | Loss Mitigation | 06/01/2020 | 7.5 00 | 1,286.75 | 10/01/2047 | * | * | 178,532.75 |
| 182,250.00 | 10/01/2020 | * | (7,576.74) | * | 1 | Post Mod Current Values | 0 0 | No Action No Action | 11/01/2020 01/01/2021 | 9.5 00 9.5 00 | 1,596.98 1,596.98 | 10/01/2047 10/01/2047 | * N/A | * N/A | 185,925.89 185,674.76 |
| 1710003529 | 11/17/2020 |  |  |  |  | Pre Mod | 5 | Loss Mitigation | 05/01/2020 | 7.7 50 | 2,307.92 | 11/01/2047 | * | * | 313,111.02 |
| 322,150.00 | 10/01/2020 | * | (13,734.14) | * | 1 | Post Mod Current Values | 1 0 | No Action No Action | 10/01/2020 01/01/2021 | 7.7 50 7.7 50 | 2,407.41 2,407.41 | 11/01/2047 11/01/2047 | * N/A | * N/A | 326,459.93 325,859.96 |

--- Page 21 ---

Contact: Customer Service - CTSLink
Deephaven Residential Mortgage Trust
Wells Fargo Bank, N.A.
Mortgage-Backed Notes
Deephaven Residential Mortgage Trust Securities Administration Services
Distribution Date: 25-Jan-2021
8480 Stagecoach Circle
Mortgage-Backed Notes
Frederick, MD 21701-4747
Series 2018-1
www.ctslink.com
20-Jan-2021 02:49:10 PM Telephone: 1-866-846-4526
Modified Data Elements
For Additional Footnote information, please see bottom of the Historical Modified Data Elements Detail Section.
If a loan has been modified multiple times, it will be included in the totals for each applicable modification type in the summary sections.
* Loans that are listed in the Modification Detail Section, and are not listed in the Modified Data Elements Section may have been reported prior to November 2008 or incurred one or more ARM Parameter changes.
Page 21

| CURRENT PERIOD SUMMARY | # of Modifications | % of Modifications | Original Principal Balance | % of Original Principal Balance | Current Scheduled Balance | % of Current Scheduled Balance |
| --- | --- | --- | --- | --- | --- | --- |
| Principal Balance, Scheduled P&I | 2 | 100.0000 % | 321,650.00 | 100.0000 % | 325,565.14 | 100.0000 % |
| Total | 2 | 100.0000 % | 321,650.00 | 100.0000 % | 325,565.14 | 100.0000 % |

| CUMULATIVE SUMMARY | # of Modifications | % of Modifications | Original Principal Balance | % of Original Principal Balance | Current Scheduled Balance | % of Current Scheduled Balance |
| --- | --- | --- | --- | --- | --- | --- |
| Interest Rate, Principal Balance, Scheduled P&I | 1 | 25.0000 % | 182,250.00 | 22.0628 % | 185,925.89 | 22.1882 % |
| Principal Balance, Scheduled P&I | 3 | 75.0000 % | 643,800.00 | 77.9372 % | 652,025.07 | 77.8118 % |
| Total | 4 | 100.0000 % | 826,050.00 | 100.0000 % | 837,950.96 | 100.0000 % |

| Current Modified Data Elements Detail |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Loan Number | Modification Approved Date | Modification Effective Date | Other Change(s) | GRM/GPM Modification | Interest Rate Change | Principal Balance Change | Maturity Date Change | Scheduled P&I Change | Balloon Date Change | Balloon Amt Change | ARM to Fixed Change | Fixed To ARM Change | IO To Fully Amortizing Change | Fully Amortizing To IO Change | Streamlined Modification |
| 1706002409 | 01/18/2021 | 01/01/2021 |  |  |  | X |  | X |  |  |  |  |  |  |  |
| 1710800332 | 01/13/2021 | 01/01/2021 |  |  |  | X |  | X |  |  |  |  |  |  |  |

| Historical Modified Data Elements Detail |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Loan Number | Modification Approved Date | Modification Effective Date | Other Change(s) | GRM/GPM Modification | Interest Rate Change | Principal Balance Change | Maturity Date Change | Scheduled P&I Change | Balloon Date Change | Balloon Amt Change | ARM to Fixed Change | Fixed To ARM Change | IO To Fully Amortizing Change | Fully Amortizing To IO Change | Streamlined Modification |
| 1708003075 | 11/17/2020 | 10/01/2020 |  |  | X | X |  | X |  |  |  |  |  |  |  |
| 1710003529 | 11/17/2020 | 10/01/2020 |  |  |  | X |  | X |  |  |  |  |  |  |  |

--- Page 22 ---

Contact: Customer Service - CTSLink
Deephaven Residential Mortgage Trust
Wells Fargo Bank, N.A.
Mortgage-Backed Notes
Deephaven Residential Mortgage Trust Securities Administration Services
Distribution Date: 25-Jan-2021
8480 Stagecoach Circle
Mortgage-Backed Notes
Frederick, MD 21701-4747
Series 2018-1
www.ctslink.com
20-Jan-2021 02:49:10 PM Telephone: 1-866-846-4526
Future Modifications
Page 22

| Future Modification Summary |  |  |  |
| --- | --- | --- | --- |
| Groups | Loan Count | Original Principal Balance | Current Scheduled Balance |
| Total | 0 | 0.00 | 0.00 |

| Future Modification Detail |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Loan Number | Original Principal Balance | Modification Approved Date/ Modification Effective Date | Previously Modified |  | No of Months Delinq. | Loan Status | Next Due Date | Interest Rate | Payment Amount | Maturity Date | Balloon Amount | Balloon Date | Current Sched Balance/Modified Beginning Balance |
|  |  |  |  | N | o Future | Modifications this | Period |  |  |  |  |  |  |

--- Page 23 ---

Contact: Customer Service - CTSLink
Deephaven Residential Mortgage Trust
Wells Fargo Bank, N.A.
Mortgage-Backed Notes
Deephaven Residential Mortgage Trust Securities Administration Services
Distribution Date: 25-Jan-2021
8480 Stagecoach Circle
Mortgage-Backed Notes
Frederick, MD 21701-4747
Series 2018-1
www.ctslink.com
20-Jan-2021 02:49:10 PM Telephone: 1-866-846-4526
Balance Methodology:
IB: Interest Bearing
NIB: Non-Interest Bearing
NIB Non-Loss Balance: current balance of NIB amounts that were not treated as a loss at the time of the related modification
Trust Balance = IB Balance + NIB Non-Loss Balance
NIB Loss Balance: current balance of NIB amounts that were treated as a loss at the time of the related modification
TDO: Total Debt Owed = IB Balance + NIB Non-Loss Balance + NIB Loss Balance
NOTE: ** See Information Regarding Collateral Balance Detail Reporting and Non-Interest Bearing Detail set forth in the Supplemental Reporting below.
Page 23

Collateral Balance Detail
Group Total Begining Scheduled Balance: IB 96,430,917.17 Beginning NIB Non-Loss Balance 0.00 Beginning Scheduled Balance: Trust 96,430,917.17 Beginning NIB Loss Balance 0.00 Beginning Scheduled Balance: TDO 96,430,917.17 Ending Scheduled Balance: IB 90,937,239.05 Ending NIB Non-Loss Balance 0.00 Ending Scheduled Balance: Trust 90,937,239.05 Ending NIB Loss Balance 0.00 Ending Scheduled Balance: TDO 90,937,239.05 Ending Actual Balance: IB 91,067,347.92 Ending NIB Non-Loss Balance 0.00 Ending Actual Balance: Trust 91,067,347.92 Ending NIB Loss Balance 0.00 Ending Actual Balance: TDO 91,067,347.92

--- Page 24 ---

Contact: Customer Service - CTSLink
Deephaven Residential Mortgage Trust
Wells Fargo Bank, N.A.
Mortgage-Backed Notes
Deephaven Residential Mortgage Trust Securities Administration Services
Distribution Date: 25-Jan-2021
8480 Stagecoach Circle
Mortgage-Backed Notes
Frederick, MD 21701-4747
Series 2018-1
www.ctslink.com
20-Jan-2021 02:49:10 PM Telephone: 1-866-846-4526
Page 24

Non-Interest Bearing Detail Summary Deferred Principal Principal Reduction Alternative Total NIB Count Curtailments Count PIF/Liquidation Count Ending Balance Count PIF/Liquidation Count Ending Balance Count Ending Balance Total -NONLOSS 0 0.00 0 0.00 0 0.00 0 0.00 0 0.00 0 0.00 Total -LOSS 0 0.00 0 0.00 0 0.00 0 0.00 0 0.00 0 0.00
Loan Level Deferred Principal Principal Reduction Alternative Total NIB Modification Modification Paid in Full/ Paid in Full/ Group Treatment Loan Number Effective Date Approval Date Curtailments Liquidation Ending Balance Liquidation Ending Balance Ending Balance No Non-Interest Bearing Balances this period

| Summary |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | Deferred Principal |  |  |  |  |  | Principal Reduction Alternative |  |  |  | Total NIB |  |
|  | Count | Curtailments | Count | PIF/Liquidation | Count | Ending Balance | Count | PIF/Liquidation | Count | Ending Balance | Count | Ending Balance |
| Total -NONLOSS | 0 | 0.00 | 0 | 0.00 | 0 | 0.00 | 0 | 0.00 | 0 | 0.00 | 0 | 0.00 |
| Total -LOSS | 0 | 0.00 | 0 | 0.00 | 0 | 0.00 | 0 | 0.00 | 0 | 0.00 | 0 | 0.00 |

| Loan Level |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  | Deferred Principal |  |  | Principal Reduction Alternative |  | Total NIB |
| Group | Treatment | Loan Number | Modification Effective Date | Modification Approval Date | Curtailments | Paid in Full/ Liquidation | Ending Balance | Paid in Full/ Liquidation | Ending Balance | Ending Balance |
|  |  |  |  | No Non-Inter | est Bearing Ba | lances this peri | od |  |  |  |

--- Page 25 ---

Contact: Customer Service - CTSLink
Deephaven Residential Mortgage Trust
Wells Fargo Bank, N.A.
Mortgage-Backed Notes
Deephaven Residential Mortgage Trust Securities Administration Services
Distribution Date: 25-Jan-2021
8480 Stagecoach Circle
Mortgage-Backed Notes
Frederick, MD 21701-4747
Series 2018-1
www.ctslink.com
20-Jan-2021 02:49:10 PM Telephone: 1-866-846-4526
Supplemental Non-Interest Bearing Detail Report
No Supplemental Non-Interest Bearing Balances this period
Page 25

|  |  |  |  | Deferred Principal |  |  | Principal Reduction Alternative |  | Total NIB |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Group | Treatment | Loan Number | Modification Effective Date | Curtailments | Paid In Full/ Liquidation | Ending Balance | Paid In Full/ Liquidation | Ending Balance | Ending Balance |

--- Page 26 ---

Contact: Customer Service - CTSLink
Deephaven Residential Mortgage Trust
Wells Fargo Bank, N.A.
Mortgage-Backed Notes
Deephaven Residential Mortgage Trust Securities Administration Services
Distribution Date: 25-Jan-2021
8480 Stagecoach Circle
Mortgage-Backed Notes
Frederick, MD 21701-4747
Series 2018-1
www.ctslink.com
20-Jan-2021 02:49:10 PM Telephone: 1-866-846-4526
Page 26

Substitutions
Loans Repurchased Loans Substituted Current Current Loan Scheduled Current Current Loan Scheduled Current Current Number Balance Rate Payment Number Balance Rate Payment
No Substitutions this Period

Repurchases Due to Breaches
Beginning Loan Scheduled Payoff Current Current Number Balance Balance Rate Payment
No Repurchases Due to Breaches this Period

Repurchases Due To Other
Beginning Loan Scheduled Payoff Current Current Number Balance Balance Rate Payment
No Repurchases Due to Other this Period

--- Page 27 ---

Contact: Customer Service - CTSLink
Deephaven Residential Mortgage Trust
Wells Fargo Bank, N.A.
Mortgage-Backed Notes
Deephaven Residential Mortgage Trust Securities Administration Services
Distribution Date: 25-Jan-2021
8480 Stagecoach Circle
Mortgage-Backed Notes
Frederick, MD 21701-4747
Series 2018-1
www.ctslink.com
20-Jan-2021 02:49:10 PM Telephone: 1-866-846-4526
Interest Rate Stratification
Page 27

|  | Summary |
| --- | --- |
|  | Number Outstanding Percentage Of Scheduled Of Loans Balance($) Balance(%) |
| < 0.000 0.000 0.499 0.500 0.999 1.000 1.499 1.500 1.999 2.000 2.499 2.500 2.999 3.000 3.499 3.500 3.999 4.000 4.499 4.500 4.999 5.000 5.499 5.500 5.999 6.000 6.499 6.500 6.999 7.000 7.499 7.500 7.999 8.000 8.499 8.500 8.999 9.000 9.499 9.500 9.999 >= 10.000 Total | 0 0.00 0.000 0 0.00 0.000 0 0.00 0.000 0 0.00 0.000 0 0.00 0.000 0 0.00 0.000 0 0.00 0.000 0 0.00 0.000 0 0.00 0.000 0 0.00 0.000 3 3,120,249.26 3.431 7 3,300,816.81 3.630 28 15,731,526.00 17.299 41 13,618,955.31 14.976 72 27,575,768.75 30.324 23 5,811,317.27 6.390 41 14,876,861.53 16.359 17 3,208,424.14 3.528 14 2,829,841.64 3.112 3 396,372.36 0.436 3 467,105.98 0.514 0 0.00 0.000 |
|  | 252 90,937,239.05 100.000 |

--- Page 28 ---

Contact: Customer Service - CTSLink
Deephaven Residential Mortgage Trust
Wells Fargo Bank, N.A.
Mortgage-Backed Notes
Deephaven Residential Mortgage Trust Securities Administration Services
Distribution Date: 25-Jan-2021
8480 Stagecoach Circle
Mortgage-Backed Notes
Frederick, MD 21701-4747
Series 2018-1
www.ctslink.com
20-Jan-2021 02:49:10 PM Telephone: 1-866-846-4526
Supplemental Reporting
Page 28

Accrual Period
For each Payment Date, the calendar month immediately preceding the month in which the Payment Date occurs. Interest will be calculated on the basis of a 360-day year consisting of twelve 30-day months.

Payment Date
The 25th day of each month, or the immediately following Business Day if the 25th day is not a Business Day, commencing in February 2018.

Closing Date
January 31, 2018.

Business Day
Any day other than a Saturday, a Sunday or a day on which banking institutions in the State of California, the State of New York, the State of North Carolina, the State of Delaware or in any city in which the Corporate Trust Office is located are authorized or obligated by law, executive order or government decree to be closed.

Information Relating to Forbearance Modification Reporting
Wells Fargo's practice, as master servicer, securities administrator or trustee, is to report and allocate principal forborne in connection with mortgage loan modifications ("Forborne Principal") as losses or non-losses, including mortgage loan modifications made pursuant to the Home Affordability Modification Program, as explicitly and clearly reported to Wells Fargo by the servicer of the modified loan. From time to time, Wells Fargo may receive information from a servicer that revises or clarifies the servicer's intent about its treatment of Forborne Principal ("Supplemental Servicer Reporting"). If this occurs, Wells Fargo's practice is to revise its reporting of Forborne Principal to conform to the Supplemental Servicer Reporting. This may result in the recognition and allocation of Forborne Principal as a loss after the modification date of a mortgage loan by the servicer or the reversal of a prior recognition and allocation of Forborne Principal as a loss. Reclassification of Forborne Principal Wells Fargo's practice is to classify, or reclassify, Forborne Principal on the first distribution date on which it is reasonably practicable to do so after Wells Fargo determines that it has received the Supplemental Servicer Reporting, which, due to the time and effort necessary to review, verify, and process such Supplemental Servicer Reporting, may be several reporting periods after Wells Fargo determines that it has received such reporting (such distribution date, the "Target Reporting Date").

--- Page 29 ---

Contact: Customer Service - CTSLink
Deephaven Residential Mortgage Trust
Wells Fargo Bank, N.A.
Mortgage-Backed Notes
Deephaven Residential Mortgage Trust Securities Administration Services
Distribution Date: 25-Jan-2021
8480 Stagecoach Circle
Mortgage-Backed Notes
Frederick, MD 21701-4747
Series 2018-1
www.ctslink.com
20-Jan-2021 02:49:10 PM Telephone: 1-866-846-4526
Supplemental Reporting
Page 29

Information Relating to Forbearance Modification Reporting (continued)
Restatement of Distribution Reports to Loan Modification Date Wells Fargo will not restate distribution reports to reflect losses or gains attributable to Forborne Principal as of the date the servicer modified the loan if the Target Reporting Date is later than the normal reporting cycle for monthly servicer activities. Restatement to Target Reporting Date In certain circumstances, Wells Fargo may restate distribution reports from the Target Reporting Date if Wells Fargo determines that it did not apply Forborne Principal in the manner specified in the Supplemental Servicer Reporting on the Target Reporting Date. Wells Fargo's practice is to restate previous distribution reports to the Target Reporting Date only if the restatement would have a significant impact on cash distributions to any class of certificates after the Target Reporting Date. If Wells Fargo determines that restating previous distribution reports to the Target Reporting Date would have a significant impact on cash distributions to any class of certificates after the Target Reporting Date, then Wells Fargo's practice is to restate the distribution reports to the Target Reporting Date and include additional footnoting or reporting describing the restatement.

Information Regarding Collateral Balance Detail Reporting
As a result of a reporting limitation, the Collateral Balance Detail section of this Distribution Report does not include information about any Current Non-Loss Modifications. As a result, "Ending Scheduled Balance: IB" and "Ending Actual Balance: IB" are overstated by the amount of the Current Non-Loss Modifications, and "Ending NIB Non-Loss Balance" is understated by the amount of the Current Non-Loss Modifications. Loan-level information regarding the Current Non-Loss Modifications is provided in the Supplemental Non-Interest Bearing Detail Report set forth herein. Wells Fargo is in the process of addressing this reporting limitation.

Information Regarding Non-Interest Bearing Detail Reporting
Wells Fargo has identified reporting limitations related to loans that (1) are now being reported by the relevant servicer as subject to certain forbearance modifications or deferments but where the servicer is not reporting a collateral loss for such modifications or deferments (the "Current Non-Loss Modifications"), and (2) have prior reported non-interest-bearing balances resulting from prior loan modifications that were treated as a loss. The Summary and Loan Level Non-Interest Bearing Detail does not include information about the Current Non-Loss Modifications. Loan-level information regarding the Current Non-Loss Modifications is provided in the Supplemental Non-Interest Bearing Detail Report set forth herein. Wells Fargo is in the process of addressing this reporting limitation.