--- Page 1 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 25-Oct-2022
18-Oct-2022 7:55:21 PM
This document is provided by Computershare Trust Company, N.A., or one or more of its affiliates (collectively, "Computershare"), in its named capacity or as agent of or successor to Wells Fargo Bank, N.A., or
one or more of its affiliates ("Wells Fargo"), by virtue of the acquisition by Computershare of substantially all the assets of the corporate trust services business of Wells Fargo. This report is compiled by
Computershare Trust Company, N.A. from information provided by third parties. Computershare Trust Company, N.A. has not independently confirmed the accuracy of the information.
All Record Dates are based upon the governing documents and logic set forth as of closing.
© 2021 Computershare. All rights reserved. Confidential. Page 1 of 29

MFA Financial, Inc.
Mortgage Pass-Through Certificates
Series 2021-NV1

| Certificateholder Distribution Summary |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Class | CUSIP | Record Date | Certificate Pass- Through Rate | Beginning Certificate Balance | Interest Distribution | Principal Distribution | Current Realized Loss/Write Down | Ending Certificate Balance | Total Distribution | Cumulative Realized Losses/Write Down |
| A-1 | 552747AA5 | 09/30/2022 | 0.85200 % | 60,668,560.33 | 43,074.68 | 1,058,282.25 | 0.00 | 59,610,278.08 | 1,101,356.93 | 0.00 |
| A-2 | 552747AB3 | 09/30/2022 | 1.05700 % | 5,623,902.72 | 4,953.72 | 95,923.11 | 0.00 | 5,527,979.61 | 100,876.83 | 0.00 |
| A-3 | 552747AC1 | 09/30/2022 | 1.26200 % | 8,192,735.34 | 8,616.03 | 139,737.95 | 0.00 | 8,052,997.38 | 148,353.98 | 0.00 |
| M-1 | 552747AD9 | 09/30/2022 | 2.28800 % | 7,394,000.00 | 14,097.89 | 0.00 | 0.00 | 7,394,000.00 | 14,097.89 | 0.00 |
| B-1 | 552747AE7 | 09/30/2022 | 3.29200 % | 7,613,000.00 | 20,885.00 | 0.00 | 0.00 | 7,613,000.00 | 20,885.00 | 0.00 |
| B-2 | 552747AF4 | 09/30/2022 | 4.29200 % | 8,699,000.00 | 31,113.42 | 0.00 | 0.00 | 8,699,000.00 | 31,113.42 | 0.00 |
| B-3 | 552747AG2 | 09/30/2022 | 6.14206 % | 10,875,114.00 | 55,663.00 | 0.00 | 0.00 | 10,875,114.00 | 55,663.00 | 0.00 |
| A-IO-S | 552747AH0 | 09/30/2022 | 0.14327 % | 0.00 | 13,022.11 | 0.00 | 0.00 | 0.00 | 13,022.11 | 0.00 |
| XS | 552747AJ6 | 09/30/2022 | 4.17924 % | 0.00 | 396,589.38 | 0.00 | 0.00 | 0.00 | 396,589.38 | 0.00 |
| R | 552747AK3 | 09/30/2022 | 0.00000 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| Totals |  |  |  | 109,066,312.39 | 588,015.23 | 1,293,943.31 | 0.00 | 107,772,369.07 | 1,881,958.54 | 0.00 |

--- Page 2 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 25-Oct-2022
18-Oct-2022 7:55:21 PM
© 2021 Computershare. All rights reserved. Confidential. Page 2 of 29

MFA Financial, Inc.
Mortgage Pass-Through Certificates
Series 2021-NV1

| Principal Distribution Statement |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Class | Original Face Amount | Beginning Certificate Balance | Scheduled Principal Distribution | Unscheduled Principal Distribution | Accretion | Realized Loss/Write Down | Total Principal Reduction | Ending Certificate Balance | Ending Certificate Percentage | Total Principal Distribution |
| A-1 | 148,980,000.00 | 60,668,560.33 | 0.00 | 1,058,282.25 | 0.00 | 0.00 | 1,058,282.25 | 59,610,278.08 | 0.40012269 | 1,058,282.25 |
| A-2 | 13,810,000.00 | 5,623,902.72 | 0.00 | 95,923.11 | 0.00 | 0.00 | 95,923.11 | 5,527,979.61 | 0.40028817 | 95,923.11 |
| A-3 | 20,118,000.00 | 8,192,735.34 | 0.00 | 139,737.95 | 0.00 | 0.00 | 139,737.95 | 8,052,997.38 | 0.40028817 | 139,737.95 |
| M-1 | 7,394,000.00 | 7,394,000.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 7,394,000.00 | 1.00000000 | 0.00 |
| B-1 | 7,613,000.00 | 7,613,000.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 7,613,000.00 | 1.00000000 | 0.00 |
| B-2 | 8,699,000.00 | 8,699,000.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 8,699,000.00 | 1.00000000 | 0.00 |
| B-3 | 10,875,114.00 | 10,875,114.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 10,875,114.00 | 1.00000000 | 0.00 |
| A-IO-S | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| XS | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| R | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| Totals | 217,489,114.00 | 109,066,312.39 | 0.00 | 1,293,943.31 | 0.00 | 0.00 | 1,293,943.31 | 107,772,369.07 | 0.49552995 | 1,293,943.31 |

--- Page 3 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 25-Oct-2022
18-Oct-2022 7:55:21 PM
(1) Amount also includes Coupon Cap or Basis Risk Shortfalls, if applicable.
© 2021 Computershare. All rights reserved. Confidential. Page 4 of 29

MFA Financial, Inc.
Mortgage Pass-Through Certificates
Series 2021-NV1

Interest Distribution Statement

| Class | Accrual Dates | Accrual Days | Current Certificate Rate | Beginning Certificate/Notional Balance | Current Accrued Interest | Payment of Unpaid Interest Shortfall(1) | Basis Risk Shortfall | Interest Shortfall | Non- Supported Interest Shortfall | Total Interest Distribution | Remaining Unpaid Interest Shortfall(1) | Ending Certificate/ Notional Balance |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| A-1 | 09/01/22 - 09/30/22 | 30 | 0.85200 % | 60,668,560.33 | 43,074.68 | 0.00 | 0.00 | 0.00 | 0.00 | 43,074.68 | 0.00 | 59,610,278.08 |
| A-2 | 09/01/22 - 09/30/22 | 30 | 1.05700 % | 5,623,902.72 | 4,953.72 | 0.00 | 0.00 | 0.00 | 0.00 | 4,953.72 | 0.00 | 5,527,979.61 |
| A-3 | 09/01/22 - 09/30/22 | 30 | 1.26200 % | 8,192,735.34 | 8,616.03 | 0.00 | 0.00 | 0.00 | 0.00 | 8,616.03 | 0.00 | 8,052,997.38 |
| M-1 | 09/01/22 - 09/30/22 | 30 | 2.28800 % | 7,394,000.00 | 14,097.89 | 0.00 | 0.00 | 0.00 | 0.00 | 14,097.89 | 0.00 | 7,394,000.00 |
| B-1 | 09/01/22 - 09/30/22 | 30 | 3.29200 % | 7,613,000.00 | 20,885.00 | 0.00 | 0.00 | 0.00 | 0.00 | 20,885.00 | 0.00 | 7,613,000.00 |
| B-2 | 09/01/22 - 09/30/22 | 30 | 4.29200 % | 8,699,000.00 | 31,113.42 | 0.00 | 0.00 | 0.00 | 0.00 | 31,113.42 | 0.00 | 8,699,000.00 |
| B-3 | 09/01/22 - 09/30/22 | 30 | 6.14206 % | 10,875,114.00 | 55,663.00 | 0.00 | 0.00 | 0.00 | 0.00 | 55,663.00 | 0.00 | 10,875,114.00 |
| A-IO-S | 09/01/22 - 09/30/22 | 30 | 0.14327 % | 109,070,000.35 | 13,022.11 | 0.00 | 0.00 | 0.00 | 0.00 | 13,022.11 | 0.00 | 107,787,328.79 |
| XS | 09/01/22 - 09/30/22 | 30 | 4.17924 % | 109,070,000.35 | 379,858.29 | 0.00 | 0.00 | 0.00 | 0.00 | 396,589.38 | 0.00 | 107,787,328.79 |
| R | N/A | N/A | 0.00000 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| Totals |  |  |  |  | 571,284.14 | 0.00 | 0.00 | 0.00 | 0.00 | 588,015.23 | 0.00 |  |

--- Page 4 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 25-Oct-2022
18-Oct-2022 7:55:21 PM
(1) Amount also includes Coupon Cap or Basis Risk Shortfalls, if applicable.
NOTE: All classes per $1,000 denomination.
© 2021 Computershare. All rights reserved. Confidential. Page 5 of 29

MFA Financial, Inc.
Mortgage Pass-Through Certificates
Series 2021-NV1

Interest Distribution Factors Statement

| Class | Original Face Amount | Current Certificate Rate | Beginning Certificate/Notional Balance | Current Accrued Interest | Payment of Unpaid Interest Shortfall(1) | Basis Risk Shortfall | Interest Shortfall | Non- Supported Interest Shortfall | Total Interest Distribution | Remaining Unpaid Interest Shortfall(1) | Ending Certificate/ Notional Balance |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| A-1 | 148,980,000.00 | 0.85200 % | 407.22620707 | 0.28913062 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.28913062 | 0.00000000 | 400.12268815 |
| A-2 | 13,810,000.00 | 1.05700 % | 407.23408545 | 0.35870529 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.35870529 | 0.00000000 | 400.28816872 |
| A-3 | 20,118,000.00 | 1.26200 % | 407.23408589 | 0.42827468 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.42827468 | 0.00000000 | 400.28816880 |
| M-1 | 7,394,000.00 | 2.28800 % | 1000.00000000 | 1.90666622 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 1.90666622 | 0.00000000 | 1000.00000000 |
| B-1 | 7,613,000.00 | 3.29200 % | 1000.00000000 | 2.74333377 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 2.74333377 | 0.00000000 | 1000.00000000 |
| B-2 | 8,699,000.00 | 4.29200 % | 1000.00000000 | 3.57666628 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 3.57666628 | 0.00000000 | 1000.00000000 |
| B-3 | 10,875,114.00 | 6.14206 % | 1000.00000000 | 5.11838313 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 5.11838313 | 0.00000000 | 1000.00000000 |
| A-IO-S | 0.00 | 0.14327 % | 501.49636616 | 0.05987477 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.05987477 | 0.00000000 | 495.59873047 |
| XS | 0.00 | 4.17924 % | 501.49636616 | 1.74656231 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 1.82349072 | 0.00000000 | 495.59873047 |
| R | 0.00 | 0.00000 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 |

--- Page 5 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 25-Oct-2022
18-Oct-2022 7:55:21 PM
Certificateholder Account Statement
*Servicer Payees include: FAY SERVICING, LLC; LIMA ONE CAPITAL, LLC
© 2021 Computershare. All rights reserved. Confidential. Page 6 of 29

MFA Financial, Inc.
Mortgage Pass-Through Certificates
Series 2021-NV1

CERTIFICATE ACCOUNT
Beginning Balance 0.00 Deposits Payments of Interest and Principal 1,903,874.42 Reserve Funds and Credit Enhancements 0.00 Proceeds from Repurchased Loans 0.00 Gains & Subsequent Recoveries (Realized Losses) (23,499.59) Total Deposits 1,880,374.83 Withdrawals Reserve Funds and Credit Enhancements 0.00 Total Administration Fees 38,130.29 Payment of Interest and Principal 1,842,244.54 Total Withdrawals (Pool Distribution Amount) 1,880,374.83 Ending Balance 0.00

PREPAYMENT/CURTAILMENT INTEREST SHORTFALL
Total Prepayment/Curtailment Interest Shortfall 0.00 Servicing Fee Support 0.00 Non-Supported Prepayment/Curtailment Interest Shortfall 0.00

| ADMINISTRATION FEES |  |  |
| --- | --- | --- |
| Gross Servicing Fee* 0.00 Aggregate Servicing Fee-Fay Servicing, Lima One Capital 31,503.46 Custodian Fee – Wells Fargo Bank, N.A. 1,293.50 Loan Data Agent Fee – DV01, Inc. 2,000.00 Securities Administration Fee – Wells Fargo Bank, N.A. 2,500.00 Trustee Fee - Wilmington Savings Fund Society, FSB 833.33 Supported Prepayment/Curtailment Interest Shortfall 0.00 |  |  |
| Total Administration Fees | 38,130.29 |  |

| Reserve and Guaranty Funds |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
| Account Name | Beginning Balance | Deposit of Reinvestment Income | Current Deposits | Current Withdrawals | Ending Balance |
| Cap Carryover Reserve Account | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| Interest Reserve Account | 285,993.68 | 0.00 | 239,652.85 | 285,993.68 | 239,652.85 |

--- Page 6 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 25-Oct-2022
18-Oct-2022 7:55:21 PM
Collateral Statement
NOTE: The Collateral Balances shown are Trust Balances unless otherwise designated.
© 2021 Computershare. All rights reserved. Confidential. Page 7 of 29

MFA Financial, Inc.
Mortgage Pass-Through Certificates
Series 2021-NV1

| Group | Total |  |
| --- | --- | --- |
| Collateral Description | Mixed Fixed & Arm |  |
| Weighted Average Coupon Rate | 6.503112 |  |
| Weighted Average Net Rate | 6.503112 |  |
| Weighted Average Pass-Through Rate | 6.503112 |  |
| Weighted Average Remaining Term | 320 |  |
| Principal and Interest Constant | 730,299.47 |  |
| Beginning Loan Count | 767 |  |
| Loans Paid in Full | 7 |  |
| Ending Loan Count | 760 |  |
| Beginning Actual Balance | 109,070,000.35 |  |
| Actual Ending Collateral Balance | 107,787,328.79 |  |
| Scheduled Principal | 139,220.79 |  |
| Unscheduled Principal | 1,143,450.77 |  |
| Negative Amortized Principal | 0.00 |  |
| Interest Received | 0.00 |  |
| Actual Interest | 591,078.68 |  |
| Servicing Fees | 0.00 |  |
| Master Servicing Fees | 0.00 |  |
| Trustee Fee | 0.00 |  |
| Special Hazard Fee | 0.00 |  |
| Other Fee | 0.00 |  |
| Net Interest | 591,078.68 |  |
| Realized Loss Amount | 23,499.59 |  |
| Cumulative Realized Loss | (3,196.10) |  |
| Percentage of Cumulative Losses | (0.0015) |  |
| Special Servicing Fee | 0.00 |  |

--- Page 7 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 25-Oct-2022
18-Oct-2022 7:55:21 PM
Additional Reporting - Deal Level
© 2021 Computershare. All rights reserved. Confidential. Page 8 of 29

MFA Financial, Inc.
Mortgage Pass-Through Certificates
Series 2021-NV1

| Cash Reporting |  |
| --- | --- |
| Interest Remittance Amount | 821,414.47 |
| Principal Remittance Amount | 1,270,443.72 |
| Monthly Excess Cashflow | 643,010.73 |
| Servicing Advances Made | 251,714.57 |
| Servicing Advances Reimbursed | 1,911.90 |
| Servicing Advances Outstanding | 249,802.67 |
| Excess of Servicing Advances over the Aggregate Excess Servicing Strip | 249,802.67 |
| Pre-Closing Deferred Amounts Distributed to Class XS Certificates | 0.00 |
| Indemnification Amounts Paid to Securities Administrator | 0.00 |
| Indemnification Amounts Paid to Trustee | 0.00 |
| Indemnification Amounts Paid to Servicer - Fay Servicing, LLC | 0.00 |
| Indemnification Amounts Paid to Servicer - Lima One Capital, LLC | 0.00 |
| Indemnification Amounts Paid to Servicing Administrator | 0.00 |
| Indemnification Amounts Paid to Controlling Holder | 0.00 |
| Indemnification Amounts Paid to Loan Data Agent | 0.00 |
| Indemnification Amounts Paid to Custodian | 0.00 |
| Transaction Expenses Paid to Securities Administrator | 0.00 |
| Transaction Expenses Paid to Trustee | 0.00 |
| Transaction Expenses Paid to Servicer - Fay Servicing, LLC | 0.00 |
| Transaction Expenses Paid to Servicer - Lima One Capital, LLC | 0.00 |
| Transaction Expenses Paid to Servicing Administrator | 0.00 |
| Transaction Expenses Paid to Controlling Holder | 0.00 |
| Transaction Expenses Paid to Loan Data Agent | 0.00 |
| Transaction Expenses Paid to Custodian | 0.00 |
| Informational Reporting |  |
| Forborne Payments Amounts | 0.00 |
| Aggregate UPB of Mortgage Loans Subject to a Forbearance Plan | 0.00 |
| Percentage of Mortgage Loans Subject to a Forbearance Plan | 0.000000% |
| Pre-Closing Deferred Amounts | 4,390.95 |
| Aggregate UPB of Mortgage Loans Subject to a Deferral | 0.00 |
| Percentage of Mortgage Loans Subject to a Deferral | 0.000000% |
| Structural Reporting |  |
| Net WAC Rate | 6.142060% |
| Class A-1 Cap Carryover Amount | 0.00 |
| Class A-2 Cap Carryover Amount | 0.00 |
| Class A-3 Cap Carryover Amount | 0.00 |

--- Page 8 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 25-Oct-2022
18-Oct-2022 7:55:21 PM
Additional Reporting - Deal Level
© 2021 Computershare. All rights reserved. Confidential. Page 9 of 29

MFA Financial, Inc.
Mortgage Pass-Through Certificates
Series 2021-NV1

| Structural Reporting |  |
| --- | --- |
| Class M-1 Cap Carryover Amount | 0.00 |
| Class B-1 Cap Carryover Amount | 0.00 |
| Class B-2 Cap Carryover Amount | 0.00 |
| Trigger Event Reporting |  |
| Cumulative Loss Trigger Event | Pass |
| Delinquency Loss Trigger Event | Pass |

--- Page 9 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 25-Oct-2022
18-Oct-2022 7:55:21 PM
Delinquency Status - MBA Delinquency Calculation Method
Please refer to CTSLink.com for a list of delinquency code descriptions.
Current Period Class A Insufficient Funds 0.00 Principal Balance of Contaminated Properties 0.00 Periodic Advance 4,354.27
© 2021 Computershare. All rights reserved. Confidential. Page 10 of 29

MFA Financial, Inc.
Mortgage Pass-Through Certificates
Series 2021-NV1

| DELINQUENT |  |  | BANKRUPTCY |  |  | FORECLOSURE |  |  | REO |  |  | TOTAL |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | No. of Loans | Actual Balance |  | No. of Loans | Actual Balance |  | No. of Loans | Actual Balance |  | No. of Loans | Actual Balance |  | No. of Loans | Actual Balance |
|  |  |  | 0-29 Days | 2 | 155,806.06 | 0-29 Days | 0 | 0.00 | 0-29 Days | 0 | 0.00 | 0-29 Days | 2 | 155,806.06 |
| 30 Days | 20 | 1,945,135.40 | 30 Days | 0 | 0.00 | 30 Days | 0 | 0.00 | 30 Days | 0 | 0.00 | 30 Days | 20 | 1,945,135.40 |
| 60 Days | 4 | 612,802.88 | 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 | 60 Days | 4 | 612,802.88 |
| 90 Days | 3 | 317,144.50 | 90 Days | 0 | 0.00 | 90 Days | 0 | 0.00 | 90 Days | 0 | 0.00 | 90 Days | 3 | 317,144.50 |
| 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 |
| 150 Days | 0 | 0.00 | 150 Days | 0 | 0.00 | 150 Days | 0 | 0.00 | 150 Days | 0 | 0.00 | 150 Days | 0 | 0.00 |
| 180+ Days | 3 | 289,114.46 | 180+ Days | 0 | 0.00 | 180+ Days | 0 | 0.00 | 180+ Days | 0 | 0.00 | 180+ Days | 3 | 289,114.46 |
| 30 3,164,197.24 |  |  | 2 155,806.06 |  |  | 0 0.00 |  |  | 0 0.00 |  |  | 32 3,320,003.30 |  |  |
|  |  |  | 0-29 Days | 0.263158 % | 0.144550 % | 0-29 Days | 0.000000 % | 0.000000 % | 0-29 Days | 0.000000 % | 0.000000 % | 0-29 Days | 0.263158 % | 0.144550 % |
| 30 Days | 2.631579 % | 1.804605 % | 30 Days | 0.000000 % | 0.000000 % | 30 Days | 0.000000 % | 0.000000 % | 30 Days | 0.000000 % | 0.000000 % | 30 Days | 2.631579 % | 1.804605 % |
| 60 Days | 0.526316 % | 0.568530 % | 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.526316 % | 0.568530 % |
| 90 Days | 0.394737 % | 0.294232 % | 90 Days | 0.000000 % | 0.000000 % | 90 Days | 0.000000 % | 0.000000 % | 90 Days | 0.000000 % | 0.000000 % | 90 Days | 0.394737 % | 0.294232 % |
| 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % |
| 150 Days | 0.000000 % | 0.000000 % | 150 Days | 0.000000 % | 0.000000 % | 150 Days | 0.000000 % | 0.000000 % | 150 Days | 0.000000 % | 0.000000 % | 150 Days | 0.000000 % | 0.000000 % |
| 180+ Days | 0.394737 % | 0.268227 % | 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 0.394737 % | 0.268227 % |
| 3.947368 % 2.935593 % |  |  | 0.263158 % 0.144550 % |  |  | 0.000000 % 0.000000 % |  |  | 0.000000 % 0.000000 % |  |  | 4.210526 % 3.080142 % |  |  |

--- Page 10 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 25-Oct-2022
18-Oct-2022 7:55:21 PM
180+ Delinquency Summary
This report includes all loans greater than 180 days delinquent regardless of status (REO, Foreclosure, Bankruptcy)
© 2021 Computershare. All rights reserved. Confidential. Page 11 of 29

MFA Financial, Inc.
Mortgage Pass-Through Certificates
Series 2021-NV1

|  | Summary |  |  |
| --- | --- | --- | --- |
| Days Delinquent | Number of Loans | Outstanding Actual Balance($) | Percentage Of Balance(%) |
| 390 - 419 | 1 | 57,679.80 | 0.054 |
| 510 - 539 | 1 | 89,976.45 | 0.083 |
| 630 - 659 | 1 | 141,458.21 | 0.131 |
| Total | 3 | 289,114.46 | 0.268 |

--- Page 11 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 25-Oct-2022
18-Oct-2022 7:55:21 PM
Realized Loss Detail Report - Loans with Losses during Current Period
Realized Loss/(Gain) value may include Interest Loss, Principal Loss, and Expense amounts.
* This data is currently not provided for reporting.
** The current loss for this loan is associated with a modification; for further detail please see the Modification section.
© 2021 Computershare. All rights reserved. Confidential. Page 15 of 29

MFA Financial, Inc.
Mortgage Pass-Through Certificates
Series 2021-NV1

|  |  | Inactive |  |  |  |  |  |  | Active |  |  |  |  |  |  | Totals |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Group |  | # Loans with Losses | Liquidated Actual Balance |  | Realized Loss/(Gain) Amount |  | Current Loss Percentage |  | # Loans with Losses |  | Ending Actual Balance |  | Realized Loss/(Gain) Amount |  | Current Loss Percentage | # Loans with Losses |  | Liquidated or Ending Actual Balance |  | Realized Loss/(Gain) Amount |  | Current Loss Percentage |
| Total |  | 0 | 0.00 |  | 0.00 |  | 0.000 % |  | 1 |  | 226,657.46 |  | 23,499.59 |  | 0.022 % | 1 |  | 226,657.46 |  | 23,499.59 |  | 0.022 % |
| Realized Loss Loan Detail Report - Loans with Losses during Current Period |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

| Group | Loan Number | Original Securitized Balance | Current Note Rate | State | LTV at Origination | Original Term | Liquidated or Ending Actual Balance | Liquidation Effective Date | Realized Loss/(Gain) | Cumulative Realized Loss/(Gain) |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Summary | 0000045217 | 245,000.00 | 6.375 % | MD | 77.53 | 360 | 226,657.46 | Active** | 23,499.59 | 23,499.59 |

--- Page 12 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 25-Oct-2022
18-Oct-2022 7:55:22 PM
Calculation Methodology:
Monthly Default Rate (MDR): Sum(Beg Scheduled Balance of Liquidated Loans) / Sum(Beg Scheduled Balance).
Conditional Default Rate (CDR): 1-((1-MDR)^12)
SDA Standard Default Assumption: If WAS ≤ 30 then CDR / (WAS * 0.02) else if 30 < WAS ≤ 60 then CDR / 0.6 else if 60 < WAS ≤ 120 then CDR / (0.6 - ((WAS - 60) * 0.0095)) else if WAS > 120 then CDR /
0.03
Cumulative Loss Severity: Sum(All Active & Inactive Realized Losses) / Sum(Active Loans or loans without a loss passed on or after liquidation: the Actual Ending Principal Balance as of the most recent cycle in
which a Realized Loss was passed; loans with a loss passed on or after the month of liquidation: the Actual Beginning Principal Balance from the cycle in which the loan was liquidated).
3 Month Average and 12 Month Average will not have values until the 3rd and 12th month respectively.
© 2021 Computershare. All rights reserved. Confidential. Page 16 of 29

MFA Financial, Inc.
Mortgage Pass-Through Certificates
Series 2021-NV1

Realized Loss Report - Collateral
Summary
MDR SDA Current Month 0.000 % Current Month 0.000 % 3 Month Average 0.000 % 3 Month Average 0.000 % 12 Month Average 0.000 % 12 Month Average 0.000 %
CDR | Loss Severity
Current Month | 0.000 % | Current Month (Cumulative) | (0.156) %
3 Month Average | 0.000 % | 3 Month Average (Cumulative) | (0.508) %
12 Month Average | 0.000 % | 12 Month Average (Cumulative) | 0.930 %

--- Page 13 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 25-Oct-2022
18-Oct-2022 7:55:22 PM
Prepayment Detail - Prepayments during Current Period
Prepayment Loan Detail - Prepayments during Current Period
© 2021 Computershare. All rights reserved. Confidential. Page 17 of 29

MFA Financial, Inc.
Mortgage Pass-Through Certificates
Series 2021-NV1

| Summary |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | Loans Paid in Full |  |  | Repurchased Loans |  |  | Substitution Loans |  |  | Liquidated Loans |  |  | Curtailments |
|  | Count | Original Securitized Balance | Current Scheduled Balance | Count | Original Securitized Balance | Current Scheduled Balance | Count | Original Securitized Balance | Current Scheduled Balance | Count | Original Securitized Balance | Current Scheduled Balance | Curtailment Amount |
| Total | 7 | 1,335,564.00 | 891,455.81 | 0 | 0.00 | 0.00 | 0 | 0.00 | 0.00 | 0 | 0.00 | 0.00 | 252,441.95 |

| Group | Loan Number | State | LTV at Origination | First Payment Date | Original Securitized Balance | Prepayment Amount | Resolution Type | Months Delinquent | Current Loan Rate | Original Term | Seasoning |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Summary | 0000026278 | NJ | 52.00 | 01-May-2018 | 184,080.00 | 173,268.43 | Loan Paid in Full | 0 | 6.150 % | 360 | 53 |
| Summary | 0000034835 | TN | 51.26 | 10-Feb-2019 | 499,284.00 | 194,384.18 | Loan Paid in Full | 0 | 5.750 % | 360 | 44 |
| Summary | 0000034844 | FL | 72.89 | 10-Feb-2019 | 158,900.00 | 40,911.44 | Loan Paid in Full | 0 | 7.800 % | 360 | 44 |
| Summary | 0000040315 | WI | 75.00 | 01-Jun-2019 | 62,250.00 | 60,439.67 | Loan Paid in Full | 0 | 8.125 % | 360 | 40 |
| Summary | 0000041135 | CT | 65.00 | 01-Aug-2019 | 94,250.00 | 91,786.50 | Loan Paid in Full | 0 | 8.375 % | 360 | 38 |
| Summary | 0000041182 | MI | 80.00 | 10-Sep-2019 | 96,800.00 | 93,563.28 | Loan Paid in Full | 0 | 7.050 % | 360 | 37 |
| Summary | 0000046606 | CT | 80.00 | 01-Mar-2020 | 240,000.00 | 236,655.32 | Loan Paid in Full | 0 | 7.083 % | 360 | 31 |

--- Page 14 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 25-Oct-2022
18-Oct-2022 7:55:22 PM
Prepayment Penalty Loan Detail - Prepayment Penalty Paid during Current Period
© 2021 Computershare. All rights reserved. Confidential. Page 18 of 29

MFA Financial, Inc.
Mortgage Pass-Through Certificates
Series 2021-NV1

Prepayment Penalty Detail - Prepayment Penalty Paid during Current Period

| Summary | Loan Count | Prior Balance | Prepayment Penalty Amount | Prepayment Penalty Waived |
| --- | --- | --- | --- | --- |
| Total | 9 | 1,534,582.29 | 16,731.09 | 0.00 |

| Group | Loan Number | Paid In Full Date | Prior Balance | Prepayment Penalty Amount | Prepayment Penalty Waived |
| --- | --- | --- | --- | --- | --- |
| Summary | 0000026278 | 09/21/2022 | 173,500.71 | 1,386.15 | 0 |
| Summary | 0000034835 | 09/07/2022 | 194,384.18 | 3,887.68 | 0 |
| Summary | 0000034844 | 09/09/2022 | 40,911.44 | 818.33 | 0 |
| Summary | 0000041182 | 09/15/2022 | 93,660.30 | 1,497.01 | 0 |
| Summary | 0000045237 | Active | 131,661.87 | 10.49 | 0 |
| Summary | 0000046595 | Active | 149,385.83 | 1.47 | 0 |
| Summary | 0000046606 | 09/30/2022 | 236,773.01 | 7,099.66 | 0 |
| Summary | 0000046614 | Active | 384,641.16 | 2,028.83 | 0 |
| Summary | 0000047967 | Active | 129,663.79 | 1.47 | 0 |

--- Page 15 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 25-Oct-2022
18-Oct-2022 7:55:22 PM
Prepayment Rates
Calculation Methodology:
Single Month Mortality (SMM): (Partial and full prepayments + Repurchases) / (Beginning Scheduled Balance - Scheduled Principal)
Conditional PrePayment Rate (CPR): 1 - ((1 - SMM)^12)
PSA Standard Prepayment Model: 100 * CPR / (0.2 * MIN(30,WAS))
Weighted Average Seasoning (WAS): sum((Original Term - Remaining Term)*(Current Scheduled Balance/Deal Scheduled Principal Balance))
© 2021 Computershare. All rights reserved. Confidential. Page 19 of 29

MFA Financial, Inc.
Mortgage Pass-Through Certificates
Series 2021-NV1

Summary
SMM CPR PSA Current Month 1.050 % Current Month 11.894 % Current Month 198.234 % 3 Month Average 1.936 % 3 Month Average 20.679 % 3 Month Average 344.644 % 12 Month Average 3.617 % 12 Month Average 34.825 % 12 Month Average 581.449 %

--- Page 16 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 25-Oct-2022
18-Oct-2022 7:55:23 PM
Modifications
© 2021 Computershare. All rights reserved. Confidential. Page 20 of 29

MFA Financial, Inc.
Mortgage Pass-Through Certificates
Series 2021-NV1

| Loan Number | Beginning Scheduled Balance | Current Scheduled Balance | Prior Rate | Modified Rate | Prior Payment | Modified Payment |
| --- | --- | --- | --- | --- | --- | --- |
| 0000045217 | 238,950.26 | 226,657.46 | 6.375 % | 6.375 % | 1,528.48 | 1,528.48 |

--- Page 17 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 25-Oct-2022
18-Oct-2022 7:55:23 PM
Collateral Balance Detail
Balance Methodology:
IB: Interest Bearing
NIB: Non-Interest Bearing
NIB Non-Loss Balance: current balance of NIB amounts that were not treated as a loss at the time of the related modification
Trust Balance = IB Balance + NIB Non-Loss Balance
NIB Loss Balance: current balance of NIB amounts that were treated as a loss at the time of the related modification
TDO: Total Debt Owed = IB Balance + NIB Non-Loss Balance + NIB Loss Balance
© 2021 Computershare. All rights reserved. Confidential. Page 21 of 29

MFA Financial, Inc.
Mortgage Pass-Through Certificates
Series 2021-NV1

| Group | Total |
| --- | --- |
| Begining Scheduled Balance: IB | 109,070,000.35 |
| Beginning NIB Non-Loss Balance | 0.00 |
| Beginning Scheduled Balance: Trust | 109,070,000.35 |
| Beginning NIB Loss Balance | 1,140.30 |
| Beginning Scheduled Balance: TDO | 109,071,140.65 |

| Ending Scheduled Balance: IB | 107,787,328.79 |
| --- | --- |
| Ending NIB Non-Loss Balance | 0.00 |
| Ending Scheduled Balance: Trust | 107,787,328.79 |
| Ending NIB Loss Balance | 24,639.89 |
| Ending Scheduled Balance: TDO | 107,811,968.68 |

| Ending Actual Balance: IB | 107,787,328.79 |
| --- | --- |
| Ending NIB Non-Loss Balance | 0.00 |
| Ending Actual Balance: Trust | 107,787,328.79 |
| Ending NIB Loss Balance | 24,639.89 |
| Ending Actual Balance: TDO | 107,811,968.68 |

--- Page 18 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 25-Oct-2022
18-Oct-2022 7:55:23 PM
Cumulative Repurchases Due To Breaches
© 2021 Computershare. All rights reserved. Confidential. Page 23 of 29

MFA Financial, Inc.
Mortgage Pass-Through Certificates
Series 2021-NV1

| Substitutions |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | Loans Repurchased |  |  |  |  | Loans Substituted |  |  |
| Loan Number | Current Scheduled Balance | Current Rate | Current Payment |  | Loan Number | Current Scheduled Balance | Current Rate | Current Payment |
| No Substitutions this Period |  |  |  |  |  |  |  |  |

| Current Repurchases Due To Breaches |  |  |  |  |
| --- | --- | --- | --- | --- |
| Loan Number | Beginning Scheduled Balance | Payoff Balance | Current Rate | Current Payment |
| No Repurchases Due to Breaches this Period |  |  |  |  |

| Count of Loans Repurchased Due To Breaches | Total Cumulative UPB of Loans Repurchased Due To Breaches |
| --- | --- |
| No Cumulative Repurchases |  |