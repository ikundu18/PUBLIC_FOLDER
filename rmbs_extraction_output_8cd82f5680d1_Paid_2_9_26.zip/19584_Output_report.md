--- Page 1 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
16-Jan-2026 10:13:20 AM
Certificateholder Distribution Summary
© 2021 Computershare. All rights reserved. Confidential. Page 1 of 73

MASTR Adjustable Rate Mortgages Trust
Mortgage Pass-Through Certificates
Series 2004-3

| Class | CUSIP | Record Date | Certificate Pass-Through Rate | Beginning Certificate Balance | Interest Distribution | Principal Distribution | Current Realized Loss/Write Down | Ending Certificate Balance | Total Distribution | Cumulative Realized Losses/Write Down |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1-A1 | 576433KM7 | 12/31/2025 | 3.02326% | 93,118.65 | 234.60 | 585.53 | 0.00 | 92,533.12 | 820.13 | 0.00 |
| 1-AX | 576433KN5 | 12/31/2025 | 0.93320% | 0.00 | 72.42 | 0.00 | 0.00 | 0.00 | 72.42 | 0.00 |
| 2-A1 | 576433KP0 | 12/31/2025 | 5.85725% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 2-AX | 576433KQ8 | 12/31/2025 | 0.76800% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 3-A1 | 576433KR6 | 12/31/2025 | 5.43127% | 104,794.49 | 474.31 | 839.45 | 0.00 | 103,955.03 | 1,313.76 | 0.00 |
| 3-A2 | 576433KS4 | 12/31/2025 | 5.43127% | 69,865.35 | 316.21 | 559.66 | 0.00 | 69,305.69 | 875.87 | 0.00 |
| 3-A3 | 576433KT2 | 12/31/2025 | 5.43127% | 279,461.39 | 1,264.86 | 2,238.62 | 0.00 | 277,222.77 | 3,503.48 | 0.00 |
| 3-A4 | 576433KU9 | 12/31/2025 | 5.43127% | 104,794.49 | 474.31 | 839.45 | 0.00 | 103,955.03 | 1,313.76 | 0.00 |
| 3-AX | 576433KV7 | 12/31/2025 | 0.47700% | 0.00 | 222.17 | 0.00 | 0.00 | 0.00 | 222.17 | 0.00 |
| 4-A1 | 576433KW5 | 12/31/2025 | 4.23329% | 303,178.99 | 1,069.54 | 1,310.03 | 0.00 | 301,868.96 | 2,379.57 | 0.00 |
| 4-A2 | 576433KX3 | 12/31/2025 | 4.23329% | 210,686.34 | 743.25 | 910.37 | 0.00 | 209,775.98 | 1,653.62 | 0.00 |
| 4-AX | 576433KY1 | 12/31/2025 | 0.37600% | 0.00 | 161.01 | 0.00 | 0.00 | 0.00 | 161.01 | 0.00 |
| 5-A1 | 576433KZ8 | 12/31/2025 | 6.34092% | 19,129.79 | 101.08 | 247.69 | 0.00 | 18,882.10 | 348.77 | 0.00 |
| 5-A2 | 576433LA2 | 12/31/2025 | 6.62492% | 693.98 | 3.83 | 8.99 | 0.00 | 684.99 | 12.82 | 0.00 |
| 5-AX | 576433LB0 | 12/31/2025 | 0.28400% | 0.00 | 4.53 | 0.00 | 0.00 | 0.00 | 4.53 | 0.00 |
| 6-A1 | 576433LC8 | 12/31/2025 | 3.10877% | 1,502,336.65 | 3,892.01 | 5,820.19 | 0.00 | 1,496,516.45 | 9,712.20 | 0.00 |
| 6-AX | 576433LD6 | 12/31/2025 | 0.23300% | 0.00 | 291.70 | 0.00 | 0.00 | 0.00 | 291.70 | 0.00 |
| 7-A1 | 576433LE4 | 12/31/2025 | 4.96411% | 372,401.82 | 1,540.54 | 1,781.30 | 0.00 | 370,620.52 | 3,321.84 | 0.00 |
| 7-AX | 576433LF1 | 12/31/2025 | 0.44300% | 0.00 | 137.48 | 0.00 | 0.00 | 0.00 | 137.48 | 0.00 |
| 8-A1 | 576433LG9 | 12/31/2025 | 6.04826% | 57,798.63 | 291.32 | 278.11 | 0.00 | 57,520.51 | 569.43 | 0.00 |
| 8-A2 | 576433LH7 | 12/31/2025 | 6.04826% | 115,597.25 | 582.63 | 556.22 | 0.00 | 115,041.03 | 1,138.85 | 0.00 |
| 8-A3 | 576433LJ3 | 12/31/2025 | 6.04826% | 144,496.56 | 728.29 | 695.28 | 0.00 | 143,801.29 | 1,423.57 | 0.00 |
| 8-A4 | 576433LK0 | 12/31/2025 | 6.04826% | 86,724.28 | 437.11 | 417.29 | 0.00 | 86,306.98 | 854.40 | 0.00 |
| 8-AX | 576433LL8 | 12/31/2025 | 0.48500% | 0.00 | 163.53 | 0.00 | 0.00 | 0.00 | 163.53 | 0.00 |
| B-1 | 576433LP9 | 12/31/2025 | 4.87384% | 799,127.88 | 3,245.68 | 1,170.66 | 2,912.93 | 795,044.30 | 4,416.34 | 326,343.32 |

--- Page 2 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
16-Jan-2026 10:13:20 AM
Certificateholder Distribution Summary
All Record Dates are based upon the governing documents and logic set forth as of closing.
NOTE: On December 20, 2006, US Mortgage, a servicer in this deal, filed for bankruptcy relief under Chapter 11 of the Bankruptcy Code. Please refer to Supplemental Reporting page for the full disclosure of this
event.
This document is provided by Computershare Trust Company, N.A., or one or more of its affiliates (collectively, "Computershare"), in its named capacity or as agent of or successor to Wells Fargo Bank, N.A., or
one or more of its affiliates ("Wells Fargo"), by virtue of the acquisition by Computershare of substantially all the assets of the corporate trust services business of Wells Fargo. This report is compiled by
Computershare Trust Company, N.A. from information provided by third parties. Computershare Trust Company, N.A. has not independently confirmed the accuracy of the information.
Effective March 1, 2023 our Computershare Corporate Trust office located at 600 S 4th Street Minneapolis, MN 55415 has moved and our new address is 1505 Energy Park Drive St. Paul, Minnesota 55108. Please
update your records to reflect the new address.
© 2021 Computershare. All rights reserved. Confidential. Page 2 of 73

MASTR Adjustable Rate Mortgages Trust
Mortgage Pass-Through Certificates
Series 2004-3

| Class | CUSIP | Record Date | Certificate Pass-Through Rate | Beginning Certificate Balance | Interest Distribution | Principal Distribution | Current Realized Loss/Write Down | Ending Certificate Balance | Total Distribution | Cumulative Realized Losses/Write Down |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| B-1-X | 576433LQ7 | 12/31/2025 | 0.00000% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| B-2 | 576433LR5 | 12/31/2025 | 4.87384% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 647,588.61 |
| B-3 | 576433LS3 | 12/31/2025 | 4.87384% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 1,299,353.17 |
| B-4 | 576433LT1 | 12/31/2025 | 4.87384% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 2,017,781.57 |
| B-5 | 576433LU8 | 12/31/2025 | 4.87384% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 1,219,355.83 |
| B-6 | 576433LV6 | 12/31/2025 | 4.87384% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 1,080,548.79 |
| AR | 576433LN4 | 12/31/2025 | 3.95646% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| ALR | 576433LM6 | 12/31/2025 | 3.95646% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| Totals |  |  |  | 4,264,206.54 | 16,452.41 | 18,258.84 | 2,912.93 | 4,243,034.75 | 34,711.25 | 6,590,971.29 |

--- Page 3 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
16-Jan-2026 10:13:20 AM
© 2021 Computershare. All rights reserved. Confidential. Page 3 of 73

MASTR Adjustable Rate Mortgages Trust
Mortgage Pass-Through Certificates
Series 2004-3

| Principal Distribution Statement |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Class | Original Face Amount | Beginning Certificate Balance | Scheduled Principal Distribution | Unscheduled Principal Distribution | Accretion | Realized Loss/Write Down | Total Principal Reduction | Ending Certificate Balance | Ending Certificate Percentage | Total Principal Distribution |
| 1-A1 | 35,660,000.00 | 93,118.65 | 585.53 | 0.00 | 0.00 | 0.00 | 585.53 | 92,533.12 | 0.00259487 | 585.53 |
| 1-AX | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| 2-A1 | 61,892,000.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| 2-AX | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| 3-A1 | 14,827,000.00 | 104,794.49 | 837.80 | 1.66 | 0.00 | 0.00 | 839.45 | 103,955.03 | 0.00701120 | 839.45 |
| 3-A2 | 9,885,000.00 | 69,865.35 | 558.55 | 1.10 | 0.00 | 0.00 | 559.66 | 69,305.69 | 0.00701120 | 559.66 |
| 3-A3 | 39,540,000.00 | 279,461.39 | 2,234.21 | 4.42 | 0.00 | 0.00 | 2,238.62 | 277,222.77 | 0.00701120 | 2,238.62 |
| 3-A4 | 14,827,000.00 | 104,794.49 | 837.80 | 1.66 | 0.00 | 0.00 | 839.45 | 103,955.03 | 0.00701120 | 839.45 |
| 3-AX | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| 4-A1 | 35,047,000.00 | 303,178.99 | 1,301.95 | 8.08 | 0.00 | 0.00 | 1,310.03 | 301,868.96 | 0.00861326 | 1,310.03 |
| 4-A2 | 24,355,000.00 | 210,686.34 | 904.75 | 5.61 | 0.00 | 0.00 | 910.37 | 209,775.98 | 0.00861326 | 910.37 |
| 4-AX | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| 5-A1 | 47,633,000.00 | 19,129.79 | 148.61 | 99.08 | 0.00 | 0.00 | 247.69 | 18,882.10 | 0.00039641 | 247.69 |
| 5-A2 | 1,728,000.00 | 693.98 | 5.39 | 3.59 | 0.00 | 0.00 | 8.99 | 684.99 | 0.00039641 | 8.99 |
| 5-AX | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| 6-A1 | 81,256,000.00 | 1,502,336.65 | 5,780.14 | 40.06 | 0.00 | 0.00 | 5,820.19 | 1,496,516.45 | 0.01841730 | 5,820.19 |
| 6-AX | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| 7-A1 | 34,031,000.00 | 372,401.82 | 1,771.38 | 9.92 | 0.00 | 0.00 | 1,781.30 | 370,620.52 | 0.01089067 | 1,781.30 |
| 7-AX | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| 8-A1 | 19,750,000.00 | 57,798.63 | 251.96 | 26.15 | 0.00 | 0.00 | 278.11 | 57,520.51 | 0.00291243 | 278.11 |
| 8-A2 | 39,500,000.00 | 115,597.25 | 503.92 | 52.30 | 0.00 | 0.00 | 556.22 | 115,041.03 | 0.00291243 | 556.22 |
| 8-A3 | 49,375,000.00 | 144,496.56 | 629.91 | 65.37 | 0.00 | 0.00 | 695.28 | 143,801.29 | 0.00291243 | 695.28 |
| 8-A4 | 29,634,000.00 | 86,724.28 | 378.06 | 39.23 | 0.00 | 0.00 | 417.29 | 86,306.98 | 0.00291243 | 417.29 |
| 8-AX | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| B-1 | 16,471,000.00 | 799,127.88 | 1,170.66 | 0.00 | 0.00 | 2,912.93 | 4,083.59 | 795,044.30 | 0.04826934 | 1,170.66 |

--- Page 4 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
16-Jan-2026 10:13:20 AM
NOTE: Accretion amount also includes Net Negative Amortization, if applicable.
© 2021 Computershare. All rights reserved. Confidential. Page 4 of 73

MASTR Adjustable Rate Mortgages Trust
Mortgage Pass-Through Certificates
Series 2004-3

| Principal Distribution Statement |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Class | Original Face Amount | Beginning Certificate Balance | Scheduled Principal Distribution | Unscheduled Principal Distribution | Accretion | Realized Loss/Write Down | Total Principal Reduction | Ending Certificate Balance | Ending Certificate Percentage | Total Principal Distribution |
| B-1-X | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| B-2 | 7,802,000.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| B-3 | 4,335,000.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| B-4 | 5,202,000.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| B-5 | 2,890,000.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| B-6 | 2,311,849.07 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| AR | 50.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| ALR | 50.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| Totals | 577,951,949.07 | 4,264,206.54 | 17,900.62 | 358.23 | 0.00 | 2,912.93 | 21,171.77 | 4,243,034.75 | 0.00734150 | 18,258.84 |

--- Page 5 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
16-Jan-2026 10:13:20 AM
© 2021 Computershare. All rights reserved. Confidential. Page 7 of 73

MASTR Adjustable Rate Mortgages Trust
Mortgage Pass-Through Certificates
Series 2004-3

Interest Distribution Statement

| Class | Accrual Dates | Accrual Days | Current Certificate Rate | Beginning Certificate/Notional Balance | Current Accrued Interest | Payment of Unpaid Interest Shortfall(1) | Basis Risk Shortfall | Interest Shortfall | Non- Supported Interest Shortfall | Total Interest Distribution | Remaining Unpaid Interest Shortfall(1) | Ending Certificate/ Notional Balance |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1-A1 | 12/01/25 - 12/30/25 | 30 | 3.02326 % | 93,118.65 | 234.60 | 0.00 | 0.00 | 0.00 | 0.00 | 234.60 | 0.00 | 92,533.12 |
| 1-AX | 12/01/25 - 12/30/25 | 30 | 0.93320 % | 93,118.65 | 72.42 | 0.00 | 0.00 | 0.00 | 0.00 | 72.42 | 0.00 | 92,533.12 |
| 2-A1 | N/A | N/A | 5.85725 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 2-AX | N/A | N/A | 0.76800 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 3-A1 | 12/01/25 - 12/30/25 | 30 | 5.43127 % | 104,794.49 | 474.31 | 0.00 | 0.00 | 0.00 | 0.00 | 474.31 | 0.00 | 103,955.03 |
| 3-A2 | 12/01/25 - 12/30/25 | 30 | 5.43127 % | 69,865.35 | 316.21 | 0.00 | 0.00 | 0.00 | 0.00 | 316.21 | 0.00 | 69,305.69 |
| 3-A3 | 12/01/25 - 12/30/25 | 30 | 5.43127 % | 279,461.39 | 1,264.86 | 0.00 | 0.00 | 0.00 | 0.00 | 1,264.86 | 0.00 | 277,222.77 |
| 3-A4 | 12/01/25 - 12/30/25 | 30 | 5.43127 % | 104,794.49 | 474.31 | 0.00 | 0.00 | 0.00 | 0.00 | 474.31 | 0.00 | 103,955.03 |
| 3-AX | 12/01/25 - 12/30/25 | 30 | 0.47700 % | 558,915.72 | 222.17 | 0.00 | 0.00 | 0.00 | 0.00 | 222.17 | 0.00 | 554,438.53 |
| 4-A1 | 12/01/25 - 12/30/25 | 30 | 4.23329 % | 303,178.99 | 1,069.54 | 0.00 | 0.00 | 0.00 | 0.00 | 1,069.54 | 0.00 | 301,868.96 |
| 4-A2 | 12/01/25 - 12/30/25 | 30 | 4.23329 % | 210,686.34 | 743.25 | 0.00 | 0.00 | 0.00 | 0.00 | 743.25 | 0.00 | 209,775.98 |
| 4-AX | 12/01/25 - 12/30/25 | 30 | 0.37600 % | 513,865.33 | 161.01 | 0.00 | 0.00 | 0.00 | 0.00 | 161.01 | 0.00 | 511,644.94 |
| 5-A1 | 12/01/25 - 12/30/25 | 30 | 6.34092 % | 19,129.79 | 101.08 | 0.00 | 0.00 | 0.00 | 0.00 | 101.08 | 0.00 | 18,882.10 |
| 5-A2 | 12/01/25 - 12/30/25 | 30 | 6.62492 % | 693.98 | 3.83 | 0.00 | 0.00 | 0.00 | 0.00 | 3.83 | 0.00 | 684.99 |
| 5-AX | 12/01/25 - 12/30/25 | 30 | 0.28400 % | 19,129.79 | 4.53 | 0.00 | 0.00 | 0.00 | 0.00 | 4.53 | 0.00 | 18,882.10 |
| 6-A1 | 12/01/25 - 12/30/25 | 30 | 3.10877 % | 1,502,336.65 | 3,892.01 | 0.00 | 0.00 | 0.00 | 0.00 | 3,892.01 | 0.00 | 1,496,516.45 |
| 6-AX | 12/01/25 - 12/30/25 | 30 | 0.23300 % | 1,502,336.65 | 291.70 | 0.00 | 0.00 | 0.00 | 0.00 | 291.70 | 0.00 | 1,496,516.45 |
| 7-A1 | 12/01/25 - 12/30/25 | 30 | 4.96411 % | 372,401.82 | 1,540.54 | 0.00 | 0.00 | 0.00 | 0.00 | 1,540.54 | 0.00 | 370,620.52 |
| 7-AX | 12/01/25 - 12/30/25 | 30 | 0.44300 % | 372,401.82 | 137.48 | 0.00 | 0.00 | 0.00 | 0.00 | 137.48 | 0.00 | 370,620.52 |
| 8-A1 | 12/01/25 - 12/30/25 | 30 | 6.04826 % | 57,798.63 | 291.32 | 0.00 | 0.00 | 0.00 | 0.00 | 291.32 | 0.00 | 57,520.51 |
| 8-A2 | 12/01/25 - 12/30/25 | 30 | 6.04826 % | 115,597.25 | 582.63 | 0.00 | 0.00 | 0.00 | 0.00 | 582.63 | 0.00 | 115,041.03 |
| 8-A3 | 12/01/25 - 12/30/25 | 30 | 6.04826 % | 144,496.56 | 728.29 | 0.00 | 0.00 | 0.00 | 0.00 | 728.29 | 0.00 | 143,801.29 |
| 8-A4 | 12/01/25 - 12/30/25 | 30 | 6.04826 % | 86,724.28 | 437.11 | 0.00 | 0.00 | 0.00 | 0.00 | 437.11 | 0.00 | 86,306.98 |
| 8-AX | 12/01/25 - 12/30/25 | 30 | 0.48500 % | 404,616.72 | 163.53 | 0.00 | 0.00 | 0.00 | 0.00 | 163.53 | 0.00 | 402,669.82 |
| B-1 | 12/01/25 - 12/30/25 | 30 | 4.87384 % | 799,127.88 | 3,245.68 | 0.00 | 0.00 | 0.00 | 0.00 | 3,245.68 | 0.00 | 795,044.30 |

--- Page 6 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
16-Jan-2026 10:13:20 AM
(1) Amount also includes Coupon Cap or Basis Risk Shortfalls, if applicable.
© 2021 Computershare. All rights reserved. Confidential. Page 8 of 73

MASTR Adjustable Rate Mortgages Trust
Mortgage Pass-Through Certificates
Series 2004-3

Interest Distribution Statement

| Class | Accrual Dates | Accrual Days | Current Certificate Rate | Beginning Certificate/Notional Balance | Current Accrued Interest | Payment of Unpaid Interest Shortfall(1) | Basis Risk Shortfall | Interest Shortfall | Non- Supported Interest Shortfall | Total Interest Distribution | Remaining Unpaid Interest Shortfall(1) | Ending Certificate/ Notional Balance |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| B-1-X | N/A | N/A | 0.00000 % | 799,127.88 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 795,044.30 |
| B-2 | N/A | N/A | 4.87384 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| B-3 | N/A | N/A | 4.87384 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| B-4 | N/A | N/A | 4.87384 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| B-5 | N/A | N/A | 4.87384 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| B-6 | N/A | N/A | 4.87384 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| AR | N/A | N/A | 3.95646 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| ALR | N/A | N/A | 3.95646 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| Totals |  |  |  |  | 16,452.41 | 0.00 | 0.00 | 0.00 | 0.00 | 16,452.41 | 0.00 |  |

--- Page 7 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
16-Jan-2026 10:13:20 AM
© 2021 Computershare. All rights reserved. Confidential. Page 9 of 73

MASTR Adjustable Rate Mortgages Trust
Mortgage Pass-Through Certificates
Series 2004-3

Interest Distribution Factors Statement

| Class | Original Face Amount | Current Certificate Rate | Beginning Certificate/Notional Balance | Current Accrued Interest | Payment of Unpaid Interest Shortfall(1) | Basis Risk Shortfall | Interest Shortfall | Non- Supported Interest Shortfall | Total Interest Distribution | Remaining Unpaid Interest Shortfall(1) | Ending Certificate/ Notional Balance |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1-A1 | 35,660,000.00 | 3.02326 % | 2.61129136 | 0.00657880 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00657880 | 0.00000000 | 2.59487156 |
| 1-AX | 0.00 | 0.93320 % | 2.61129136 | 0.00203085 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00203085 | 0.00000000 | 2.59487156 |
| 2-A1 | 61,892,000.00 | 5.85725 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 |
| 2-AX | 0.00 | 0.76800 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 |
| 3-A1 | 14,827,000.00 | 5.43127 % | 7.06781480 | 0.03198961 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.03198961 | 0.00000000 | 7.01119781 |
| 3-A2 | 9,885,000.00 | 5.43127 % | 7.06781487 | 0.03198887 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.03198887 | 0.00000000 | 7.01119777 |
| 3-A3 | 39,540,000.00 | 5.43127 % | 7.06781462 | 0.03198938 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.03198938 | 0.00000000 | 7.01119803 |
| 3-A4 | 14,827,000.00 | 5.43127 % | 7.06781480 | 0.03198961 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.03198961 | 0.00000000 | 7.01119781 |
| 3-AX | 0.00 | 0.47700 % | 7.06781472 | 0.00280947 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00280947 | 0.00000000 | 7.01119804 |
| 4-A1 | 35,047,000.00 | 4.23329 % | 8.65064028 | 0.03051731 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.03051731 | 0.00000000 | 8.61326105 |
| 4-A2 | 24,355,000.00 | 4.23329 % | 8.65064011 | 0.03051735 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.03051735 | 0.00000000 | 8.61326134 |
| 4-AX | 0.00 | 0.37600 % | 8.65064021 | 0.00271051 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00271051 | 0.00000000 | 8.61326117 |
| 5-A1 | 47,633,000.00 | 6.34092 % | 0.40160792 | 0.00212206 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00212206 | 0.00000000 | 0.39640795 |
| 5-A2 | 1,728,000.00 | 6.62492 % | 0.40160880 | 0.00221644 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00221644 | 0.00000000 | 0.39640625 |
| 5-AX | 0.00 | 0.28400 % | 0.40160792 | 0.00009510 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00009510 | 0.00000000 | 0.39640795 |
| 6-A1 | 81,256,000.00 | 3.10877 % | 18.48893189 | 0.04789812 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.04789812 | 0.00000000 | 18.41730395 |
| 6-AX | 0.00 | 0.23300 % | 18.48893189 | 0.00358989 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00358989 | 0.00000000 | 18.41730395 |
| 7-A1 | 34,031,000.00 | 4.96411 % | 10.94301725 | 0.04526873 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.04526873 | 0.00000000 | 10.89067380 |
| 7-AX | 0.00 | 0.44300 % | 10.94301725 | 0.00403985 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00403985 | 0.00000000 | 10.89067380 |
| 8-A1 | 19,750,000.00 | 6.04826 % | 2.92651291 | 0.01475038 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.01475038 | 0.00000000 | 2.91243089 |
| 8-A2 | 39,500,000.00 | 6.04826 % | 2.92651266 | 0.01475013 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.01475013 | 0.00000000 | 2.91243114 |
| 8-A3 | 49,375,000.00 | 6.04826 % | 2.92651261 | 0.01475018 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.01475018 | 0.00000000 | 2.91243119 |
| 8-A4 | 29,634,000.00 | 6.04826 % | 2.92651279 | 0.01475029 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.01475029 | 0.00000000 | 2.91243099 |
| 8-AX | 0.00 | 0.48500 % | 2.92651270 | 0.00118278 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00118278 | 0.00000000 | 2.91243116 |
| B-1 | 16,471,000.00 | 4.87384 % | 48.51726550 | 0.19705422 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.19705422 | 0.00000000 | 48.26934005 |

--- Page 8 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
16-Jan-2026 10:13:20 AM
(1) Amount also includes Coupon Cap or Basis Risk Shortfalls, if applicable.
NOTE: All Classes are per $1,000 denomination.
© 2021 Computershare. All rights reserved. Confidential. Page 10 of 73

MASTR Adjustable Rate Mortgages Trust
Mortgage Pass-Through Certificates
Series 2004-3

Interest Distribution Factors Statement

| Class | Original Face Amount | Current Certificate Rate | Beginning Certificate/Notional Balance | Current Accrued Interest | Payment of Unpaid Interest Shortfall(1) | Basis Risk Shortfall | Interest Shortfall | Non- Supported Interest Shortfall | Total Interest Distribution | Remaining Unpaid Interest Shortfall(1) | Ending Certificate/ Notional Balance |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| B-1-X | 0.00 | 0.00000 % | 48.51726550 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 48.26934005 |
| B-2 | 7,802,000.00 | 4.87384 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 |
| B-3 | 4,335,000.00 | 4.87384 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 |
| B-4 | 5,202,000.00 | 4.87384 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 |
| B-5 | 2,890,000.00 | 4.87384 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 |
| B-6 | 2,311,849.07 | 4.87384 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 |
| AR | 50.00 | 3.95646 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 |
| ALR | 50.00 | 3.95646 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 |

--- Page 9 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
16-Jan-2026 10:13:20 AM
© 2021 Computershare. All rights reserved. Confidential. Page 11 of 73

MASTR Adjustable Rate Mortgages Trust
Mortgage Pass-Through Certificates
Series 2004-3

| Certificateholder Component Statement |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- |
| Class | Component Pass-Through Rate | Beginning Notional Balance | Ending Notional Balance | Beginning Component Balance | Ending Component Balance | Ending Component Percentage |
| 3-AX-1 | 0.47700% | 104,794.49 | 103,955.03 | 0.00 | 0.00 | 0.70111978% |
| 3-AX-2 | 0.47700% | 69,865.35 | 69,305.69 | 0.00 | 0.00 | 0.70111978% |
| 3-AX-3 | 0.47700% | 279,461.39 | 277,222.77 | 0.00 | 0.00 | 0.70111980% |
| 3-AX-4 | 0.47700% | 104,794.49 | 103,955.03 | 0.00 | 0.00 | 0.70111978% |
| 4-AX-1 | 0.37600% | 303,178.99 | 301,868.96 | 0.00 | 0.00 | 0.86132610% |
| 4-AX-2 | 0.37600% | 210,686.34 | 209,775.98 | 0.00 | 0.00 | 0.86132613% |
| 8-AX-1 | 0.48500% | 57,798.63 | 57,520.51 | 0.00 | 0.00 | 0.29124309% |
| 8-AX-2 | 0.48500% | 115,597.25 | 115,041.03 | 0.00 | 0.00 | 0.29124311% |
| 8-AX-3 | 0.48500% | 144,496.56 | 143,801.29 | 0.00 | 0.00 | 0.29124312% |
| 8-AX-4 | 0.48500% | 86,724.28 | 86,306.98 | 0.00 | 0.00 | 0.29124310% |

--- Page 10 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
16-Jan-2026 10:13:20 AM
Certificateholder Account Statement
*Servicer Payees include: PHH MORTGAGE CORPORATION; WASHINGTON MUTUAL MTG SEC CORP
Servicer Advances are calculated as delinquent scheduled principal and interest.
© 2021 Computershare. All rights reserved. Confidential. Page 12 of 73

MASTR Adjustable Rate Mortgages Trust
Mortgage Pass-Through Certificates
Series 2004-3

CERTIFICATE ACCOUNT
Beginning Balance 0.00 Deposits Payments of Interest and Principal 32,240.10 Reserve Funds and Credit Enhancements 0.00 Proceeds from Repurchased Loans 0.00 Servicer Advances 3,653.13 Gains & Subsequent Recoveries (Realized Losses) (17.50) Total Deposits 35,875.73 Withdrawals Reserve Funds and Credit Enhancements 0.00 Total Administration Fees 1,164.48 Payment of Interest and Principal 34,711.25 Total Withdrawals (Pool Distribution Amount) 35,875.73 Ending Balance 0.00

PREPAYMENT/CURTAILMENT INTEREST SHORTFALL
Total Prepayment/Curtailment Interest Shortfall 0.00 Servicing Fee Support 0.00 Non-Supported Prepayment/Curtailment Interest Shortfall 0.00

| ADMINISTRATION FEES |  |  |
| --- | --- | --- |
| Gross Servicing Fee* 1,149.41 Lender Paid Morgage Insurance 0.00 Master Servicing Fee - WMMSC 15.07 Supported Prepayment/Curtailment Interest Shortfall 0.00 |  |  |
| Total Administration Fees | 1,164.48 |  |

--- Page 11 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
16-Jan-2026 10:13:20 AM
Collateral Statement
© 2021 Computershare. All rights reserved. Confidential. Page 13 of 73

MASTR Adjustable Rate Mortgages Trust
Mortgage Pass-Through Certificates
Series 2004-3

| Group | 1 | 2 | 3 | 4 | 5 | 6 |
| --- | --- | --- | --- | --- | --- | --- |
| Collateral Description | Mixed ARM | Mixed ARM | Mixed ARM | Mixed ARM | Mixed ARM | Mixed ARM |
| Weighted Average Coupon Rate | 4.253227 | 6.875103 | 6.236347 | 4.952892 | 6.875128 | 3.641647 |
| Weighted Average Net Rate | 3.956462 | 6.625245 | 5.908271 | 4.609293 | 6.624916 | 3.341767 |
| Weighted Average Pass-Through Rate | 3.956462 | 6.625245 | 5.908271 | 4.609293 | 6.624916 | 3.341767 |
| Weighted Average Remaining Term | 98 | 98 | 97 | 105 | 99 | 112 |
| Principal and Interest Constant | 2,230.26 | 382.71 | 7,473.10 | 6,295.73 | 298.43 | 11,208.88 |
| Beginning Loan Count | 1 | 1 | 6 | 3 | 1 | 10 |
| Loans Paid in Full | 0 | 0 | 0 | 0 | 0 | 0 |
| Ending Loan Count | 1 | 1 | 6 | 3 | 1 | 10 |
| Beginning Scheduled Balance | 223,166.07 | 28,288.16 | 566,502.80 | 747,558.42 | 22,109.26 | 1,628,691.63 |
| Ending Scheduled Balance | 221,726.79 | 28,001.54 | 561,873.18 | 744,348.17 | 21,835.35 | 1,622,425.35 |
| Actual Ending Collateral Balance | 223,166.07 | 28,222.56 | 567,479.37 | 747,558.42 | 22,007.69 | 1,628,691.63 |
| Scheduled Principal | 1,439.28 | 220.64 | 4,529.01 | 3,210.25 | 171.76 | 6,266.28 |
| Unscheduled Principal | 0.00 | 65.98 | 100.61 | 0.00 | 102.15 | 0.00 |
| Negative Amortized Principal | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| Scheduled Interest | 790.98 | 162.07 | 2,944.09 | 3,085.48 | 126.67 | 4,942.60 |
| Servicing Fees | 55.19 | 5.89 | 154.88 | 214.05 | 4.61 | 407.01 |
| Master Servicing Fees | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| Trustee Fee | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| FRY Amount | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| Special Hazard Fee | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| Other Fee | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| Pool Insurance Fee | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| Spread 1 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| Spread 2 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| Spread 3 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| Net Interest | 735.79 | 156.18 | 2,789.21 | 2,871.43 | 122.06 | 4,535.59 |
| Realized Loss Amount | 17.50 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| Cumulative Realized Loss | 117,126.12 | 795,559.46 | 1,715,771.66 | 271,831.36 | 319,618.19 | 1,383,582.48 |
| Percentage of Cumulative Losses | 0.3063 | 1.1986 | 2.0232 | 0.4267 | 0.6038 | 1.5878 |
| Special Servicing Fee | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |

--- Page 12 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
16-Jan-2026 10:13:21 AM
Collateral Statement
NOTE: The Collateral Balances shown are Trust Balances unless otherwise designated.
© 2021 Computershare. All rights reserved. Confidential. Page 14 of 73

MASTR Adjustable Rate Mortgages Trust
Mortgage Pass-Through Certificates
Series 2004-3

| Group | 7 | 8 | Total |  |
| --- | --- | --- | --- | --- |
| Collateral Description | Mixed ARM | Mixed ARM | Mixed ARM |  |
| Weighted Average Coupon Rate | 5.808274 | 6.874993 | 4.957609 |  |
| Weighted Average Net Rate | 5.443767 | 6.533256 | 4.634151 |  |
| Weighted Average Pass-Through Rate | 5.407110 | 6.533256 | 4.629910 |  |
| Weighted Average Remaining Term | 93 | 95 | 104 |  |
| Principal and Interest Constant | 4,734.36 | 5,594.73 | 38,218.20 |  |
| Beginning Loan Count | 3 | 5 | 30 |  |
| Loans Paid in Full | 0 | 0 | 0 |  |
| Ending Loan Count | 3 | 5 | 30 |  |
| Beginning Scheduled Balance | 493,323.81 | 554,566.39 | 4,264,206.54 |  |
| Ending Scheduled Balance | 490,977.25 | 551,847.14 | 4,243,034.77 |  |
| Actual Ending Collateral Balance | 493,005.62 | 593,029.59 | 4,303,160.95 |  |
| Scheduled Principal | 2,346.56 | 2,417.53 | 20,601.31 |  |
| Unscheduled Principal | 0.00 | 301.72 | 570.46 |  |
| Negative Amortized Principal | 0.00 | 0.00 | 0.00 |  |
| Scheduled Interest | 2,387.80 | 3,177.20 | 17,616.89 |  |
| Servicing Fees | 149.85 | 157.93 | 1,149.41 |  |
| Master Servicing Fees | 0.00 | 0.00 | 0.00 |  |
| Trustee Fee | 0.00 | 0.00 | 0.00 |  |
| FRY Amount | 0.00 | 0.00 | 0.00 |  |
| Special Hazard Fee | 0.00 | 0.00 | 0.00 |  |
| Other Fee | 15.07 | 0.00 | 15.07 |  |
| Pool Insurance Fee | 0.00 | 0.00 | 0.00 |  |
| Spread 1 | 0.00 | 0.00 | 0.00 |  |
| Spread 2 | 0.00 | 0.00 | 0.00 |  |
| Spread 3 | 0.00 | 0.00 | 0.00 |  |
| Net Interest | 2,222.88 | 3,019.27 | 16,452.41 |  |
| Realized Loss Amount | 0.00 | 0.00 | 17.50 |  |
| Cumulative Realized Loss | 199,630.47 | 767,580.28 | 5,570,700.02 |  |
| Percentage of Cumulative Losses | 0.5470 | 0.5177 | 0.9639 |  |
| Special Servicing Fee | 0.00 | 0.00 | 0.00 |  |

--- Page 13 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
16-Jan-2026 10:13:21 AM
Additional Reporting - Deal Level
No data for Additional Reporting – Deal Level
© 2021 Computershare. All rights reserved. Confidential. Page 15 of 73

MASTR Adjustable Rate Mortgages Trust
Mortgage Pass-Through Certificates
Series 2004-3

--- Page 14 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
16-Jan-2026 10:13:21 AM
Delinquency Status
Please refer to CTSLink.com for a list of delinquency code descriptions.
Current Period Class A Insufficient Funds 0.00 Principal Balance of Contaminated Properties 0.00 Periodic Advance 3,653.13
© 2021 Computershare. All rights reserved. Confidential. Page 17 of 73

MASTR Adjustable Rate Mortgages Trust
Mortgage Pass-Through Certificates
Series 2004-3

| DELINQUENT |  |  | BANKRUPTCY |  |  | FORECLOSURE |  |  | REO |  |  | TOTAL |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | No. of Loans | Actual Balance |  | No. of Loans | Actual Balance |  | No. of Loans | Actual Balance |  | No. of Loans | Actual Balance |  | No. of Loans | Actual Balance |
|  |  |  | 0-29 Days | 1 | 311,772.41 | 0-29 Days | 0 | 0.00 | 0-29 Days | 0 | 0.00 | 0-29 Days | 1 | 311,772.41 |
| 30 Days | 2 | 280,697.19 | 30 Days | 0 | 0.00 | 30 Days | 0 | 0.00 | 30 Days | 0 | 0.00 | 30 Days | 2 | 280,697.19 |
| 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 |
| 90 Days | 0 | 0.00 | 90 Days | 0 | 0.00 | 90 Days | 0 | 0.00 | 90 Days | 0 | 0.00 | 90 Days | 0 | 0.00 |
| 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 |
| 150 Days | 0 | 0.00 | 150 Days | 0 | 0.00 | 150 Days | 0 | 0.00 | 150 Days | 0 | 0.00 | 150 Days | 0 | 0.00 |
| 180+ Days | 0 | 0.00 | 180+ Days | 0 | 0.00 | 180+ Days | 1 | 296,078.02 | 180+ Days | 0 | 0.00 | 180+ Days | 1 | 296,078.02 |
| 2 280,697.19 |  |  | 1 311,772.41 |  |  | 1 296,078.02 |  |  | 0 0.00 |  |  | 4 888,547.62 |  |  |
|  |  |  | 0-29 Days | 3.333333 % | 7.245195 % | 0-29 Days | 0.000000 % | 0.000000 % | 0-29 Days | 0.000000 % | 0.000000 % | 0-29 Days | 3.333333 % | 7.245195 % |
| 30 Days | 6.666667 % | 6.523047 % | 30 Days | 0.000000 % | 0.000000 % | 30 Days | 0.000000 % | 0.000000 % | 30 Days | 0.000000 % | 0.000000 % | 30 Days | 6.666667 % | 6.523047 % |
| 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % |
| 90 Days | 0.000000 % | 0.000000 % | 90 Days | 0.000000 % | 0.000000 % | 90 Days | 0.000000 % | 0.000000 % | 90 Days | 0.000000 % | 0.000000 % | 90 Days | 0.000000 % | 0.000000 % |
| 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % |
| 150 Days | 0.000000 % | 0.000000 % | 150 Days | 0.000000 % | 0.000000 % | 150 Days | 0.000000 % | 0.000000 % | 150 Days | 0.000000 % | 0.000000 % | 150 Days | 0.000000 % | 0.000000 % |
| 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 3.333333 % | 6.880477 % | 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 3.333333 % | 6.880477 % |
| 6.666667 % 6.523047 % |  |  | 3.333333 % 7.245195 % |  |  | 3.333333 % 6.880477 % |  |  | 0.000000 % 0.000000 % |  |  | 13.333333 % 20.648719 % |  |  |

--- Page 15 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
16-Jan-2026 10:13:21 AM
Delinquency Status By Group
© 2021 Computershare. All rights reserved. Confidential. Page 18 of 73

MASTR Adjustable Rate Mortgages Trust
Mortgage Pass-Through Certificates
Series 2004-3

| DELINQUENT |  |  | BANKRUPTCY |  |  | FORECLOSURE |  |  | REO |  |  | TOTAL |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | No of Loans | Actual Balance |  | No of Loans | Actual Balance |  | No of Loans | Actual Balance |  | No of Loans | Actual Balance |  | No of Loans | Actual Balance |
| 1 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  | 0-29 Days | 0 | 0.00 | 0-29 Days | 0 | 0.00 | 0-29 Days | 0 | 0.00 | 0-29 Days | 0 | 0.00 |
| 30 Days 0 0.00 |  |  | 30 Days 0 0.00 |  |  | 30 Days 0 0.00 |  |  | 30 Days 0 0.00 |  |  | 30 Days 0 0.00 |  |  |
| 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 |
| 90 Days 0 0.00 |  |  | 90 Days 0 0.00 |  |  | 90 Days 0 0.00 |  |  | 90 Days 0 0.00 |  |  | 90 Days 0 0.00 |  |  |
| 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 |
| 150 Days 0 0.00 |  |  | 150 Days 0 0.00 |  |  | 150 Days 0 0.00 |  |  | 150 Days 0 0.00 |  |  | 150 Days 0 0.00 |  |  |
| 180+ Days | 0 | 0.00 | 180+ Days | 0 | 0.00 | 180+ Days | 0 | 0.00 | 180+ Days | 0 | 0.00 | 180+ Days | 0 | 0.00 |
| 0 0.00 |  |  | 0 0.00 |  |  | 0 0.00 |  |  | 0 0.00 |  |  | 0 0.00 |  |  |
|  |  |  | 0-29 Days | 0.000000 % | 0.000000 % | 0-29 Days | 0.000000 % | 0.000000 % | 0-29 Days | 0.000000 % | 0.000000 % | 0-29 Days | 0.000000 % | 0.000000 % |
| 30 Days 0.000000 % 0.000000 % |  |  | 30 Days 0.000000 % 0.000000 % |  |  | 30 Days 0.000000 % 0.000000 % |  |  | 30 Days 0.000000 % 0.000000 % |  |  | 30 Days 0.000000 % 0.000000 % |  |  |
| 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % |
| 90 Days 0.000000 % 0.000000 % |  |  | 90 Days 0.000000 % 0.000000 % |  |  | 90 Days 0.000000 % 0.000000 % |  |  | 90 Days 0.000000 % 0.000000 % |  |  | 90 Days 0.000000 % 0.000000 % |  |  |
| 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % |
| 150 Days 0.000000 % 0.000000 % |  |  | 150 Days 0.000000 % 0.000000 % |  |  | 150 Days 0.000000 % 0.000000 % |  |  | 150 Days 0.000000 % 0.000000 % |  |  | 150 Days 0.000000 % 0.000000 % |  |  |
| 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 0.000000 % | 0.000000 % |
| 0.000000 % 0.000000 % |  |  | 0.000000 % 0.000000 % |  |  | 0.000000 % 0.000000 % |  |  | 0.000000 % 0.000000 % |  |  | 0.000000% 0.000000 % |  |  |
| 2 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  | 0-29 Days | 0 | 0.00 | 0-29 Days | 0 | 0.00 | 0-29 Days | 0 | 0.00 | 0-29 Days | 0 | 0.00 |
| 30 Days 0 0.00 |  |  | 30 Days 0 0.00 |  |  | 30 Days 0 0.00 |  |  | 30 Days 0 0.00 |  |  | 30 Days 0 0.00 |  |  |
| 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 |
| 90 Days 0 0.00 |  |  | 90 Days 0 0.00 |  |  | 90 Days 0 0.00 |  |  | 90 Days 0 0.00 |  |  | 90 Days 0 0.00 |  |  |
| 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 |
| 150 Days 0 0.00 |  |  | 150 Days 0 0.00 |  |  | 150 Days 0 0.00 |  |  | 150 Days 0 0.00 |  |  | 150 Days 0 0.00 |  |  |
| 180+ Days | 0 | 0.00 | 180+ Days | 0 | 0.00 | 180+ Days | 0 | 0.00 | 180+ Days | 0 | 0.00 | 180+ Days | 0 | 0.00 |
| 0 0.00 |  |  | 0 0.00 |  |  | 0 0.00 |  |  | 0 0.00 |  |  | 0 0.00 |  |  |
|  |  |  | 0-29 Days | 0.000000 % | 0.000000 % | 0-29 Days | 0.000000 % | 0.000000 % | 0-29 Days | 0.000000 % | 0.000000 % | 0-29 Days | 0.000000 % | 0.000000 % |
| 30 Days 0.000000 % 0.000000 % |  |  | 30 Days 0.000000 % 0.000000 % |  |  | 30 Days 0.000000 % 0.000000 % |  |  | 30 Days 0.000000 % 0.000000 % |  |  | 30 Days 0.000000 % 0.000000 % |  |  |
| 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % |
| 90 Days 0.000000 % 0.000000 % |  |  | 90 Days 0.000000 % 0.000000 % |  |  | 90 Days 0.000000 % 0.000000 % |  |  | 90 Days 0.000000 % 0.000000 % |  |  | 90 Days 0.000000 % 0.000000 % |  |  |
| 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % |
| 150 Days 0.000000 % 0.000000 % |  |  | 150 Days 0.000000 % 0.000000 % |  |  | 150 Days 0.000000 % 0.000000 % |  |  | 150 Days 0.000000 % 0.000000 % |  |  | 150 Days 0.000000 % 0.000000 % |  |  |
| 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 0.000000 % | 0.000000 % |
| 0.000000 % 0.000000 % |  |  | 0.000000 % 0.000000 % |  |  | 0.000000 % 0.000000 % |  |  | 0.000000 % 0.000000 % |  |  | 0.000000% 0.000000 % |  |  |

--- Page 16 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
16-Jan-2026 10:13:21 AM
Delinquency Status By Group
© 2021 Computershare. All rights reserved. Confidential. Page 19 of 73

MASTR Adjustable Rate Mortgages Trust
Mortgage Pass-Through Certificates
Series 2004-3

| DELINQUENT |  |  | BANKRUPTCY |  |  | FORECLOSURE |  |  | REO |  |  | TOTAL |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | No of Loans | Actual Balance |  | No of Loans | Actual Balance |  | No of Loans | Actual Balance |  | No of Loans | Actual Balance |  | No of Loans | Actual Balance |
| 3 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  | 0-29 Days | 0 | 0.00 | 0-29 Days | 0 | 0.00 | 0-29 Days | 0 | 0.00 | 0-29 Days | 0 | 0.00 |
| 30 Days 1 166,964.95 |  |  | 30 Days 0 0.00 |  |  | 30 Days 0 0.00 |  |  | 30 Days 0 0.00 |  |  | 30 Days 1 166,964.95 |  |  |
| 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 |
| 90 Days 0 0.00 |  |  | 90 Days 0 0.00 |  |  | 90 Days 0 0.00 |  |  | 90 Days 0 0.00 |  |  | 90 Days 0 0.00 |  |  |
| 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 |
| 150 Days 0 0.00 |  |  | 150 Days 0 0.00 |  |  | 150 Days 0 0.00 |  |  | 150 Days 0 0.00 |  |  | 150 Days 0 0.00 |  |  |
| 180+ Days | 0 | 0.00 | 180+ Days | 0 | 0.00 | 180+ Days | 0 | 0.00 | 180+ Days | 0 | 0.00 | 180+ Days | 0 | 0.00 |
| 1 166,964.95 |  |  | 0 0.00 |  |  | 0 0.00 |  |  | 0 0.00 |  |  | 1 166,964.95 |  |  |
|  |  |  | 0-29 Days | 0.000000 % | 0.000000 % | 0-29 Days | 0.000000 % | 0.000000 % | 0-29 Days | 0.000000 % | 0.000000 % | 0-29 Days | 0.000000 % | 0.000000 % |
| 30 Days 16.666667 % 29.422206 % |  |  | 30 Days 0.000000 % 0.000000 % |  |  | 30 Days 0.000000 % 0.000000 % |  |  | 30 Days 0.000000 % 0.000000 % |  |  | 30 Days 16.666667 % 29.422206 % |  |  |
| 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % |
| 90 Days 0.000000 % 0.000000 % |  |  | 90 Days 0.000000 % 0.000000 % |  |  | 90 Days 0.000000 % 0.000000 % |  |  | 90 Days 0.000000 % 0.000000 % |  |  | 90 Days 0.000000 % 0.000000 % |  |  |
| 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % |
| 150 Days 0.000000 % 0.000000 % |  |  | 150 Days 0.000000 % 0.000000 % |  |  | 150 Days 0.000000 % 0.000000 % |  |  | 150 Days 0.000000 % 0.000000 % |  |  | 150 Days 0.000000 % 0.000000 % |  |  |
| 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 0.000000 % | 0.000000 % |
| 16.666667 % 29.422206 % |  |  | 0.000000 % 0.000000 % |  |  | 0.000000 % 0.000000 % |  |  | 0.000000 % 0.000000 % |  |  | 16.666667% 29.422206 % |  |  |
| 4 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  | 0-29 Days | 0 | 0.00 | 0-29 Days | 0 | 0.00 | 0-29 Days | 0 | 0.00 | 0-29 Days | 0 | 0.00 |
| 30 Days 0 0.00 |  |  | 30 Days 0 0.00 |  |  | 30 Days 0 0.00 |  |  | 30 Days 0 0.00 |  |  | 30 Days 0 0.00 |  |  |
| 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 |
| 90 Days 0 0.00 |  |  | 90 Days 0 0.00 |  |  | 90 Days 0 0.00 |  |  | 90 Days 0 0.00 |  |  | 90 Days 0 0.00 |  |  |
| 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 |
| 150 Days 0 0.00 |  |  | 150 Days 0 0.00 |  |  | 150 Days 0 0.00 |  |  | 150 Days 0 0.00 |  |  | 150 Days 0 0.00 |  |  |
| 180+ Days | 0 | 0.00 | 180+ Days | 0 | 0.00 | 180+ Days | 0 | 0.00 | 180+ Days | 0 | 0.00 | 180+ Days | 0 | 0.00 |
| 0 0.00 |  |  | 0 0.00 |  |  | 0 0.00 |  |  | 0 0.00 |  |  | 0 0.00 |  |  |
|  |  |  | 0-29 Days | 0.000000 % | 0.000000 % | 0-29 Days | 0.000000 % | 0.000000 % | 0-29 Days | 0.000000 % | 0.000000 % | 0-29 Days | 0.000000 % | 0.000000 % |
| 30 Days 0.000000 % 0.000000 % |  |  | 30 Days 0.000000 % 0.000000 % |  |  | 30 Days 0.000000 % 0.000000 % |  |  | 30 Days 0.000000 % 0.000000 % |  |  | 30 Days 0.000000 % 0.000000 % |  |  |
| 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % |
| 90 Days 0.000000 % 0.000000 % |  |  | 90 Days 0.000000 % 0.000000 % |  |  | 90 Days 0.000000 % 0.000000 % |  |  | 90 Days 0.000000 % 0.000000 % |  |  | 90 Days 0.000000 % 0.000000 % |  |  |
| 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % |
| 150 Days 0.000000 % 0.000000 % |  |  | 150 Days 0.000000 % 0.000000 % |  |  | 150 Days 0.000000 % 0.000000 % |  |  | 150 Days 0.000000 % 0.000000 % |  |  | 150 Days 0.000000 % 0.000000 % |  |  |
| 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 0.000000 % | 0.000000 % |
| 0.000000 % 0.000000 % |  |  | 0.000000 % 0.000000 % |  |  | 0.000000 % 0.000000 % |  |  | 0.000000 % 0.000000 % |  |  | 0.000000% 0.000000 % |  |  |

--- Page 17 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
16-Jan-2026 10:13:21 AM
Delinquency Status By Group
© 2021 Computershare. All rights reserved. Confidential. Page 20 of 73

MASTR Adjustable Rate Mortgages Trust
Mortgage Pass-Through Certificates
Series 2004-3

| DELINQUENT |  |  | BANKRUPTCY |  |  | FORECLOSURE |  |  | REO |  |  | TOTAL |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | No of Loans | Actual Balance |  | No of Loans | Actual Balance |  | No of Loans | Actual Balance |  | No of Loans | Actual Balance |  | No of Loans | Actual Balance |
| 5 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  | 0-29 Days | 0 | 0.00 | 0-29 Days | 0 | 0.00 | 0-29 Days | 0 | 0.00 | 0-29 Days | 0 | 0.00 |
| 30 Days 0 0.00 |  |  | 30 Days 0 0.00 |  |  | 30 Days 0 0.00 |  |  | 30 Days 0 0.00 |  |  | 30 Days 0 0.00 |  |  |
| 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 |
| 90 Days 0 0.00 |  |  | 90 Days 0 0.00 |  |  | 90 Days 0 0.00 |  |  | 90 Days 0 0.00 |  |  | 90 Days 0 0.00 |  |  |
| 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 |
| 150 Days 0 0.00 |  |  | 150 Days 0 0.00 |  |  | 150 Days 0 0.00 |  |  | 150 Days 0 0.00 |  |  | 150 Days 0 0.00 |  |  |
| 180+ Days | 0 | 0.00 | 180+ Days | 0 | 0.00 | 180+ Days | 0 | 0.00 | 180+ Days | 0 | 0.00 | 180+ Days | 0 | 0.00 |
| 0 0.00 |  |  | 0 0.00 |  |  | 0 0.00 |  |  | 0 0.00 |  |  | 0 0.00 |  |  |
|  |  |  | 0-29 Days | 0.000000 % | 0.000000 % | 0-29 Days | 0.000000 % | 0.000000 % | 0-29 Days | 0.000000 % | 0.000000 % | 0-29 Days | 0.000000 % | 0.000000 % |
| 30 Days 0.000000 % 0.000000 % |  |  | 30 Days 0.000000 % 0.000000 % |  |  | 30 Days 0.000000 % 0.000000 % |  |  | 30 Days 0.000000 % 0.000000 % |  |  | 30 Days 0.000000 % 0.000000 % |  |  |
| 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % |
| 90 Days 0.000000 % 0.000000 % |  |  | 90 Days 0.000000 % 0.000000 % |  |  | 90 Days 0.000000 % 0.000000 % |  |  | 90 Days 0.000000 % 0.000000 % |  |  | 90 Days 0.000000 % 0.000000 % |  |  |
| 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % |
| 150 Days 0.000000 % 0.000000 % |  |  | 150 Days 0.000000 % 0.000000 % |  |  | 150 Days 0.000000 % 0.000000 % |  |  | 150 Days 0.000000 % 0.000000 % |  |  | 150 Days 0.000000 % 0.000000 % |  |  |
| 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 0.000000 % | 0.000000 % |
| 0.000000 % 0.000000 % |  |  | 0.000000 % 0.000000 % |  |  | 0.000000 % 0.000000 % |  |  | 0.000000 % 0.000000 % |  |  | 0.000000% 0.000000 % |  |  |
| 6 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  | 0-29 Days | 1 | 311,772.41 | 0-29 Days | 0 | 0.00 | 0-29 Days | 0 | 0.00 | 0-29 Days | 1 | 311,772.41 |
| 30 Days 0 0.00 |  |  | 30 Days 0 0.00 |  |  | 30 Days 0 0.00 |  |  | 30 Days 0 0.00 |  |  | 30 Days 0 0.00 |  |  |
| 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 |
| 90 Days 0 0.00 |  |  | 90 Days 0 0.00 |  |  | 90 Days 0 0.00 |  |  | 90 Days 0 0.00 |  |  | 90 Days 0 0.00 |  |  |
| 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 |
| 150 Days 0 0.00 |  |  | 150 Days 0 0.00 |  |  | 150 Days 0 0.00 |  |  | 150 Days 0 0.00 |  |  | 150 Days 0 0.00 |  |  |
| 180+ Days | 0 | 0.00 | 180+ Days | 0 | 0.00 | 180+ Days | 0 | 0.00 | 180+ Days | 0 | 0.00 | 180+ Days | 0 | 0.00 |
| 0 0.00 |  |  | 1 311,772.41 |  |  | 0 0.00 |  |  | 0 0.00 |  |  | 1 311,772.41 |  |  |
|  |  |  | 0-29 Days | 10.000000 % | 19.142507 % | 0-29 Days | 0.000000 % | 0.000000 % | 0-29 Days | 0.000000 % | 0.000000 % | 0-29 Days | 10.000000 % | 19.142507 % |
| 30 Days 0.000000 % 0.000000 % |  |  | 30 Days 0.000000 % 0.000000 % |  |  | 30 Days 0.000000 % 0.000000 % |  |  | 30 Days 0.000000 % 0.000000 % |  |  | 30 Days 0.000000 % 0.000000 % |  |  |
| 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % |
| 90 Days 0.000000 % 0.000000 % |  |  | 90 Days 0.000000 % 0.000000 % |  |  | 90 Days 0.000000 % 0.000000 % |  |  | 90 Days 0.000000 % 0.000000 % |  |  | 90 Days 0.000000 % 0.000000 % |  |  |
| 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % |
| 150 Days 0.000000 % 0.000000 % |  |  | 150 Days 0.000000 % 0.000000 % |  |  | 150 Days 0.000000 % 0.000000 % |  |  | 150 Days 0.000000 % 0.000000 % |  |  | 150 Days 0.000000 % 0.000000 % |  |  |
| 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 0.000000 % | 0.000000 % |
| 0.000000 % 0.000000 % |  |  | 10.000000 % 19.142507 % |  |  | 0.000000 % 0.000000 % |  |  | 0.000000 % 0.000000 % |  |  | 10.000000% 19.142507 % |  |  |

--- Page 18 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
16-Jan-2026 10:13:21 AM
Delinquency Status By Group
Please refer to CTSLink.com for a list of delinquency code descriptions.
© 2021 Computershare. All rights reserved. Confidential. Page 21 of 73

MASTR Adjustable Rate Mortgages Trust
Mortgage Pass-Through Certificates
Series 2004-3

| DELINQUENT |  |  | BANKRUPTCY |  |  | FORECLOSURE |  |  | REO |  |  | TOTAL |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | No of Loans | Actual Balance |  | No of Loans | Actual Balance |  | No of Loans | Actual Balance |  | No of Loans | Actual Balance |  | No of Loans | Actual Balance |
| 7 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  | 0-29 Days | 0 | 0.00 | 0-29 Days | 0 | 0.00 | 0-29 Days | 0 | 0.00 | 0-29 Days | 0 | 0.00 |
| 30 Days 0 0.00 |  |  | 30 Days 0 0.00 |  |  | 30 Days 0 0.00 |  |  | 30 Days 0 0.00 |  |  | 30 Days 0 0.00 |  |  |
| 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 |
| 90 Days 0 0.00 |  |  | 90 Days 0 0.00 |  |  | 90 Days 0 0.00 |  |  | 90 Days 0 0.00 |  |  | 90 Days 0 0.00 |  |  |
| 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 |
| 150 Days 0 0.00 |  |  | 150 Days 0 0.00 |  |  | 150 Days 0 0.00 |  |  | 150 Days 0 0.00 |  |  | 150 Days 0 0.00 |  |  |
| 180+ Days | 0 | 0.00 | 180+ Days | 0 | 0.00 | 180+ Days | 0 | 0.00 | 180+ Days | 0 | 0.00 | 180+ Days | 0 | 0.00 |
| 0 0.00 |  |  | 0 0.00 |  |  | 0 0.00 |  |  | 0 0.00 |  |  | 0 0.00 |  |  |
|  |  |  | 0-29 Days | 0.000000 % | 0.000000 % | 0-29 Days | 0.000000 % | 0.000000 % | 0-29 Days | 0.000000 % | 0.000000 % | 0-29 Days | 0.000000 % | 0.000000 % |
| 30 Days 0.000000 % 0.000000 % |  |  | 30 Days 0.000000 % 0.000000 % |  |  | 30 Days 0.000000 % 0.000000 % |  |  | 30 Days 0.000000 % 0.000000 % |  |  | 30 Days 0.000000 % 0.000000 % |  |  |
| 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % |
| 90 Days 0.000000 % 0.000000 % |  |  | 90 Days 0.000000 % 0.000000 % |  |  | 90 Days 0.000000 % 0.000000 % |  |  | 90 Days 0.000000 % 0.000000 % |  |  | 90 Days 0.000000 % 0.000000 % |  |  |
| 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % |
| 150 Days 0.000000 % 0.000000 % |  |  | 150 Days 0.000000 % 0.000000 % |  |  | 150 Days 0.000000 % 0.000000 % |  |  | 150 Days 0.000000 % 0.000000 % |  |  | 150 Days 0.000000 % 0.000000 % |  |  |
| 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 0.000000 % | 0.000000 % |
| 0.000000 % 0.000000 % |  |  | 0.000000 % 0.000000 % |  |  | 0.000000 % 0.000000 % |  |  | 0.000000 % 0.000000 % |  |  | 0.000000% 0.000000 % |  |  |
| 8 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  | 0-29 Days | 0 | 0.00 | 0-29 Days | 0 | 0.00 | 0-29 Days | 0 | 0.00 | 0-29 Days | 0 | 0.00 |
| 30 Days 1 113,732.24 |  |  | 30 Days 0 0.00 |  |  | 30 Days 0 0.00 |  |  | 30 Days 0 0.00 |  |  | 30 Days 1 113,732.24 |  |  |
| 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 |
| 90 Days 0 0.00 |  |  | 90 Days 0 0.00 |  |  | 90 Days 0 0.00 |  |  | 90 Days 0 0.00 |  |  | 90 Days 0 0.00 |  |  |
| 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 |
| 150 Days 0 0.00 |  |  | 150 Days 0 0.00 |  |  | 150 Days 0 0.00 |  |  | 150 Days 0 0.00 |  |  | 150 Days 0 0.00 |  |  |
| 180+ Days | 0 | 0.00 | 180+ Days | 0 | 0.00 | 180+ Days | 1 | 296,078.02 | 180+ Days | 0 | 0.00 | 180+ Days | 1 | 296,078.02 |
| 1 113,732.24 |  |  | 0 0.00 |  |  | 1 296,078.02 |  |  | 0 0.00 |  |  | 2 409,810.26 |  |  |
|  |  |  | 0-29 Days | 0.000000 % | 0.000000 % | 0-29 Days | 0.000000 % | 0.000000 % | 0-29 Days | 0.000000 % | 0.000000 % | 0-29 Days | 0.000000 % | 0.000000 % |
| 30 Days 20.000000 % 19.178173 % |  |  | 30 Days 0.000000 % 0.000000 % |  |  | 30 Days 0.000000 % 0.000000 % |  |  | 30 Days 0.000000 % 0.000000 % |  |  | 30 Days 20.000000 % 19.178173 % |  |  |
| 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % |
| 90 Days 0.000000 % 0.000000 % |  |  | 90 Days 0.000000 % 0.000000 % |  |  | 90 Days 0.000000 % 0.000000 % |  |  | 90 Days 0.000000 % 0.000000 % |  |  | 90 Days 0.000000 % 0.000000 % |  |  |
| 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % |
| 150 Days 0.000000 % 0.000000 % |  |  | 150 Days 0.000000 % 0.000000 % |  |  | 150 Days 0.000000 % 0.000000 % |  |  | 150 Days 0.000000 % 0.000000 % |  |  | 150 Days 0.000000 % 0.000000 % |  |  |
| 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 20.000000 % | 49.926349 % | 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 20.000000 % | 49.926349 % |
| 20.000000 % 19.178173 % |  |  | 0.000000 % 0.000000 % |  |  | 20.000000 % 49.926349 % |  |  | 0.000000 % 0.000000 % |  |  | 40.000000% 69.104521 % |  |  |

--- Page 19 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
16-Jan-2026 10:13:21 AM
180+ Delinquency Summary
© 2021 Computershare. All rights reserved. Confidential. Page 22 of 73

MASTR Adjustable Rate Mortgages Trust
Mortgage Pass-Through Certificates
Series 2004-3

|  | Summary |  |  | 1 |  |  | 2 |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Days Delinquent | Number of Loans | Outstanding Actual Balance($) | Percentage Of Balance(%) | Number of Loans | Outstanding Actual Balance($) | Percentage Of Balance(%) | Number of Loans | Outstanding Actual Balance($) | Percentage Of Balance(%) |
| 6540 - 6569 | 1 | 296,078.02 | 6.880 | 0 | 0.00 | 0.000 | 0 | 0.00 | 0.000 |
| Total | 1 | 296,078.02 | 6.880 | 0 | 0.00 | 0.000 | 0 | 0.00 | 0.000 |

--- Page 20 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
16-Jan-2026 10:13:21 AM
180+ Delinquency Summary
© 2021 Computershare. All rights reserved. Confidential. Page 23 of 73

MASTR Adjustable Rate Mortgages Trust
Mortgage Pass-Through Certificates
Series 2004-3

|  | 3 |  |  | 4 |  |  | 5 |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Days Delinquent | Number of Loans | Outstanding Actual Balance($) | Percentage Of Balance(%) | Number of Loans | Outstanding Actual Balance($) | Percentage Of Balance(%) | Number of Loans | Outstanding Actual Balance($) | Percentage Of Balance(%) |
| 6540 - 6569 | 0 | 0.00 | 0.000 | 0 | 0.00 | 0.000 | 0 | 0.00 | 0.000 |
| Total | 0 | 0.00 | 0.000 | 0 | 0.00 | 0.000 | 0 | 0.00 | 0.000 |

--- Page 21 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
16-Jan-2026 10:13:21 AM
180+ Delinquency Summary
This report includes all loans greater than 180 days delinquent regardless of status (REO, Foreclosure, Bankruptcy)
© 2021 Computershare. All rights reserved. Confidential. Page 24 of 73

MASTR Adjustable Rate Mortgages Trust
Mortgage Pass-Through Certificates
Series 2004-3

|  | 6 |  |  | 7 |  |  | 8 |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Days Delinquent | Number of Loans | Outstanding Actual Balance($) | Percentage Of Balance(%) | Number of Loans | Outstanding Actual Balance($) | Percentage Of Balance(%) | Number of Loans | Outstanding Actual Balance($) | Percentage Of Balance(%) |
| 6540 - 6569 | 0 | 0.00 | 0.000 | 0 | 0.00 | 0.000 | 1 | 296,078.02 | 49.926 |
| Total | 0 | 0.00 | 0.000 | 0 | 0.00 | 0.000 | 1 | 296,078.02 | 49.926 |

--- Page 22 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
16-Jan-2026 10:13:21 AM
© 2021 Computershare. All rights reserved. Confidential. Page 31 of 73

MASTR Adjustable Rate Mortgages Trust
Mortgage Pass-Through Certificates
Series 2004-3

Realized Loss Report - Collateral
Summary
MDR SDA Current Month 0.000 % Current Month 0.000 % 3 Month Average 0.000 % 3 Month Average 0.000 % 12 Month Average 0.000 % 12 Month Average 0.000 %
CDR | Loss Severity
Current Month | 0.000 % | Current Month (Cumulative) | 16.185 %
3 Month Average | 0.000 % | 3 Month Average (Cumulative) | 16.198 %
12 Month Average | 0.000 % | 12 Month Average (Cumulative) | 16.203 %

--- Page 23 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
16-Jan-2026 10:13:22 AM
© 2021 Computershare. All rights reserved. Confidential. Page 32 of 73

MASTR Adjustable Rate Mortgages Trust
Mortgage Pass-Through Certificates
Series 2004-3

Realized Loss Report - Collateral
1
MDR SDA Current Month 0.000 % Current Month 0.000 % 3 Month Average 0.000 % 3 Month Average 0.000 % 12 Month Average 0.000 % 12 Month Average 0.000 %
CDR | Loss Severity
Current Month | 0.000 % | Current Month (Cumulative) | 2.405 %
3 Month Average | 0.000 % | 3 Month Average (Cumulative) | 2.419 %
12 Month Average | 0.000 % | 12 Month Average (Cumulative) | 2.424 %

--- Page 24 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
16-Jan-2026 10:13:22 AM
© 2021 Computershare. All rights reserved. Confidential. Page 33 of 73

MASTR Adjustable Rate Mortgages Trust
Mortgage Pass-Through Certificates
Series 2004-3

Realized Loss Report - Collateral
2
MDR SDA Current Month 0.000 % Current Month 0.000 % 3 Month Average 0.000 % 3 Month Average 0.000 % 12 Month Average 0.000 % 12 Month Average 0.000 %
CDR | Loss Severity
Current Month | 0.000 % | Current Month (Cumulative) | 30.469 %
3 Month Average | 0.000 % | 3 Month Average (Cumulative) | 30.469 %
12 Month Average | 0.000 % | 12 Month Average (Cumulative) | 30.469 %

--- Page 25 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
16-Jan-2026 10:13:22 AM
© 2021 Computershare. All rights reserved. Confidential. Page 34 of 73

MASTR Adjustable Rate Mortgages Trust
Mortgage Pass-Through Certificates
Series 2004-3

Realized Loss Report - Collateral
3
MDR SDA Current Month 0.000 % Current Month 0.000 % 3 Month Average 0.000 % 3 Month Average 0.000 % 12 Month Average 0.000 % 12 Month Average 0.000 %
CDR | Loss Severity
Current Month | 0.000 % | Current Month (Cumulative) | 21.982 %
3 Month Average | 0.000 % | 3 Month Average (Cumulative) | 21.982 %
12 Month Average | 0.000 % | 12 Month Average (Cumulative) | 21.982 %

--- Page 26 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
16-Jan-2026 10:13:22 AM
© 2021 Computershare. All rights reserved. Confidential. Page 35 of 73

MASTR Adjustable Rate Mortgages Trust
Mortgage Pass-Through Certificates
Series 2004-3

Realized Loss Report - Collateral
4
MDR SDA Current Month 0.000 % Current Month 0.000 % 3 Month Average 0.000 % 3 Month Average 0.000 % 12 Month Average 0.000 % 12 Month Average 0.000 %
CDR | Loss Severity
Current Month | 0.000 % | Current Month (Cumulative) | 7.961 %
3 Month Average | 0.000 % | 3 Month Average (Cumulative) | 7.961 %
12 Month Average | 0.000 % | 12 Month Average (Cumulative) | 7.961 %

--- Page 27 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
16-Jan-2026 10:13:23 AM
© 2021 Computershare. All rights reserved. Confidential. Page 36 of 73

MASTR Adjustable Rate Mortgages Trust
Mortgage Pass-Through Certificates
Series 2004-3

Realized Loss Report - Collateral
5
MDR SDA Current Month 0.000 % Current Month 0.000 % 3 Month Average 0.000 % 3 Month Average 0.000 % 12 Month Average 0.000 % 12 Month Average 0.000 %
CDR | Loss Severity
Current Month | 0.000 % | Current Month (Cumulative) | 9.836 %
3 Month Average | 0.000 % | 3 Month Average (Cumulative) | 9.836 %
12 Month Average | 0.000 % | 12 Month Average (Cumulative) | 9.838 %

--- Page 28 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
16-Jan-2026 10:13:23 AM
© 2021 Computershare. All rights reserved. Confidential. Page 37 of 73

MASTR Adjustable Rate Mortgages Trust
Mortgage Pass-Through Certificates
Series 2004-3

Realized Loss Report - Collateral
6
MDR SDA Current Month 0.000 % Current Month 0.000 % 3 Month Average 0.000 % 3 Month Average 0.000 % 12 Month Average 0.000 % 12 Month Average 0.000 %
CDR | Loss Severity
Current Month | 0.000 % | Current Month (Cumulative) | 17.425 %
3 Month Average | 0.000 % | 3 Month Average (Cumulative) | 17.425 %
12 Month Average | 0.000 % | 12 Month Average (Cumulative) | 17.426 %

--- Page 29 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
16-Jan-2026 10:13:23 AM
© 2021 Computershare. All rights reserved. Confidential. Page 38 of 73

MASTR Adjustable Rate Mortgages Trust
Mortgage Pass-Through Certificates
Series 2004-3

Realized Loss Report - Collateral
7
MDR SDA Current Month 0.000 % Current Month 0.000 % 3 Month Average 0.000 % 3 Month Average 0.000 % 12 Month Average 0.000 % 12 Month Average 0.000 %
CDR | Loss Severity
Current Month | 0.000 % | Current Month (Cumulative) | 10.774 %
3 Month Average | 0.000 % | 3 Month Average (Cumulative) | 10.774 %
12 Month Average | 0.000 % | 12 Month Average (Cumulative) | 10.774 %

--- Page 30 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
16-Jan-2026 10:13:24 AM
Calculation Methodology:
Monthly Default Rate (MDR): Sum(Beg Scheduled Balance of Liquidated Loans) / Sum(Beg Scheduled Balance).
Conditional Default Rate (CDR): 1-((1-MDR)^12)
SDA Standard Default Assumption: If WAS ≤ 30 then CDR / (WAS * 0.02) else if 30 < WAS ≤ 60 then CDR / 0.6 else if 60 < WAS ≤ 120 then CDR/(0.6 - ((WAS - 60) * 0.0095)) else if WAS > 120 then CDR/0.03
Cumulative Loss Severity: Sum(All Active & Inactive Realized Losses) / Sum(Active Loans or loans without a loss passed on or after liquidation: the Actual Ending Principal Balance as of the most recent cycle in
which a Realized Loss was passed; loans with a loss passed on or after the month of liquidation: the Actual Beginning Principal Balance from the cycle in which the loan was liquidated).
3 Month Average and 12 Month Average will not have values until the 3rd and 12th month respectively.
© 2021 Computershare. All rights reserved. Confidential. Page 39 of 73

MASTR Adjustable Rate Mortgages Trust
Mortgage Pass-Through Certificates
Series 2004-3

Realized Loss Report - Collateral
8
MDR SDA Current Month 0.000 % Current Month 0.000 % 3 Month Average 0.000 % 3 Month Average 0.000 % 12 Month Average 0.000 % 12 Month Average 0.000 %
CDR | Loss Severity
Current Month | 0.000 % | Current Month (Cumulative) | 28.683 %
3 Month Average | 0.000 % | 3 Month Average (Cumulative) | 28.683 %
12 Month Average | 0.000 % | 12 Month Average (Cumulative) | 28.683 %

--- Page 31 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
16-Jan-2026 10:13:24 AM
Prepayment Detail - Prepayments during Current Period
Prepayment Loan Detail - Prepayments during Current Period
© 2021 Computershare. All rights reserved. Confidential. Page 40 of 73

MASTR Adjustable Rate Mortgages Trust
Mortgage Pass-Through Certificates
Series 2004-3

| Summary |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | Loans Paid in Full |  |  | Repurchased Loans |  |  | Substitution Loans |  |  | Liquidated Loans |  |  | Curtailments |
|  | Count | Original Securitized Balance | Current Scheduled Balance | Count | Original Securitized Balance | Current Scheduled Balance | Count | Original Securitized Balance | Current Scheduled Balance | Count | Original Securitized Balance | Current Scheduled Balance | Curtailment Amount |
| 1 | 0 | 0.00 | 0.00 | 0 | 0.00 | 0.00 | 0 | 0.00 | 0.00 | 0 | 0.00 | 0.00 | 0.00 |
| 2 | 0 | 0.00 | 0.00 | 0 | 0.00 | 0.00 | 0 | 0.00 | 0.00 | 0 | 0.00 | 0.00 | 65.98 |
| 3 | 0 | 0.00 | 0.00 | 0 | 0.00 | 0.00 | 0 | 0.00 | 0.00 | 0 | 0.00 | 0.00 | 100.61 |
| 4 | 0 | 0.00 | 0.00 | 0 | 0.00 | 0.00 | 0 | 0.00 | 0.00 | 0 | 0.00 | 0.00 | 0.00 |
| 5 | 0 | 0.00 | 0.00 | 0 | 0.00 | 0.00 | 0 | 0.00 | 0.00 | 0 | 0.00 | 0.00 | 102.15 |
| 6 | 0 | 0.00 | 0.00 | 0 | 0.00 | 0.00 | 0 | 0.00 | 0.00 | 0 | 0.00 | 0.00 | 0.00 |
| 7 | 0 | 0.00 | 0.00 | 0 | 0.00 | 0.00 | 0 | 0.00 | 0.00 | 0 | 0.00 | 0.00 | 0.00 |
| 8 | 0 | 0.00 | 0.00 | 0 | 0.00 | 0.00 | 0 | 0.00 | 0.00 | 0 | 0.00 | 0.00 | 301.72 |
| Total | 0 | 0.00 | 0.00 | 0 | 0.00 | 0.00 | 0 | 0.00 | 0.00 | 0 | 0.00 | 0.00 | 570.46 |

| Group | Loan Number | State | LTV at Origination | First Payment Date | Original Securitized Balance | Prepayment Amount | Resolution Type | Months Delinquent | Current Loan Rate | Original Term | Seasoning |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| No Prepayments in Full this Period |  |  |  |  |  |  |  |  |  |  |  |

--- Page 32 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
16-Jan-2026 10:13:24 AM
Prepayment Penalty Loan Detail - Prepayment Penalty Paid during Current Period
© 2021 Computershare. All rights reserved. Confidential. Page 41 of 73

MASTR Adjustable Rate Mortgages Trust
Mortgage Pass-Through Certificates
Series 2004-3

Prepayment Penalty Detail - Prepayment Penalty Paid during Current Period

| Summary | Loan Count | Prior Balance | Prepayment Penalty Amount | Prepayment Penalty Waived |
| --- | --- | --- | --- | --- |
| Total | 0 | 0.00 | 0.00 | 0.00 |

| Group | Loan Number | Paid In Full Date | Prior Balance | Prepayment Penalty Amount | Prepayment Penalty Waived |
| --- | --- | --- | --- | --- | --- |
| No Prepayment Penalties this period |  |  |  |  |  |

--- Page 33 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
16-Jan-2026 10:13:24 AM
Prepayment Rates
© 2021 Computershare. All rights reserved. Confidential. Page 42 of 73

MASTR Adjustable Rate Mortgages Trust
Mortgage Pass-Through Certificates
Series 2004-3

Summary
SMM CPR PSA Current Month 0.013 % Current Month 0.161 % Current Month 2.687 % 3 Month Average 0.334 % 3 Month Average 3.802 % 3 Month Average 63.368 % 12 Month Average 0.421 % 12 Month Average 4.271 % 12 Month Average 71.190 %
1
SMM CPR PSA Current Month 0.000 % Current Month 0.000 % Current Month 0.000 % 3 Month Average 5.203 % 3 Month Average 28.983 % 3 Month Average 483.055 % 12 Month Average 1.302 % 12 Month Average 7.256 % 12 Month Average 120.936 %

--- Page 34 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
16-Jan-2026 10:13:25 AM
Prepayment Rates
© 2021 Computershare. All rights reserved. Confidential. Page 43 of 73

MASTR Adjustable Rate Mortgages Trust
Mortgage Pass-Through Certificates
Series 2004-3

2
SMM CPR PSA Current Month 0.235 % Current Month 2.785 % Current Month 46.412 % 3 Month Average 0.233 % 3 Month Average 2.757 % 3 Month Average 45.951 % 12 Month Average 0.219 % 12 Month Average 2.597 % 12 Month Average 43.279 %
3
SMM CPR PSA Current Month 0.018 % Current Month 0.215 % Current Month 3.577 % 3 Month Average 0.018 % 3 Month Average 0.217 % 3 Month Average 3.624 % 12 Month Average 0.019 % 12 Month Average 0.230 % 12 Month Average 3.840 %

--- Page 35 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
16-Jan-2026 10:13:25 AM
Prepayment Rates
© 2021 Computershare. All rights reserved. Confidential. Page 44 of 73

MASTR Adjustable Rate Mortgages Trust
Mortgage Pass-Through Certificates
Series 2004-3

4
SMM CPR PSA Current Month 0.000 % Current Month 0.000 % Current Month 0.000 % 3 Month Average 0.000 % 3 Month Average 0.000 % 3 Month Average 0.000 % 12 Month Average 1.578 % 12 Month Average 7.662 % 12 Month Average 127.702 %
5
SMM CPR PSA Current Month 0.466 % Current Month 5.447 % Current Month 90.780 % 3 Month Average 0.460 % 3 Month Average 5.382 % 3 Month Average 89.699 % 12 Month Average 0.441 % 12 Month Average 5.145 % 12 Month Average 85.750 %

--- Page 36 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
16-Jan-2026 10:13:25 AM
Prepayment Rates
© 2021 Computershare. All rights reserved. Confidential. Page 45 of 73

MASTR Adjustable Rate Mortgages Trust
Mortgage Pass-Through Certificates
Series 2004-3

6
SMM CPR PSA Current Month 0.000 % Current Month 0.000 % Current Month 0.000 % 3 Month Average 0.001 % 3 Month Average 0.010 % 3 Month Average 0.172 % 12 Month Average 0.008 % 12 Month Average 0.097 % 12 Month Average 1.611 %
7
SMM CPR PSA Current Month 0.000 % Current Month 0.000 % Current Month 0.000 % 3 Month Average 0.000 % 3 Month Average 0.000 % 3 Month Average 0.000 % 12 Month Average 0.018 % 12 Month Average 0.219 % 12 Month Average 3.652 %

--- Page 37 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
16-Jan-2026 10:13:26 AM
Prepayment Rates
Calculation Methodology:
Single Month Mortality (SMM): (Partial and full prepayments + Repurchases) / (Beginning Scheduled Balance - Scheduled Principal)
Conditional PrePayment Rate (CPR): 1 - ((1 - SMM)^12)
PSA Standard Prepayment Model: 100 * CPR / (0.2 * MIN(30,WAS))
Weighted Average Seasoning (WAS): sum((Original Term - Remaining Term)*(Current Scheduled Balance/Deal Scheduled Principal Balance))
© 2021 Computershare. All rights reserved. Confidential. Page 46 of 73

MASTR Adjustable Rate Mortgages Trust
Mortgage Pass-Through Certificates
Series 2004-3

8
SMM CPR PSA Current Month 0.055 % Current Month 0.654 % Current Month 10.896 % 3 Month Average 0.054 % 3 Month Average 0.651 % 3 Month Average 10.843 % 12 Month Average 0.053 % 12 Month Average 0.637 % 12 Month Average 10.618 %

--- Page 38 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
16-Jan-2026 10:13:26 AM
© 2021 Computershare. All rights reserved. Confidential. Page 48 of 73

MASTR Adjustable Rate Mortgages Trust
Mortgage Pass-Through Certificates
Series 2004-3

Modification Detail

| Modification Detail Summary |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | Current |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Cumulative |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Groups | Loan Count |  |  | Original Securitized Balance |  |  | Current Scheduled Balance |  |  | Capitalized Amount |  |  | Capitalized Reimbursement Amount |  |  |  |  | Total Forgiveness |  |  | Loan Count |  | Original Securitized Balance |  |  | Current Scheduled Balance |  |  | Capitalized Amount |  | Capitalized Reimbursement Amount |  |  | Total Forgiveness |  |
| 1 | 0 |  |  | 0.00 |  |  | 0.00 |  |  | 0.00 |  |  | 0.00 |  |  |  |  | 0.00 |  |  | 2 |  | 1,205,000.00 |  |  | 221,726.79 |  |  | 85,222.65 |  | 0.01 |  |  | 0.00 |  |
| 2 | 0 |  |  | 0.00 |  |  | 0.00 |  |  | 0.00 |  |  | 0.00 |  |  |  |  | 0.00 |  |  | 1 |  | 427,000.00 |  |  | 0.00 |  |  | 308,279.02 |  | (3.05) |  |  | 0.00 |  |
| 3 | 0 |  |  | 0.00 |  |  | 0.00 |  |  | 0.00 |  |  | 0.00 |  |  |  |  | 0.00 |  |  | 7 |  | 1,209,070.00 |  |  | 195,981.69 |  |  | 76,071.44 |  | (67,867.07) |  |  | 25,431.93 |  |
| 4 | 0 |  |  | 0.00 |  |  | 0.00 |  |  | 0.00 |  |  | 0.00 |  |  |  |  | 0.00 |  |  | 4 |  | 2,270,600.00 |  |  | 415,781.00 |  |  | 108,634.03 |  | (98,503.72) |  |  | 500.15 |  |
| 5 | 0 |  |  | 0.00 |  |  | 0.00 |  |  | 0.00 |  |  | 0.00 |  |  |  |  | 0.00 |  |  | 3 |  | 809,400.00 |  |  | 0.00 |  |  | 12,484.30 |  | (21,123.77) |  |  | 0.00 |  |
| 6 | 0 |  |  | 0.00 |  |  | 0.00 |  |  | 0.00 |  |  | 0.00 |  |  |  |  | 0.00 |  |  | 8 |  | 2,796,250.00 |  |  | 1,416,731.95 |  |  | 528,960.49 |  | (274,839.56) |  |  | 0.00 |  |
| 7 | 0 |  |  | 0.00 |  |  | 0.00 |  |  | 0.00 |  |  | 0.00 |  |  |  |  | 0.00 |  |  | 0 |  | 0.00 |  |  | 0.00 |  |  | 0.00 |  | 0.00 |  |  | 0.00 |  |
| 8 | 0 |  |  | 0.00 |  |  | 0.00 |  |  | 0.00 |  |  | 0.00 |  |  |  |  | 0.00 |  |  | 1 |  | 246,400.00 |  |  | 0.00 |  |  | 0.00 |  | (23,345.12) |  |  | 0.00 |  |
| Total | 0 |  |  | 0.00 |  |  | 0.00 |  |  | 0.00 |  |  | 0.00 |  |  |  |  | 0.00 |  |  | 26 |  | 8,963,720.00 |  |  | 2,250,221.43 |  |  | 1,119,651.93 |  | (485,682.28) |  |  | 25,932.08 |  |
| Current Month Modification Detail |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Loan Number/ Original Balance |  |  | Mod Appr Date/Mod Effective Date |  |  | Total Capitalized Amount |  |  | Total Capitalized Reimb. Amount |  |  | Total Forgiveness |  |  | No of Times Loan Modified |  |  |  | No of Months Delinq. |  | Loan Status |  |  | Next Due Date |  |  | Interest Rate | Payment Amount |  | Maturity Date |  | Balloon Amount | Balloon Date |  | Scheduled Balance |
| No Modifications this Period |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Historical Modification Detail |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Loan Number/ Original Balance |  | Mod Appr Date/Mod Effective Date |  |  | Total Capitalized Amount |  |  | Total Capitalized Reimb. Amount |  |  | Total Forgiveness |  |  | No of Times Loan Modified |  |  |  |  |  | No of Months Delinq. |  | Loan Status |  |  | Next Due Date |  | Interest Rate | Payment Amount |  | Maturity Date |  | Balloon Amount | Balloon Date |  | Scheduled Balance |
| 1 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 0000234164 |  | 05/11/2020 |  |  |  |  |  |  |  |  |  |  |  |  |  | Pre Mod |  |  |  | 0 |  | No Action |  |  | 04/01/2020 |  | 3.125 | 3,451.43 |  | 01/01/2034 |  | * | * |  | 462,446.80 |
| 625,000.00 |  | 05/01/2020 |  |  | 3,451.43 |  |  | 0.00 |  |  | * |  |  |  |  | Post Mod |  |  |  | 0 |  | No Action |  |  | 05/01/2020 |  | 3.125 | 3,451.43 |  | 01/01/2034 |  | 0.00 | * |  | 463,651.09 |

--- Page 39 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
16-Jan-2026 10:13:26 AM
Collateral Balance Detail
© 2021 Computershare. All rights reserved. Confidential. Page 64 of 73

MASTR Adjustable Rate Mortgages Trust
Mortgage Pass-Through Certificates
Series 2004-3

| Group | 1 | 2 | 3 | 4 | 5 | 6 |
| --- | --- | --- | --- | --- | --- | --- |
| Beginning Scheduled Balance: IB | 176,591.88 | 28,288.16 | 566,502.80 | 741,828.14 | 22,109.26 | 1,558,993.48 |
| Beginning NIB Non-Loss Balance | 46,574.19 | 0.00 | 0.00 | 5,730.28 | 0.00 | 69,698.15 |
| Beginning Scheduled Balance: Trust | 223,166.07 | 28,288.16 | 566,502.80 | 747,558.42 | 22,109.26 | 1,628,691.63 |
| Beginning NIB Loss Balance | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| Beginning Scheduled Balance: TDO | 223,166.07 | 28,288.16 | 566,502.80 | 747,558.42 | 22,109.26 | 1,628,691.63 |

| Ending Scheduled Balance: IB | 175,152.60 | 28,001.54 | 561,873.18 | 738,617.89 | 21,835.35 | 1,552,727.20 |
| --- | --- | --- | --- | --- | --- | --- |
| Ending NIB Non-Loss Balance | 46,574.19 | 0.00 | 0.00 | 5,730.28 | 0.00 | 69,698.15 |
| Ending Scheduled Balance: Trust | 221,726.79 | 28,001.54 | 561,873.18 | 744,348.17 | 21,835.35 | 1,622,425.35 |
| Ending NIB Loss Balance | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| Ending Scheduled Balance: TDO | 221,726.79 | 28,001.54 | 561,873.18 | 744,348.17 | 21,835.35 | 1,622,425.35 |

| Ending Actual Balance: IB | 176,591.88 | 28,222.56 | 567,479.37 | 741,828.14 | 22,007.69 | 1,558,993.48 |
| --- | --- | --- | --- | --- | --- | --- |
| Ending NIB Non-Loss Balance | 46,574.19 | 0.00 | 0.00 | 5,730.28 | 0.00 | 69,698.15 |
| Ending Actual Balance: Trust | 223,166.07 | 28,222.56 | 567,479.37 | 747,558.42 | 22,007.69 | 1,628,691.63 |
| Ending NIB Loss Balance | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| Ending Actual Balance: TDO | 223,166.07 | 28,222.56 | 567,479.37 | 747,558.42 | 22,007.69 | 1,628,691.63 |

--- Page 40 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
16-Jan-2026 10:13:26 AM
Collateral Balance Detail
Balance Methodology:
IB: Interest Bearing
NIB: Non-Interest Bearing
NIB Non-Loss Balance: current balance of NIB amounts that were not treated as a loss at the time of the related modification
Trust Balance = IB Balance + NIB Non-Loss Balance
NIB Loss Balance: current balance of NIB amounts that were treated as a loss at the time of the related modification
TDO: Total Debt Owed = IB Balance + NIB Non-Loss Balance + NIB Loss Balance
NOTE: In addition to modifications included in this reporting package, Servicer(s) may utilize other loss mitigation options with borrowers. Please see the External Collateral File loan level data reported separately
on CTSLink® for additional reporting.
NOTE: ** See Information Regarding Collateral Balance Detail Reporting and Non-Interest Bearing Detail set forth in the Supplemental Reporting below.
© 2021 Computershare. All rights reserved. Confidential. Page 65 of 73

MASTR Adjustable Rate Mortgages Trust
Mortgage Pass-Through Certificates
Series 2004-3

| Group | 7 | 8 | Total |
| --- | --- | --- | --- |
| Beginning Scheduled Balance: IB | 493,323.81 | 554,566.39 | 4,142,203.92 |
| Beginning NIB Non-Loss Balance | 0.00 | 0.00 | 122,002.62 |
| Beginning Scheduled Balance: Trust | 493,323.81 | 554,566.39 | 4,264,206.54 |
| Beginning NIB Loss Balance | 0.00 | 0.00 | 0.00 |
| Beginning Scheduled Balance: TDO | 493,323.81 | 554,566.39 | 4,264,206.54 |

| Ending Scheduled Balance: IB | 490,977.25 | 551,847.14 | 4,121,032.15 |
| --- | --- | --- | --- |
| Ending NIB Non-Loss Balance | 0.00 | 0.00 | 122,002.62 |
| Ending Scheduled Balance: Trust | 490,977.25 | 551,847.14 | 4,243,034.77 |
| Ending NIB Loss Balance | 0.00 | 0.00 | 0.00 |
| Ending Scheduled Balance: TDO | 490,977.25 | 551,847.14 | 4,243,034.77 |

| Ending Actual Balance: IB | 493,005.62 | 593,029.59 | 4,181,158.33 |
| --- | --- | --- | --- |
| Ending NIB Non-Loss Balance | 0.00 | 0.00 | 122,002.62 |
| Ending Actual Balance: Trust | 493,005.62 | 593,029.59 | 4,303,160.95 |
| Ending NIB Loss Balance | 0.00 | 0.00 | 0.00 |
| Ending Actual Balance: TDO | 493,005.62 | 593,029.59 | 4,303,160.95 |