--- Page 1 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
13-Jan-2026 8:17:34 AM
Certificateholder Distribution Summary
© 2021 Computershare. All rights reserved. Confidential. Page 1 of 55

Banc of America Funding Corporation
Mortgage Pass-Through Certificates
Series 2006-1

| Class | CUSIP | Record Date | Certificate Pass-Through Rate | Beginning Certificate Balance | Interest Distribution | Principal Distribution | Current Realized Loss/Write Down | Ending Certificate Balance | Total Distribution | Cumulative Realized Losses/Write Down |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1-A-1 | 05949TAA7 | 12/31/2025 | 5.75000% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 1-A-2 | 05949TAB5 | 12/31/2025 | 5.75000% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 1-A-3 | 05949TAC3 | 12/31/2025 | 5.75000% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 1-A-4 | 05949TAD1 | 12/31/2025 | 5.75000% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 1-A-5 | 05949TAE9 | 12/31/2025 | 5.50000% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 1-A-6 | 05949TAF6 | 12/31/2025 | 6.00000% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 1-A-7 | 05949TAG4 | 12/31/2025 | 5.75000% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 1-A-8 | 05949TAH2 | 12/31/2025 | 5.75000% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 1-A-9 | 05949TAJ8 | 12/31/2025 | 5.75000% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 1-A-10 | 05949TAK5 | 12/31/2025 | 5.75000% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 1-A-11 | 05949TAL3 | 12/31/2025 | 5.75000% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 1-A-12 | 05949TAM1 | 12/31/2025 | 5.75000% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 1-A-13 | 05949TAN9 | 12/31/2025 | 5.25000% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 1-A-14 | 05949TAP4 | 12/31/2025 | 6.25000% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 1-A-15 | 05949TAQ2 | 12/31/2025 | 5.75000% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 1-A-16 | 05949TAR0 | 12/31/2025 | 5.75000% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 1-A-17 | 05949TBY4 | 12/31/2025 | 5.75000% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 1-A-18 | 05949TAS8 | 12/31/2025 | 5.50000% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 1-A-19 | 05949TAT6 | 12/31/2025 | 6.00000% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 1-A-20 | 05949TAU3 | 12/31/2025 | 4.74621% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 1-A-21 | 05949TAV1 | 12/31/2025 | 1.00379% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 1-A-22 | 05949TAW9 | 12/31/2025 | 5.75000% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 1-A-23 | 05949TAX7 | 12/31/2025 | 5.75000% | 2,256,722.90 | 10,813.46 | 10,960.67 | 0.00 | 2,245,762.23 | 21,774.13 | 0.00 |
| 1-A-24 | 05949TAY5 | 12/31/2025 | 5.75000% | 852,265.47 | 4,083.77 | 4,139.37 | 0.00 | 848,126.11 | 8,223.14 | 0.00 |
| 1-A-25 | 05949TAZ2 | 12/31/2025 | 5.75000% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |

--- Page 2 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
13-Jan-2026 8:17:34 AM
Certificateholder Distribution Summary
All Record Dates are based upon the governing documents and logic set forth as of closing.
This document is provided by Computershare Trust Company, N.A., or one or more of its affiliates (collectively, "Computershare"), in its named capacity or as agent of or successor to Wells Fargo Bank, N.A., or
one or more of its affiliates ("Wells Fargo"), by virtue of the acquisition by Computershare of substantially all the assets of the corporate trust services business of Wells Fargo. This report is compiled by
Computershare Trust Company, N.A. from information provided by third parties. Computershare Trust Company, N.A. has not independently confirmed the accuracy of the information.
Effective March 1, 2023 our Computershare Corporate Trust office located at 600 S 4th Street Minneapolis, MN 55415 has moved and our new address is 1505 Energy Park Drive St. Paul, Minnesota 55108. Please
update your records to reflect the new address.
© 2021 Computershare. All rights reserved. Confidential. Page 2 of 55

Banc of America Funding Corporation
Mortgage Pass-Through Certificates
Series 2006-1

| Class | CUSIP | Record Date | Certificate Pass-Through Rate | Beginning Certificate Balance | Interest Distribution | Principal Distribution | Current Realized Loss/Write Down | Ending Certificate Balance | Total Distribution | Cumulative Realized Losses/Write Down |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1-A-26 | 05949TBA6 | 12/31/2025 | 5.75000% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 1-A-27 | 05949TBB4 | 12/31/2025 | 5.50000% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 1-A-28 | 05949TBC2 | 12/31/2025 | 5.30000% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 2-A-1 | 05949TBD0 | 12/31/2025 | 5.50000% | 2,006,957.25 | 9,198.55 | 3,510.22 | 3,380.73 | 2,000,066.30 | 12,708.77 | 876,419.11 |
| 2-A-2 | 05949TBE8 | 12/31/2025 | 5.50000% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 729,503.83 |
| 3-A-1 | 05949TBF5 | 12/31/2025 | 5.50000% | 1,416,914.98 | 6,494.19 | 3,738.25 | 2,101.80 | 1,411,074.93 | 10,232.44 | 2,280,629.72 |
| 3-A-2 | 05949TBG3 | 12/31/2025 | 5.50000% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 431,409.75 |
| 3-A-R | 05949TBH1 | 12/31/2025 | 5.50000% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| X-PO | 05949TBK4 | 12/31/2025 | 0.00000% | 53,523.90 | 0.00 | 207.59 | 2.36 | 53,313.95 | 207.59 | 149,543.80 |
| X-IO | 05949TBJ7 | 12/31/2025 | 5.50000% | 0.00 | 838.52 | 0.00 | 0.00 | 0.00 | 838.52 | 0.00 |
| X-B-1 | 05949TBP3 | 12/31/2025 | 5.75000% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 7,185,910.91 |
| X-B-2 | 05949TBQ1 | 12/31/2025 | 5.75000% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 1,953,155.53 |
| X-B-3 | 05949TBR9 | 12/31/2025 | 5.75000% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 1,246,759.09 |
| X-B-4 | 05949TBV0 | 12/31/2025 | 5.75000% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 712,797.70 |
| X-B-5 | 05949TBW8 | 12/31/2025 | 5.75000% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 535,701.46 |
| X-B-6 | 05949TBX6 | 12/31/2025 | 5.75000% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 715,469.50 |
| B-1 | 05949TBL2 | 12/31/2025 | 5.50000% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 2,922,561.16 |
| B-2 | 05949TBM0 | 12/31/2025 | 5.50000% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 686,999.99 |
| B-3 | 05949TBN8 | 12/31/2025 | 5.50000% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 344,000.00 |
| B-4 | 05949TBS7 | 12/31/2025 | 5.50000% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 229,000.00 |
| B-5 | 05949TBT5 | 12/31/2025 | 5.50000% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 172,000.00 |
| B-6 | 05949TBU2 | 12/31/2025 | 5.50000% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 172,580.00 |
| Totals |  |  |  | 6,586,384.50 | 31,428.49 | 22,556.10 | 5,484.89 | 6,558,343.52 | 53,984.59 | 21,344,441.55 |

--- Page 3 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
13-Jan-2026 8:17:34 AM
© 2021 Computershare. All rights reserved. Confidential. Page 3 of 55

Banc of America Funding Corporation
Mortgage Pass-Through Certificates
Series 2006-1

| Principal Distribution Statement |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Class | Original Face Amount | Beginning Certificate Balance | Scheduled Principal Distribution | Unscheduled Principal Distribution | Accretion | Realized Loss/Write Down | Total Principal Reduction | Ending Certificate Balance | Ending Certificate Percentage | Total Principal Distribution |
| 1-A-1 | 12,759,000.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| 1-A-2 | 3,320,000.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| 1-A-3 | 579,000.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| 1-A-4 | 4,342,000.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| 1-A-5 | 2,000,000.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| 1-A-6 | 2,000,000.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| 1-A-7 | 118,000.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| 1-A-8 | 1,057,000.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| 1-A-9 | 1,000,000.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| 1-A-10 | 18,759,000.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| 1-A-11 | 1,524,000.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| 1-A-12 | 3,701,000.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| 1-A-13 | 1,008,000.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| 1-A-14 | 1,008,000.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| 1-A-15 | 775,000.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| 1-A-16 | 775,000.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| 1-A-17 | 775,000.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| 1-A-18 | 3,000,000.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| 1-A-19 | 3,000,000.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| 1-A-20 | 28,000,000.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| 1-A-21 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| 1-A-22 | 2,621,000.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| 1-A-23 | 50,178,000.00 | 2,256,722.90 | 10,960.67 | 0.00 | 0.00 | 0.00 | 10,960.67 | 2,245,762.23 | 0.04475591 | 10,960.67 |
| 1-A-24 | 6,023,000.00 | 852,265.47 | 4,139.37 | 0.00 | 0.00 | 0.00 | 4,139.37 | 848,126.11 | 0.14081456 | 4,139.37 |
| 1-A-25 | 41,542,000.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |

--- Page 4 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
13-Jan-2026 8:17:34 AM
NOTE: Accretion amount also includes Net Negative Amortization, if applicable.
© 2021 Computershare. All rights reserved. Confidential. Page 4 of 55

Banc of America Funding Corporation
Mortgage Pass-Through Certificates
Series 2006-1

| Principal Distribution Statement |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Class | Original Face Amount | Beginning Certificate Balance | Scheduled Principal Distribution | Unscheduled Principal Distribution | Accretion | Realized Loss/Write Down | Total Principal Reduction | Ending Certificate Balance | Ending Certificate Percentage | Total Principal Distribution |
| 1-A-26 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| 1-A-27 | 27,041,000.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| 1-A-28 | 35,000,000.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| 2-A-1 | 105,137,000.00 | 2,006,957.25 | 3,510.22 | 0.00 | 0.00 | 3,380.73 | 6,890.95 | 2,000,066.30 | 0.01902343 | 3,510.22 |
| 2-A-2 | 4,324,000.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| 3-A-1 | 92,989,000.00 | 1,416,914.98 | 3,738.25 | 0.00 | 0.00 | 2,101.80 | 5,840.05 | 1,411,074.93 | 0.01517464 | 3,738.25 |
| 3-A-2 | 3,373,000.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| 3-A-R | 100.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| X-PO | 7,023,913.00 | 53,523.90 | 207.59 | 0.00 | 0.00 | 2.36 | 209.95 | 53,313.95 | 0.00759035 | 207.59 |
| X-IO | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| X-B-1 | 7,535,000.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| X-B-2 | 2,021,000.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| X-B-3 | 1,287,000.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| X-B-4 | 735,000.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| X-B-5 | 551,000.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| X-B-6 | 735,601.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| B-1 | 2,923,000.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| B-2 | 687,000.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| B-3 | 344,000.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| B-4 | 229,000.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| B-5 | 172,000.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| B-6 | 172,580.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000 | 0.00 |
| Totals | 482,144,194.00 | 6,586,384.50 | 22,556.10 | 0.00 | 0.00 | 5,484.89 | 28,040.99 | 6,558,343.52 | 0.01360245 | 22,556.10 |

--- Page 5 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
13-Jan-2026 8:17:34 AM
© 2021 Computershare. All rights reserved. Confidential. Page 7 of 55

Banc of America Funding Corporation
Mortgage Pass-Through Certificates
Series 2006-1

Interest Distribution Statement

| Class | Accrual Dates | Accrual Days | Current Certificate Rate | Beginning Certificate/Notional Balance | Current Accrued Interest | Payment of Unpaid Interest Shortfall(1) | Basis Risk Shortfall | Interest Shortfall | Non- Supported Interest Shortfall | Total Interest Distribution | Remaining Unpaid Interest Shortfall(1) | Ending Certificate/ Notional Balance |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1-A-1 | N/A | N/A | 5.75000 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 1-A-2 | N/A | N/A | 5.75000 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 1-A-3 | N/A | N/A | 5.75000 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 1-A-4 | N/A | N/A | 5.75000 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 1-A-5 | N/A | N/A | 5.50000 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 1-A-6 | N/A | N/A | 6.00000 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 1-A-7 | N/A | N/A | 5.75000 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 1-A-8 | N/A | N/A | 5.75000 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 1-A-9 | N/A | N/A | 5.75000 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 1-A-10 | N/A | N/A | 5.75000 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 1-A-11 | N/A | N/A | 5.75000 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 1-A-12 | N/A | N/A | 5.75000 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 1-A-13 | N/A | N/A | 5.25000 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 1-A-14 | N/A | N/A | 6.25000 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 1-A-15 | N/A | N/A | 5.75000 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 1-A-16 | N/A | N/A | 5.75000 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 1-A-17 | N/A | N/A | 5.75000 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 1-A-18 | N/A | N/A | 5.50000 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 1-A-19 | N/A | N/A | 6.00000 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 1-A-20 | N/A | N/A | 4.74621 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 9,256.62 | 0.00 |
| 1-A-21 | N/A | N/A | 1.00379 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 1-A-22 | N/A | N/A | 5.75000 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 1-A-23 | 12/01/25 - 12/30/25 | 30 | 5.75000 % | 2,256,722.90 | 10,813.46 | 0.00 | 0.00 | 0.00 | 0.00 | 10,813.46 | 0.00 | 2,245,762.23 |
| 1-A-24 | 12/01/25 - 12/30/25 | 30 | 5.75000 % | 852,265.47 | 4,083.77 | 0.00 | 0.00 | 0.00 | 0.00 | 4,083.77 | 0.00 | 848,126.11 |
| 1-A-25 | N/A | N/A | 5.75000 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |

--- Page 6 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
13-Jan-2026 8:17:34 AM
(1) Amount also includes Coupon Cap or Basis Risk Shortfalls, if applicable.
© 2021 Computershare. All rights reserved. Confidential. Page 8 of 55

Banc of America Funding Corporation
Mortgage Pass-Through Certificates
Series 2006-1

Interest Distribution Statement

| Class | Accrual Dates | Accrual Days | Current Certificate Rate | Beginning Certificate/Notional Balance | Current Accrued Interest | Payment of Unpaid Interest Shortfall(1) | Basis Risk Shortfall | Interest Shortfall | Non- Supported Interest Shortfall | Total Interest Distribution | Remaining Unpaid Interest Shortfall(1) | Ending Certificate/ Notional Balance |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1-A-26 | N/A | N/A | 5.75000 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 1-A-27 | N/A | N/A | 5.50000 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 1-A-28 | N/A | N/A | 5.30000 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 2-A-1 | 12/01/25 - 12/30/25 | 30 | 5.50000 % | 2,006,957.25 | 9,198.55 | 0.00 | 0.00 | 0.00 | 0.00 | 9,198.55 | 0.00 | 2,000,066.30 |
| 2-A-2 | N/A | N/A | 5.50000 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 3-A-1 | 12/01/25 - 12/30/25 | 30 | 5.50000 % | 1,416,914.98 | 6,494.19 | 0.00 | 0.00 | 0.00 | 0.00 | 6,494.19 | 0.00 | 1,411,074.93 |
| 3-A-2 | N/A | N/A | 5.50000 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| 3-A-R | N/A | N/A | 5.50000 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| X-PO | N/A | N/A | 0.00000 % | 53,523.90 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 53,313.95 |
| X-IO | 12/01/25 - 12/30/25 | 30 | 5.50000 % | 182,949.41 | 838.52 | 0.00 | 0.00 | 0.00 | 0.00 | 838.52 | 0.00 | 182,263.24 |
| X-B-1 | N/A | N/A | 5.75000 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 527,809.88 | 0.00 |
| X-B-2 | N/A | N/A | 5.75000 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 109,500.48 | 0.00 |
| X-B-3 | N/A | N/A | 5.75000 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 27,765.56 | 0.00 |
| X-B-4 | N/A | N/A | 5.75000 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 8,644.23 | 0.00 |
| X-B-5 | N/A | N/A | 5.75000 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 2,547.66 | 0.00 |
| X-B-6 | N/A | N/A | 5.75000 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 345.50 | 0.00 |
| B-1 | N/A | N/A | 5.50000 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 194,303.73 | 0.00 |
| B-2 | N/A | N/A | 5.50000 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 49,212.35 | 0.00 |
| B-3 | N/A | N/A | 5.50000 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 10,435.61 | 0.00 |
| B-4 | N/A | N/A | 5.50000 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 2,461.23 | 0.00 |
| B-5 | N/A | N/A | 5.50000 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 144.87 | 0.00 |
| B-6 | N/A | N/A | 5.50000 % | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| Totals |  |  |  |  | 31,428.49 | 0.00 | 0.00 | 0.00 | 0.00 | 31,428.49 | 942,427.72 |  |

--- Page 7 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
13-Jan-2026 8:17:34 AM
© 2021 Computershare. All rights reserved. Confidential. Page 9 of 55

Banc of America Funding Corporation
Mortgage Pass-Through Certificates
Series 2006-1

Interest Distribution Factors Statement

| Class | Original Face Amount | Current Certificate Rate | Beginning Certificate/Notional Balance | Current Accrued Interest | Payment of Unpaid Interest Shortfall(1) | Basis Risk Shortfall | Interest Shortfall | Non- Supported Interest Shortfall | Total Interest Distribution | Remaining Unpaid Interest Shortfall(1) | Ending Certificate/ Notional Balance |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1-A-1 | 12,759,000.00 | 5.75000 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 |
| 1-A-2 | 3,320,000.00 | 5.75000 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 |
| 1-A-3 | 579,000.00 | 5.75000 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 |
| 1-A-4 | 4,342,000.00 | 5.75000 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 |
| 1-A-5 | 2,000,000.00 | 5.50000 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 |
| 1-A-6 | 2,000,000.00 | 6.00000 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 |
| 1-A-7 | 118,000.00 | 5.75000 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 |
| 1-A-8 | 1,057,000.00 | 5.75000 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 |
| 1-A-9 | 1,000,000.00 | 5.75000 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 |
| 1-A-10 | 18,759,000.00 | 5.75000 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 |
| 1-A-11 | 1,524,000.00 | 5.75000 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 |
| 1-A-12 | 3,701,000.00 | 5.75000 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 |
| 1-A-13 | 1,008,000.00 | 5.25000 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 |
| 1-A-14 | 1,008,000.00 | 6.25000 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 |
| 1-A-15 | 775,000.00 | 5.75000 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 |
| 1-A-16 | 775,000.00 | 5.75000 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 |
| 1-A-17 | 775,000.00 | 5.75000 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 |
| 1-A-18 | 3,000,000.00 | 5.50000 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 |
| 1-A-19 | 3,000,000.00 | 6.00000 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 |
| 1-A-20 | 28,000,000.00 | 4.74621 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.33059357 | 0.00000000 |
| 1-A-21 | 0.00 | 1.00379 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 |
| 1-A-22 | 2,621,000.00 | 5.75000 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 |
| 1-A-23 | 50,178,000.00 | 5.75000 % | 44.97434932 | 0.21550201 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.21550201 | 0.00000000 | 44.75591355 |
| 1-A-24 | 6,023,000.00 | 5.75000 % | 141.50182135 | 0.67802922 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.67802922 | 0.00000000 | 140.81456251 |
| 1-A-25 | 41,542,000.00 | 5.75000 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 |

--- Page 8 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
13-Jan-2026 8:17:34 AM
(1) Amount also includes Coupon Cap or Basis Risk Shortfalls, if applicable.
NOTE: All classes are per 1,000 dollar denomination.
© 2021 Computershare. All rights reserved. Confidential. Page 10 of 55

Banc of America Funding Corporation
Mortgage Pass-Through Certificates
Series 2006-1

Interest Distribution Factors Statement

| Class | Original Face Amount | Current Certificate Rate | Beginning Certificate/Notional Balance | Current Accrued Interest | Payment of Unpaid Interest Shortfall(1) | Basis Risk Shortfall | Interest Shortfall | Non- Supported Interest Shortfall | Total Interest Distribution | Remaining Unpaid Interest Shortfall(1) | Ending Certificate/ Notional Balance |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1-A-26 | 0.00 | 5.75000 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 |
| 1-A-27 | 27,041,000.00 | 5.50000 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 |
| 1-A-28 | 35,000,000.00 | 5.30000 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 |
| 2-A-1 | 105,137,000.00 | 5.50000 % | 19.08897201 | 0.08749108 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.08749108 | 0.00000000 | 19.02342943 |
| 2-A-2 | 4,324,000.00 | 5.50000 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 |
| 3-A-1 | 92,989,000.00 | 5.50000 % | 15.23744722 | 0.06983826 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.06983826 | 0.00000000 | 15.17464356 |
| 3-A-2 | 3,373,000.00 | 5.50000 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 |
| 3-A-R | 100.00 | 5.50000 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 |
| X-PO | 7,023,913.00 | 0.00000 % | 7.62023960 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 7.59034886 |
| X-IO | 0.00 | 5.50000 % | 18.98704785 | 0.08702416 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.08702416 | 0.00000000 | 18.91583503 |
| X-B-1 | 7,535,000.00 | 5.75000 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 70.04776111 | 0.00000000 |
| X-B-2 | 2,021,000.00 | 5.75000 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 54.18133597 | 0.00000000 |
| X-B-3 | 1,287,000.00 | 5.75000 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 21.57386169 | 0.00000000 |
| X-B-4 | 735,000.00 | 5.75000 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 11.76085714 | 0.00000000 |
| X-B-5 | 551,000.00 | 5.75000 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 4.62370236 | 0.00000000 |
| X-B-6 | 735,601.00 | 5.75000 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.46968397 | 0.00000000 |
| B-1 | 2,923,000.00 | 5.50000 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 66.47407800 | 0.00000000 |
| B-2 | 687,000.00 | 5.50000 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 71.63369723 | 0.00000000 |
| B-3 | 344,000.00 | 5.50000 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 30.33607558 | 0.00000000 |
| B-4 | 229,000.00 | 5.50000 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 10.74772926 | 0.00000000 |
| B-5 | 172,000.00 | 5.50000 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.84226744 | 0.00000000 |
| B-6 | 172,580.00 | 5.50000 % | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 | 0.00000000 |

--- Page 9 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
13-Jan-2026 8:17:34 AM
© 2021 Computershare. All rights reserved. Confidential. Page 11 of 55

Banc of America Funding Corporation
Mortgage Pass-Through Certificates
Series 2006-1

| Certificateholder Component Statement |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- |
| Class | Component Pass-Through Rate | Beginning Notional Balance | Ending Notional Balance | Beginning Component Balance | Ending Component Balance | Ending Component Percentage |
| 1-X-IO | 5.50000% | 66,617.22 | 66,334.85 | 0.00 | 0.00 | 1.90393859% |
| 2-X-IO | 5.50000% | 72,752.01 | 72,515.07 | 0.00 | 0.00 | 2.24008581% |
| 3-X-IO | 5.50000% | 43,580.18 | 43,413.32 | 0.00 | 0.00 | 1.48969445% |
| 1-X-PO | 0.00000% | 0.00 | 0.00 | 53,523.90 | 53,313.95 | 0.87873614% |
| 2-X-PO | 0.00000% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000% |
| 3-X-PO | 0.00000% | 0.00 | 0.00 | 0.00 | 0.00 | 0.00000000% |

--- Page 10 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
13-Jan-2026 8:17:34 AM
Certificateholder Account Statement
*Servicer Payees include: JPMORGAN CHASE BANK, N.A.; PHH MORTGAGE CORPORATION; PNC BANK, NA;
SHELLPOINT MORTGAGE SERVICING
Servicer Advances are calculated as delinquent scheduled principal and interest.
© 2021 Computershare. All rights reserved. Confidential. Page 12 of 55

Banc of America Funding Corporation
Mortgage Pass-Through Certificates
Series 2006-1

CERTIFICATE ACCOUNT
Beginning Balance 0.00 Deposits Payments of Interest and Principal 55,548.26 Reserve Funds and Credit Enhancements 0.00 Proceeds from Repurchased Loans 0.00 Servicer Advances (0.50) Gains & Subsequent Recoveries (Realized Losses) 0.00 Prepayment Penalties 0.00 Swap/Cap Payments 0.00 Total Deposits 55,547.76 Withdrawals Swap Payments 0.00 Reserve Funds and Credit Enhancements 0.00 Reimbursement for Servicer Advances 0.00 Total Administration Fees 1,563.17 Payment of Interest and Principal 53,984.59 Total Withdrawals (Pool Distribution Amount) 55,547.76 Ending Balance 0.00

PREPAYMENT/CURTAILMENT INTEREST SHORTFALL
Total Prepayment/Curtailment Interest Shortfall 0.00 Servicing Fee Support 0.00 Non-Supported Prepayment/Curtailment Interest Shortfall 0.00

| ADMINISTRATION FEES |  |  |
| --- | --- | --- |
| Gross Servicing Fee* 1,563.17 Supported Prepayment/Curtailment Interest Shortfall 0.00 |  |  |
| Total Administration Fees | 1,563.17 |  |

| Reserve and Guaranty Funds |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
| Account Name | Beginning Balance | Deposit of Reinvestment Income | Current Deposits | Current Withdrawals | Ending Balance |
| Class 1-A-20 Reserve Fund | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| Hedge Funds |  |  |  |  |  |
| Account Name |  |  | Funds In (A) | Funds Out (B) | Net Amount (A - B) |
| 1-A-20 Yield Maintenance Agrmt - Bank of America |  |  | 0.00 | 0.00 | 0.00 |

--- Page 11 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
13-Jan-2026 8:17:34 AM
Collateral Statement
NOTE: The Collateral Balances shown are Trust Balances unless otherwise designated.
© 2021 Computershare. All rights reserved. Confidential. Page 13 of 55

Banc of America Funding Corporation
Mortgage Pass-Through Certificates
Series 2006-1

| Group | 1 | 2 | 3 | Total |  |
| --- | --- | --- | --- | --- | --- |
| Collateral Description | Fixed 30 Year | Fixed 30 Year | Fixed 30 Year | Mixed Fixed |  |
| Weighted Average Coupon Rate | 4.517785 | 4.236676 | 4.423150 | 4.419985 |  |
| Weighted Average Net Rate | 4.259720 | 3.956323 | 4.173151 | 4.157255 |  |
| Weighted Average Pass-Through Rate | 4.259720 | 3.956323 | 4.173151 | 4.157255 |  |
| Weighted Average Remaining Term | 124 | 184 | 238 | 163 |  |
| Principal and Interest Constant | 32,129.67 | 13,976.65 | 10,756.76 | 56,863.08 |  |
| Beginning Loan Count | 11 | 7 | 7 | 25 |  |
| Loans Paid in Full | 0 | 0 | 0 | 0 |  |
| Ending Loan Count | 11 | 7 | 7 | 25 |  |
| Beginning Scheduled Balance | 3,715,802.40 | 2,006,957.25 | 1,416,914.98 | 7,139,674.63 |  |
| Ending Scheduled Balance | 3,697,611.90 | 2,000,066.30 | 1,411,074.93 | 7,108,753.13 |  |
| Actual Ending Collateral Balance | 3,714,068.92 | 2,004,220.32 | 1,415,263.17 | 7,133,552.41 |  |
| Scheduled Principal | 18,140.34 | 6,890.96 | 5,534.07 | 30,565.37 |  |
| Unscheduled Principal | 50.16 | (0.01) | 305.98 | 356.13 |  |
| Negative Amortized Principal | 0.00 | 0.00 | 0.00 | 0.00 |  |
| Scheduled Interest | 13,989.33 | 7,085.69 | 5,222.69 | 26,297.71 |  |
| Servicing Fees | 799.10 | 468.88 | 295.19 | 1,563.17 |  |
| Master Servicing Fees | 0.00 | 0.00 | 0.00 | 0.00 |  |
| Trustee Fee | 0.00 | 0.00 | 0.00 | 0.00 |  |
| FRY Amount | 0.00 | 0.00 | 0.00 | 0.00 |  |
| Special Hazard Fee | 0.00 | 0.00 | 0.00 | 0.00 |  |
| Other Fee | 0.00 | 0.00 | 0.00 | 0.00 |  |
| Pool Insurance Fee | 0.00 | 0.00 | 0.00 | 0.00 |  |
| Spread 1 | 0.00 | 0.00 | 0.00 | 0.00 |  |
| Spread 2 | 0.00 | 0.00 | 0.00 | 0.00 |  |
| Spread 3 | 0.00 | 0.00 | 0.00 | 0.00 |  |
| Net Interest | 13,190.23 | 6,616.81 | 4,927.50 | 24,734.54 |  |
| Realized Loss Amount | 0.00 | 0.00 | 0.00 | 0.00 |  |
| Cumulative Realized Loss | 7,265,744.47 | 5,276,918.99 | 5,522,658.55 | 18,065,322.01 |  |
| Percentage of Cumulative Losses | 2.7179 | 4.6045 | 5.5110 | 3.7469 |  |
| Prepayment Penalty Waived Amount | 0.00 | 0.00 | 0.00 | 0.00 |  |
| Prepayment Penalty Waived Count | 0 | 0 | 0 | 0 |  |
| Prepayment Penalty Paid Amount | 0.00 | 0.00 | 0.00 | 0.00 |  |
| Prepayment Penalty Paid Count | 0 | 0 | 0 | 0 |  |
| Special Servicing Fee | 0.00 | 0.00 | 0.00 | 0.00 |  |

--- Page 12 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
13-Jan-2026 8:17:34 AM
Additional Reporting - Deal Level
© 2021 Computershare. All rights reserved. Confidential. Page 14 of 55

Banc of America Funding Corporation
Mortgage Pass-Through Certificates
Series 2006-1

Miscellaneous Reporting
1A20 Yield Maintenance Amount 0.00 Aggregate Subordinate % 7.808049% Non PO Recovery 0.00 PO Recovery 0.00 Aggregate Senior Prepayment % 104.857943% Aggregate Senior % 92.191951% Aggregate Subordinate Prepayment % -4.857943%
Trigger Event Reporting
Group 1 & 3 Delinquency Trigger Trigger Result Pass Threshold Value 50.000000% Calculated Value 0.000000% Group 1 & 3 Cumm Loss Trigger Trigger Result Fail Threshold Value 50.000000% Calculated Value 98.962828% Group 1 & 3 Senior Stepdown Trigger Trigger Result Fail Group 2 Delinquency Trigger Trigger Result Pass Threshold Value 50.000000% Calculated Value 0.000000% Group 2 Cumm Loss Trigger Trigger Result Fail Threshold Value 50.000000% Calculated Value 115.808636% Group 2 Senior Stepdown Trigger Trigger Result Fail

--- Page 13 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
13-Jan-2026 8:17:35 AM
Delinquency Status - MBA Delinquency Calculation Method
Please refer to CTSLink.com for a list of delinquency code descriptions.
Current Period Class A Insufficient Funds 0.00 Principal Balance of Contaminated Properties 0.00 Periodic Advance -0.50
© 2021 Computershare. All rights reserved. Confidential. Page 16 of 55

Banc of America Funding Corporation
Mortgage Pass-Through Certificates
Series 2006-1

| DELINQUENT |  |  | BANKRUPTCY |  |  | FORECLOSURE |  |  | REO |  |  | TOTAL |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | No. of Loans | Actual Balance |  | No. of Loans | Actual Balance |  | No. of Loans | Actual Balance |  | No. of Loans | Actual Balance |  | No. of Loans | Actual Balance |
|  |  |  | 0-29 Days | 0 | 0.00 | 0-29 Days | 0 | 0.00 | 0-29 Days | 0 | 0.00 | 0-29 Days | 0 | 0.00 |
| 30 Days | 0 | 0.00 | 30 Days | 0 | 0.00 | 30 Days | 0 | 0.00 | 30 Days | 0 | 0.00 | 30 Days | 0 | 0.00 |
| 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 |
| 90 Days | 0 | 0.00 | 90 Days | 0 | 0.00 | 90 Days | 0 | 0.00 | 90 Days | 0 | 0.00 | 90 Days | 0 | 0.00 |
| 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 |
| 150 Days | 0 | 0.00 | 150 Days | 0 | 0.00 | 150 Days | 0 | 0.00 | 150 Days | 0 | 0.00 | 150 Days | 0 | 0.00 |
| 180+ Days | 0 | 0.00 | 180+ Days | 0 | 0.00 | 180+ Days | 0 | 0.00 | 180+ Days | 0 | 0.00 | 180+ Days | 0 | 0.00 |
| 0 0.00 |  |  | 0 0.00 |  |  | 0 0.00 |  |  | 0 0.00 |  |  | 0 0.00 |  |  |
|  |  |  | 0-29 Days | 0.000000 % | 0.000000 % | 0-29 Days | 0.000000 % | 0.000000 % | 0-29 Days | 0.000000 % | 0.000000 % | 0-29 Days | 0.000000 % | 0.000000 % |
| 30 Days | 0.000000 % | 0.000000 % | 30 Days | 0.000000 % | 0.000000 % | 30 Days | 0.000000 % | 0.000000 % | 30 Days | 0.000000 % | 0.000000 % | 30 Days | 0.000000 % | 0.000000 % |
| 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % |
| 90 Days | 0.000000 % | 0.000000 % | 90 Days | 0.000000 % | 0.000000 % | 90 Days | 0.000000 % | 0.000000 % | 90 Days | 0.000000 % | 0.000000 % | 90 Days | 0.000000 % | 0.000000 % |
| 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % |
| 150 Days | 0.000000 % | 0.000000 % | 150 Days | 0.000000 % | 0.000000 % | 150 Days | 0.000000 % | 0.000000 % | 150 Days | 0.000000 % | 0.000000 % | 150 Days | 0.000000 % | 0.000000 % |
| 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 0.000000 % | 0.000000 % |
| 0.000000 % 0.000000 % |  |  | 0.000000 % 0.000000 % |  |  | 0.000000 % 0.000000 % |  |  | 0.000000 % 0.000000 % |  |  | 0.000000 % 0.000000 % |  |  |

--- Page 14 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
13-Jan-2026 8:17:35 AM
Delinquency Status By Group
© 2021 Computershare. All rights reserved. Confidential. Page 17 of 55

Banc of America Funding Corporation
Mortgage Pass-Through Certificates
Series 2006-1

| DELINQUENT |  |  | BANKRUPTCY |  |  | FORECLOSURE |  |  | REO |  |  | TOTAL |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | No of Loans | Actual Balance |  | No of Loans | Actual Balance |  | No of Loans | Actual Balance |  | No of Loans | Actual Balance |  | No of Loans | Actual Balance |
| 1 - MBA |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  | 0-29 Days | 0 | 0.00 | 0-29 Days | 0 | 0.00 | 0-29 Days | 0 | 0.00 | 0-29 Days | 0 | 0.00 |
| 30 Days 0 0.00 |  |  | 30 Days 0 0.00 |  |  | 30 Days 0 0.00 |  |  | 30 Days 0 0.00 |  |  | 30 Days 0 0.00 |  |  |
| 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 |
| 90 Days 0 0.00 |  |  | 90 Days 0 0.00 |  |  | 90 Days 0 0.00 |  |  | 90 Days 0 0.00 |  |  | 90 Days 0 0.00 |  |  |
| 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 |
| 150 Days 0 0.00 |  |  | 150 Days 0 0.00 |  |  | 150 Days 0 0.00 |  |  | 150 Days 0 0.00 |  |  | 150 Days 0 0.00 |  |  |
| 180+ Days | 0 | 0.00 | 180+ Days | 0 | 0.00 | 180+ Days | 0 | 0.00 | 180+ Days | 0 | 0.00 | 180+ Days | 0 | 0.00 |
| 0 0.00 |  |  | 0 0.00 |  |  | 0 0.00 |  |  | 0 0.00 |  |  | 0 0.00 |  |  |
|  |  |  | 0-29 Days | 0.000000 % | 0.000000 % | 0-29 Days | 0.000000 % | 0.000000 % | 0-29 Days | 0.000000 % | 0.000000 % | 0-29 Days | 0.000000 % | 0.000000 % |
| 30 Days 0.000000 % 0.000000 % |  |  | 30 Days 0.000000 % 0.000000 % |  |  | 30 Days 0.000000 % 0.000000 % |  |  | 30 Days 0.000000 % 0.000000 % |  |  | 30 Days 0.000000 % 0.000000 % |  |  |
| 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % |
| 90 Days 0.000000 % 0.000000 % |  |  | 90 Days 0.000000 % 0.000000 % |  |  | 90 Days 0.000000 % 0.000000 % |  |  | 90 Days 0.000000 % 0.000000 % |  |  | 90 Days 0.000000 % 0.000000 % |  |  |
| 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % |
| 150 Days 0.000000 % 0.000000 % |  |  | 150 Days 0.000000 % 0.000000 % |  |  | 150 Days 0.000000 % 0.000000 % |  |  | 150 Days 0.000000 % 0.000000 % |  |  | 150 Days 0.000000 % 0.000000 % |  |  |
| 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 0.000000 % | 0.000000 % |
| 0.000000 % 0.000000 % |  |  | 0.000000 % 0.000000 % |  |  | 0.000000 % 0.000000 % |  |  | 0.000000 % 0.000000 % |  |  | 0.000000% 0.000000 % |  |  |
| 2 - MBA |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  | 0-29 Days | 0 | 0.00 | 0-29 Days | 0 | 0.00 | 0-29 Days | 0 | 0.00 | 0-29 Days | 0 | 0.00 |
| 30 Days 0 0.00 |  |  | 30 Days 0 0.00 |  |  | 30 Days 0 0.00 |  |  | 30 Days 0 0.00 |  |  | 30 Days 0 0.00 |  |  |
| 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 |
| 90 Days 0 0.00 |  |  | 90 Days 0 0.00 |  |  | 90 Days 0 0.00 |  |  | 90 Days 0 0.00 |  |  | 90 Days 0 0.00 |  |  |
| 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 |
| 150 Days 0 0.00 |  |  | 150 Days 0 0.00 |  |  | 150 Days 0 0.00 |  |  | 150 Days 0 0.00 |  |  | 150 Days 0 0.00 |  |  |
| 180+ Days | 0 | 0.00 | 180+ Days | 0 | 0.00 | 180+ Days | 0 | 0.00 | 180+ Days | 0 | 0.00 | 180+ Days | 0 | 0.00 |
| 0 0.00 |  |  | 0 0.00 |  |  | 0 0.00 |  |  | 0 0.00 |  |  | 0 0.00 |  |  |
|  |  |  | 0-29 Days | 0.000000 % | 0.000000 % | 0-29 Days | 0.000000 % | 0.000000 % | 0-29 Days | 0.000000 % | 0.000000 % | 0-29 Days | 0.000000 % | 0.000000 % |
| 30 Days 0.000000 % 0.000000 % |  |  | 30 Days 0.000000 % 0.000000 % |  |  | 30 Days 0.000000 % 0.000000 % |  |  | 30 Days 0.000000 % 0.000000 % |  |  | 30 Days 0.000000 % 0.000000 % |  |  |
| 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % |
| 90 Days 0.000000 % 0.000000 % |  |  | 90 Days 0.000000 % 0.000000 % |  |  | 90 Days 0.000000 % 0.000000 % |  |  | 90 Days 0.000000 % 0.000000 % |  |  | 90 Days 0.000000 % 0.000000 % |  |  |
| 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % |
| 150 Days 0.000000 % 0.000000 % |  |  | 150 Days 0.000000 % 0.000000 % |  |  | 150 Days 0.000000 % 0.000000 % |  |  | 150 Days 0.000000 % 0.000000 % |  |  | 150 Days 0.000000 % 0.000000 % |  |  |
| 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 0.000000 % | 0.000000 % |
| 0.000000 % 0.000000 % |  |  | 0.000000 % 0.000000 % |  |  | 0.000000 % 0.000000 % |  |  | 0.000000 % 0.000000 % |  |  | 0.000000% 0.000000 % |  |  |

--- Page 15 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
13-Jan-2026 8:17:35 AM
Delinquency Status By Group
Please refer to CTSLink.com for a list of delinquency code descriptions.
© 2021 Computershare. All rights reserved. Confidential. Page 18 of 55

Banc of America Funding Corporation
Mortgage Pass-Through Certificates
Series 2006-1

| DELINQUENT |  |  | BANKRUPTCY |  |  | FORECLOSURE |  |  | REO |  |  | TOTAL |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | No of Loans | Actual Balance |  | No of Loans | Actual Balance |  | No of Loans | Actual Balance |  | No of Loans | Actual Balance |  | No of Loans | Actual Balance |
| 3 - MBA |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  | 0-29 Days | 0 | 0.00 | 0-29 Days | 0 | 0.00 | 0-29 Days | 0 | 0.00 | 0-29 Days | 0 | 0.00 |
| 30 Days 0 0.00 |  |  | 30 Days 0 0.00 |  |  | 30 Days 0 0.00 |  |  | 30 Days 0 0.00 |  |  | 30 Days 0 0.00 |  |  |
| 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 | 60 Days | 0 | 0.00 |
| 90 Days 0 0.00 |  |  | 90 Days 0 0.00 |  |  | 90 Days 0 0.00 |  |  | 90 Days 0 0.00 |  |  | 90 Days 0 0.00 |  |  |
| 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 | 120 Days | 0 | 0.00 |
| 150 Days 0 0.00 |  |  | 150 Days 0 0.00 |  |  | 150 Days 0 0.00 |  |  | 150 Days 0 0.00 |  |  | 150 Days 0 0.00 |  |  |
| 180+ Days | 0 | 0.00 | 180+ Days | 0 | 0.00 | 180+ Days | 0 | 0.00 | 180+ Days | 0 | 0.00 | 180+ Days | 0 | 0.00 |
| 0 0.00 |  |  | 0 0.00 |  |  | 0 0.00 |  |  | 0 0.00 |  |  | 0 0.00 |  |  |
|  |  |  | 0-29 Days | 0.000000 % | 0.000000 % | 0-29 Days | 0.000000 % | 0.000000 % | 0-29 Days | 0.000000 % | 0.000000 % | 0-29 Days | 0.000000 % | 0.000000 % |
| 30 Days 0.000000 % 0.000000 % |  |  | 30 Days 0.000000 % 0.000000 % |  |  | 30 Days 0.000000 % 0.000000 % |  |  | 30 Days 0.000000 % 0.000000 % |  |  | 30 Days 0.000000 % 0.000000 % |  |  |
| 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % | 60 Days | 0.000000 % | 0.000000 % |
| 90 Days 0.000000 % 0.000000 % |  |  | 90 Days 0.000000 % 0.000000 % |  |  | 90 Days 0.000000 % 0.000000 % |  |  | 90 Days 0.000000 % 0.000000 % |  |  | 90 Days 0.000000 % 0.000000 % |  |  |
| 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % | 120 Days | 0.000000 % | 0.000000 % |
| 150 Days 0.000000 % 0.000000 % |  |  | 150 Days 0.000000 % 0.000000 % |  |  | 150 Days 0.000000 % 0.000000 % |  |  | 150 Days 0.000000 % 0.000000 % |  |  | 150 Days 0.000000 % 0.000000 % |  |  |
| 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 0.000000 % | 0.000000 % | 180+ Days | 0.000000 % | 0.000000 % |
| 0.000000 % 0.000000 % |  |  | 0.000000 % 0.000000 % |  |  | 0.000000 % 0.000000 % |  |  | 0.000000 % 0.000000 % |  |  | 0.000000% 0.000000 % |  |  |

--- Page 16 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
13-Jan-2026 8:17:35 AM
© 2021 Computershare. All rights reserved. Confidential. Page 23 of 55

Banc of America Funding Corporation
Mortgage Pass-Through Certificates
Series 2006-1

Realized Loss Report - Collateral
Summary
MDR SDA Current Month 0.000 % Current Month 0.000 % 3 Month Average 0.000 % 3 Month Average 0.000 % 12 Month Average 0.000 % 12 Month Average 0.000 %
CDR | Loss Severity
Current Month | 0.000 % | Current Month (Cumulative) | 23.906 %
3 Month Average | 0.000 % | 3 Month Average (Cumulative) | 23.906 %
12 Month Average | 0.000 % | 12 Month Average (Cumulative) | 23.916 %

--- Page 17 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
13-Jan-2026 8:17:35 AM
© 2021 Computershare. All rights reserved. Confidential. Page 24 of 55

Banc of America Funding Corporation
Mortgage Pass-Through Certificates
Series 2006-1

Realized Loss Report - Collateral
1
MDR SDA Current Month 0.000 % Current Month 0.000 % 3 Month Average 0.000 % 3 Month Average 0.000 % 12 Month Average 0.000 % 12 Month Average 0.000 %
CDR | Loss Severity
Current Month | 0.000 % | Current Month (Cumulative) | 22.042 %
3 Month Average | 0.000 % | 3 Month Average (Cumulative) | 22.042 %
12 Month Average | 0.000 % | 12 Month Average (Cumulative) | 22.042 %

--- Page 18 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
13-Jan-2026 8:17:36 AM
© 2021 Computershare. All rights reserved. Confidential. Page 25 of 55

Banc of America Funding Corporation
Mortgage Pass-Through Certificates
Series 2006-1

Realized Loss Report - Collateral
2
MDR SDA Current Month 0.000 % Current Month 0.000 % 3 Month Average 0.000 % 3 Month Average 0.000 % 12 Month Average 0.000 % 12 Month Average 0.000 %
CDR | Loss Severity
Current Month | 0.000 % | Current Month (Cumulative) | 23.957 %
3 Month Average | 0.000 % | 3 Month Average (Cumulative) | 23.957 %
12 Month Average | 0.000 % | 12 Month Average (Cumulative) | 23.957 %

--- Page 19 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
13-Jan-2026 8:17:36 AM
Calculation Methodology:
Monthly Default Rate (MDR): Sum(Beg Scheduled Balance of Liquidated Loans) / Sum(Beg Scheduled Balance).
Conditional Default Rate (CDR): 1-((1-MDR)^12)
SDA Standard Default Assumption: If WAS ≤ 30 then CDR / (WAS * 0.02) else if 30 < WAS ≤ 60 then CDR / 0.6 else if 60 < WAS ≤ 120 then CDR/(0.6 - ((WAS - 60) * 0.0095)) else if WAS > 120 then CDR/0.03
Cumulative Loss Severity: Sum(All Active & Inactive Realized Losses) / Sum(Active Loans or loans without a loss passed on or after liquidation: the Actual Ending Principal Balance as of the most recent cycle in
which a Realized Loss was passed; loans with a loss passed on or after the month of liquidation: the Actual Beginning Principal Balance from the cycle in which the loan was liquidated).
3 Month Average and 12 Month Average will not have values until the 3rd and 12th month respectively.
© 2021 Computershare. All rights reserved. Confidential. Page 26 of 55

Banc of America Funding Corporation
Mortgage Pass-Through Certificates
Series 2006-1

Realized Loss Report - Collateral
3
MDR SDA Current Month 0.000 % Current Month 0.000 % 3 Month Average 0.000 % 3 Month Average 0.000 % 12 Month Average 0.000 % 12 Month Average 0.000 %
CDR | Loss Severity
Current Month | 0.000 % | Current Month (Cumulative) | 26.839 %
3 Month Average | 0.000 % | 3 Month Average (Cumulative) | 26.839 %
12 Month Average | 0.000 % | 12 Month Average (Cumulative) | 26.878 %

--- Page 20 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
13-Jan-2026 8:17:36 AM
Prepayment Detail - Prepayments during Current Period
Prepayment Loan Detail - Prepayments during Current Period
© 2021 Computershare. All rights reserved. Confidential. Page 27 of 55

Banc of America Funding Corporation
Mortgage Pass-Through Certificates
Series 2006-1

| Summary |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | Loans Paid in Full |  |  | Repurchased Loans |  |  | Substitution Loans |  |  | Liquidated Loans |  |  | Curtailments |
|  | Count | Original Securitized Balance | Current Scheduled Balance | Count | Original Securitized Balance | Current Scheduled Balance | Count | Original Securitized Balance | Current Scheduled Balance | Count | Original Securitized Balance | Current Scheduled Balance | Curtailment Amount |
| 1 | 0 | 0.00 | 0.00 | 0 | 0.00 | 0.00 | 0 | 0.00 | 0.00 | 0 | 0.00 | 0.00 | 50.16 |
| 2 | 0 | 0.00 | 0.00 | 0 | 0.00 | 0.00 | 0 | 0.00 | 0.00 | 0 | 0.00 | 0.00 | (0.01) |
| 3 | 0 | 0.00 | 0.00 | 0 | 0.00 | 0.00 | 0 | 0.00 | 0.00 | 0 | 0.00 | 0.00 | 305.98 |
| Total | 0 | 0.00 | 0.00 | 0 | 0.00 | 0.00 | 0 | 0.00 | 0.00 | 0 | 0.00 | 0.00 | 356.13 |

| Group | Loan Number | State | LTV at Origination | First Payment Date | Original Securitized Balance | Prepayment Amount | Resolution Type | Months Delinquent | Current Loan Rate | Original Term | Seasoning |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| No Prepayments in Full this Period |  |  |  |  |  |  |  |  |  |  |  |

--- Page 21 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
13-Jan-2026 8:17:36 AM
Prepayment Penalty Loan Detail - Prepayment Penalty Paid during Current Period
© 2021 Computershare. All rights reserved. Confidential. Page 28 of 55

Banc of America Funding Corporation
Mortgage Pass-Through Certificates
Series 2006-1

Prepayment Penalty Detail - Prepayment Penalty Paid during Current Period

| Summary | Loan Count | Prior Balance | Prepayment Penalty Amount | Prepayment Penalty Waived |
| --- | --- | --- | --- | --- |
| Total | 0 | 0.00 | 0.00 | 0.00 |

| Group | Loan Number | Paid In Full Date | Prior Balance | Prepayment Penalty Amount | Prepayment Penalty Waived |
| --- | --- | --- | --- | --- | --- |
| No Prepayment Penalties this period |  |  |  |  |  |

--- Page 22 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
13-Jan-2026 8:17:36 AM
Prepayment Rates
© 2021 Computershare. All rights reserved. Confidential. Page 29 of 55

Banc of America Funding Corporation
Mortgage Pass-Through Certificates
Series 2006-1

Summary
SMM CPR PSA Current Month 0.005 % Current Month 0.060 % Current Month 1.002 % 3 Month Average 0.203 % 3 Month Average 2.359 % 3 Month Average 39.317 % 12 Month Average 0.198 % 12 Month Average 2.224 % 12 Month Average 37.060 %
1
SMM CPR PSA Current Month 0.001 % Current Month 0.016 % Current Month 0.271 % 3 Month Average 0.366 % 3 Month Average 4.134 % 3 Month Average 68.901 % 12 Month Average 0.101 % 12 Month Average 1.149 % 12 Month Average 19.148 %

--- Page 23 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
13-Jan-2026 8:17:37 AM
Prepayment Rates
© 2021 Computershare. All rights reserved. Confidential. Page 30 of 55

Banc of America Funding Corporation
Mortgage Pass-Through Certificates
Series 2006-1

2
SMM CPR PSA Current Month 0.000 % Current Month 0.000 % Current Month 0.000 % 3 Month Average 0.033 % 3 Month Average 0.397 % 3 Month Average 6.622 % 12 Month Average 0.041 % 12 Month Average 0.487 % 12 Month Average 8.119 %
3
SMM CPR PSA Current Month 0.022 % Current Month 0.260 % Current Month 4.331 % 3 Month Average 0.011 % 3 Month Average 0.130 % 3 Month Average 2.159 % 12 Month Average 0.640 % 12 Month Average 5.197 % 12 Month Average 86.620 %

--- Page 24 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
13-Jan-2026 8:17:37 AM
© 2021 Computershare. All rights reserved. Confidential. Page 33 of 55

Banc of America Funding Corporation
Mortgage Pass-Through Certificates
Series 2006-1

Modification Detail

| Modification Detail Summary |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | Current |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Cumulative |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Groups | Loan Count |  |  | Original Securitized Balance |  |  | Current Scheduled Balance |  |  | Capitalized Amount |  |  | Capitalized Reimbursement Amount |  |  |  |  | Total Forgiveness |  |  | Loan Count |  | Original Securitized Balance |  |  | Current Scheduled Balance |  |  | Capitalized Amount |  | Capitalized Reimbursement Amount |  |  | Total Forgiveness |  |
| 1 | 0 |  |  | 0.00 |  |  | 0.00 |  |  | 0.00 |  |  | 0.00 |  |  |  |  | 0.00 |  |  | 22 |  | 11,122,403.00 |  |  | 2,287,124.03 |  |  | 1,462,223.79 |  | (685,956.00) |  |  | 0.00 |  |
| 2 | 0 |  |  | 0.00 |  |  | 0.00 |  |  | 0.00 |  |  | 0.00 |  |  |  |  | 0.00 |  |  | 19 |  | 9,021,350.00 |  |  | 1,419,602.23 |  |  | 272,882.89 |  | (45,954.00) |  |  | 6.53 |  |
| 3 | 0 |  |  | 0.00 |  |  | 0.00 |  |  | 0.00 |  |  | 0.00 |  |  |  |  | 0.00 |  |  | 12 |  | 3,844,975.00 |  |  | 865,663.54 |  |  | 126,585.69 |  | 45,073.07 |  |  | 0.00 |  |
| Total | 0 |  |  | 0.00 |  |  | 0.00 |  |  | 0.00 |  |  | 0.00 |  |  |  |  | 0.00 |  |  | 53 |  | 23,988,728.00 |  |  | 4,572,389.80 |  |  | 1,861,692.37 |  | (686,836.93) |  |  | 6.53 |  |
| Current Month Modification Detail |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Loan Number/ Original Balance |  |  | Mod Appr Date/Mod Effective Date |  |  | Total Capitalized Amount |  |  | Total Capitalized Reimb. Amount |  |  | Total Forgiveness |  |  | No of Times Loan Modified |  |  |  | No of Months Delinq. |  | Loan Status |  |  | Next Due Date |  |  | Interest Rate | Payment Amount |  | Maturity Date |  | Balloon Amount | Balloon Date |  | Scheduled Balance |
| No Modifications this Period |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Historical Modification Detail |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Loan Number/ Original Balance |  | Mod Appr Date/Mod Effective Date |  |  | Total Capitalized Amount |  |  | Total Capitalized Reimb. Amount |  |  | Total Forgiveness |  |  | No of Times Loan Modified |  |  |  |  |  | No of Months Delinq. |  | Loan Status |  |  | Next Due Date |  | Interest Rate | Payment Amount |  | Maturity Date |  | Balloon Amount | Balloon Date |  | Scheduled Balance |
| 1 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 0004226539 |  | 05/10/2010 |  |  |  |  |  |  |  |  |  |  |  |  |  | Pre Mod |  |  |  | 18 |  | No Action |  |  | 10/01/2008 |  | 6.250 | 1,268.38 |  | 08/01/2035 |  | * | * |  | 190,500.12 |
| 206,000.00 |  | 03/30/2010 |  |  | * |  |  | (26,723.79) |  |  | * |  |  |  |  | Post Mod |  |  |  | 0 |  | No Action |  |  | 05/01/2010 |  | 2.750 | 992.63 |  | 08/01/2035 |  | * | * |  | 216,667.84 |
| 0004226539 |  | 06/15/2018 |  |  |  |  |  |  |  |  |  |  |  |  |  | Pre Mod |  |  |  | 27 |  | Bankruptcy |  |  | 02/01/2016 |  | 5.000 | 1,229.18 |  | 08/01/2035 |  | * | * |  | 170,188.59 |
| 206,000.00 |  | 03/01/2018 |  |  | 27,908.54 |  |  | (39,673.18) |  |  | * |  |  |  |  | Post Mod |  |  |  | 0 |  | No Action |  |  | 06/01/2018 |  | 2.000 | 1,199.21 |  | 08/01/2035 |  | * | * |  | 208,946.21 |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2 |  | Current Values |  |  |  |  |  | INACTIVE |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 0004366914 |  | 04/16/2010 |  |  |  |  |  |  |  |  |  |  |  |  |  | Pre Mod |  |  |  | 6 |  | No Action |  |  | 09/01/2009 |  | 6.500 | 2,164.66 |  | 11/01/2035 |  | * | * |  | 399,629.28 |
| 400,000.00 |  | 03/17/2010 |  |  | * |  |  | (15,804.82) |  |  | * |  |  |  |  | Post Mod |  |  |  | 1 |  | No Action |  |  | 03/01/2010 |  | 4.000 | 2,159.43 |  | 11/01/2035 |  | * | * |  | 414,606.77 |

--- Page 25 ---

Contact:
Customer Service - CTSLink
Computershare Trust Company, N.A.
9062 Old Annapolis Road
Columbia, MD 21045
www.ctslink.com
Telephone: 1-866-846-4526
Distribution Date: 26-Jan-2026
13-Jan-2026 8:17:38 AM
Collateral Balance Detail
Balance Methodology:
IB: Interest Bearing
NIB: Non-Interest Bearing
NIB Non-Loss Balance: current balance of NIB amounts that were not treated as a loss at the time of the related modification
Trust Balance = IB Balance + NIB Non-Loss Balance
NIB Loss Balance: current balance of NIB amounts that were treated as a loss at the time of the related modification
TDO: Total Debt Owed = IB Balance + NIB Non-Loss Balance + NIB Loss Balance
NOTE: In addition to modifications included in this reporting package, Servicer(s) may utilize other loss mitigation options with borrowers. Please see the External Collateral File loan level data reported separately
on CTSLink® for additional reporting.
NOTE: ** See Information Regarding Collateral Balance Detail Reporting and Non-Interest Bearing Detail set forth in the Supplemental Reporting below.
© 2021 Computershare. All rights reserved. Confidential. Page 47 of 55

Banc of America Funding Corporation
Mortgage Pass-Through Certificates
Series 2006-1

| Group | 1 | 2 | 3 | Total |
| --- | --- | --- | --- | --- |
| Beginning Scheduled Balance: IB | 3,683,508.47 | 1,969,804.74 | 1,416,914.98 | 7,070,228.19 |
| Beginning NIB Non-Loss Balance | 32,293.93 | 37,152.51 | 0.00 | 69,446.44 |
| Beginning Scheduled Balance: Trust | 3,715,802.40 | 2,006,957.25 | 1,416,914.98 | 7,139,674.63 |
| Beginning NIB Loss Balance | 286,800.00 | 263,400.00 | 22,500.00 | 572,700.00 |
| Beginning Scheduled Balance: TDO | 4,002,602.40 | 2,270,357.25 | 1,439,414.98 | 7,712,374.63 |

| Ending Scheduled Balance: IB | 3,665,317.97 | 1,962,913.79 | 1,411,074.93 | 7,039,306.69 |
| --- | --- | --- | --- | --- |
| Ending NIB Non-Loss Balance | 32,293.93 | 37,152.51 | 0.00 | 69,446.44 |
| Ending Scheduled Balance: Trust | 3,697,611.90 | 2,000,066.30 | 1,411,074.93 | 7,108,753.13 |
| Ending NIB Loss Balance | 286,800.00 | 263,400.00 | 22,500.00 | 572,700.00 |
| Ending Scheduled Balance: TDO | 3,984,411.90 | 2,263,466.30 | 1,433,574.93 | 7,681,453.13 |

| Ending Actual Balance: IB | 3,681,774.99 | 1,967,067.81 | 1,415,263.17 | 7,064,105.97 |
| --- | --- | --- | --- | --- |
| Ending NIB Non-Loss Balance | 32,293.93 | 37,152.51 | 0.00 | 69,446.44 |
| Ending Actual Balance: Trust | 3,714,068.92 | 2,004,220.32 | 1,415,263.17 | 7,133,552.41 |
| Ending NIB Loss Balance | 286,800.00 | 263,400.00 | 22,500.00 | 572,700.00 |
| Ending Actual Balance: TDO | 4,000,868.92 | 2,267,620.32 | 1,437,763.17 | 7,706,252.41 |