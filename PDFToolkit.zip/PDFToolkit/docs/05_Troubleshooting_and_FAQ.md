# 5. Troubleshooting and FAQ

## 5.1 First, the two places to look

1. **The message on screen.** The program explains most problems in plain words (see 5.5).
2. **The error log.** If an *unexpected error* window appears, or the program does not start at all, a file named
   **`PDFToolkit_error.log`** is written to your home folder (`C:\Users\<you>\` on Windows, `~` on macOS/Linux). Send
   this file when you ask for help - it contains the technical details and never your PDF contents.

## 5.2 The program does not start

| Symptom | Cause and fix |
|---------|---------------|
| Black window says **"Python was not found"** | Install Python 3.12 from python.org and tick **Add python.exe to PATH**. Run the launcher again. |
| **"This program needs Python 3.9 or newer"** | Install a newer Python (3.12 recommended), then start again. |
| **"main.py was not found next to this file"** | You started the launcher from inside the zip. Right-click the zip > **Extract All**, then use the extracted folder. |
| Setup stops with **"Setup failed"** | No internet, a proxy, or antivirus interfering. Check the connection and run again. If it keeps failing: delete the `.venv` folder, install Python 3.12, run again. Behind a proxy see 1.8. For PCs without internet see 1.7. |
| Windows: **"Windows protected your PC"** | Click **More info** > **Run anyway** (the `.bat` file is unsigned plain text). |
| Window opens and closes immediately; nothing shows | Look for `PDFToolkit_error.log` in your home folder. A missing/damaged package is fixed by deleting the `.venv` folder and starting again. |
| After copying the folder to another PC / drive it will not start | Delete the `.venv` folder inside it; it is re-created on the next start. |
| Linux: *"Could not load the Qt platform plugin xcb"* | `sudo apt install libxcb-cursor0 libegl1 libgl1 libxkbcommon-x11-0` |
| macOS: the `.sh` file "cannot be opened" | `chmod +x run_pdf_toolkit.sh` in Terminal, then `./run_pdf_toolkit.sh` |

## 5.3 Opening files

| Problem | What to do |
|---------|-----------|
| "...is password protected (missing or wrong password)" | Enter the correct password in the dialog. The program cannot remove passwords it does not know. |
| "Cannot open '...': ..." / the PDF is damaged | The program tries to repair damaged files automatically. If that fails, the file is too broken to read; open the original in a browser and *Print > Save as PDF* to create a clean copy. |
| "... is not a PDF file" | The file is a picture or another format. Use **Images → PDF** for pictures. |
| Thumbnails appear slowly | They are drawn in the background; the program is usable immediately. Large scans take a while. |
| I deleted/renamed the PDF while the program was open | That is fine - the program works from a copy in memory (for files up to 150 MB). Tools that read the file again will report *File not found*. |

## 5.4 Results that look unexpected

| Observation | Explanation |
|-------------|-------------|
| **Cropped file is not smaller** | Cropping only hides the margins. Use **Rasterize** afterwards to remove them for good. |
| **Compress says "could not be made smaller"** | The file is already optimised or is mostly text. The original was copied unchanged. Try *High* or *Extreme*, or custom DPI/quality. |
| **Text can no longer be selected** | You used **Rasterize** (pages became pictures), or the watermark text is non-Latin (drawn as a picture). The document's own text is untouched by watermarking. |
| **Highlights and form fields are not editable after Resize / Scale / Cut / Pages per sheet** | These tools redraw pages; annotations and filled-in fields are burned into the page (still visible). To keep them editable, do those steps on a copy before annotating. |
| **Bookmarks are missing after Cut or Pages per sheet** | Page numbers change in these tools, so bookmarks cannot stay valid. Resize, Scale, Crop, Rotate, Compress, Extract and the stamping tools keep them. |
| **Page-label styles (i, ii, A-1 ...) or accessibility tags are missing** | Embedded file attachments are kept by every tool. Page-label styles are kept only when the page count stays the same (Resize, Scale, Rasterize, Crop, Rotate, Compress, stamping tools). Tools that add, remove or merge pages cannot keep them. Accessibility tags are not kept by tools that redraw pages. |
| **A digitally signed PDF shows an invalid signature** | Any change makes a signature invalid - that is what signatures are for. Do all edits first, sign last (Digital signature tool). Existing signatures cannot be preserved through edits. |
| **Signed file shows "certificate not trusted"** | A self-made certificate is not known to other programs. The file is still protected against changes; use a certificate from a licensed authority if the receiver requires trust. |
| **OCR text has mistakes** | Use sharper scans (300-400 DPI), straighten pages, choose the right language (`eng+hin`). OCR is never perfect. |
| **Replaced text looks a little different** | The new text uses a standard font close to the original, not the original embedded font. Choose a `.ttf` in the Font field for a closer match. |
| **Watermark Hindi/Bengali/Arabic text: "No font installed ... can show ... text"** | Install a font for that script (for example *Noto Sans*) or select a `.ttf`/`.otf` in the **Font** field. |
| **Page numbers look too small/large** | Change **Font size** (pt). A4 pages are 595 × 842 pt. |
| **The watermark is in the wrong place on a rotated page** | Rotated pages are normalised first, so it should read upright. If it does not, tell us the page's rotation. |
| **Image colours changed after Compress** | Compress re-encodes images as JPEG at the chosen quality. Use *Light* (lossless) to keep images untouched. |

## 5.5 Messages you may see

| Message | Meaning / fix |
|---------|---------------|
| Open a PDF first | The selected tool needs an open file (only *Merge* and *Images → PDF* do not). |
| Page 40 is out of range (the document has 24 pages) | A number in a **Pages** box is bigger than the page count. |
| '...' is not a valid page number / not a valid page range | Check the notation in 2.5; use `-` for ranges and `,` between items. |
| No pages selected | The Pages box produced an empty list. |
| You selected every page for deletion - nothing would be left | Delete fewer pages, or use Extract. |
| The output file must be different from the source file | Choose another name; your original is never overwritten. |
| The margins leave nothing visible | Crop margins add up to nearly the whole page. Reduce them. |
| Choose at least 2 pieces (columns × rows) | **Cut** needs 2 or more pieces. |
| The margin is larger than the page / The page size is too small | Check **Resize** values and units. |
| Too many pages per sheet for this paper size and margins | Use fewer columns/rows, a larger sheet, or smaller margins/gap. |
| Add at least two PDFs to merge | The merge list needs 2 or more files. |
| This PDF has no top-level bookmarks to split by | Use another split mode. |
| This PDF is not password protected | Nothing to remove. |
| Cannot read image '...' | The picture file is damaged or an unsupported format. |
| Cannot write the result - the file may be open in another program or the folder is read-only | Close the other program (a PDF viewer may have the old result open) or choose another folder. |
| Cannot save the result: ... | Disk full, name contains forbidden characters, or the path is too long. |
| Not enough memory for this operation | Use a lower DPI, or process fewer pages (choose a Pages range). |
| No OCR language data found / OCR language data missing: ... | Copy the `.traineddata` file of that language into the `tessdata` folder (see 1.1). |
| The text '...' was not found | The words are not in the PDF text (scans: run OCR first), or case/spacing differs. |
| Nothing matched, so nothing was redacted | Same as above. |
| Digital signatures need the 'pyhanko' package | Run the launcher again (it installs missing packages), or `pip install pyhanko`. |
| The certificate could not be opened | Wrong certificate password, or the file is not a .p12/.pfx. |
| Remove the password first ... | Signing needs an unprotected PDF: use **Remove password**, then sign. |
| No blank pages were found | Raise the sensitivity (4.27). |
| Something unexpected went wrong | A bug. Click *Show details*, and send `PDFToolkit_error.log` along with what you did. Your files were not changed. |

## 5.6 Speed and large files

* Text-based tools are fast (a 600-page document is processed in seconds). Image-heavy tools (**Rasterize**, **PDF → Images**,
  **Compress** on scans) are limited by image work: expect a few seconds per 10 scanned pages at 150 DPI.
* Lower the **DPI** to speed up and shrink image output.
* For huge files, process in chunks: **Split** first, work on the parts, then **Merge**.
* Files up to 150 MB are held in memory for the preview; larger files are read from disk.
* While a job runs, the window is intentionally locked except **Cancel**.

## 5.7 Frequently asked questions

**Is my file uploaded anywhere?** No. The program has no network code. Only the installer needs the internet, once.

**Does it change my original?** Never. Every result is a new file. The program refuses to use the original's name.

**Can I recover a lost password?** No, and the program does not try to break passwords. It only removes a password
you provide.

**Does it do OCR (make scans searchable)?** Yes - **OCR** (needs the language files, English and Hindi are included, more are a free download; see 1.1).

**Can I edit existing text?** Yes, by **Find & replace text** (words and numbers in text-based PDFs) and **Redact**. It is not a full word-processor: it does not re-flow paragraphs or edit pictures (see 7.2).

**Can it sign PDFs?** Yes - **Create signing certificate**, **Digital signature** and **Check signatures**.

**Can I undo?** There is nothing to undo: the original is untouched. Just close the result and use the original.

**Why two "flatten" tools?** *Rasterize (pages → pictures)* turns pages into images (removes hidden content and text);
*Flatten forms & comments* only makes annotations and form fields permanent (text stays text).

**What is the difference between Resize, Scale and Crop?** *Crop* trims the visible area (nothing is scaled). *Scale*
changes everything by a percentage. *Resize* chooses a paper size and fits the content into it.

**Which tool turns a wide scan into two pages?** *Cut pages into pieces* (Columns 2, Rows 1).

**Can I batch-process many files at once?** The window handles one document at a time; *Merge*, *Images → PDF*, *Split*
and the extract tools cover multi-file work. For scripts, the engine can be called from Python (see the Developer Guide).

**Can the program run from a USB stick?** Yes: build the standalone program (1.6) and copy the `dist/PDFToolkit` folder.

**Which languages are supported?** The interface is English. PDF content in any language works in every tool;
watermark / page-number text in Indic scripts, Arabic, Hebrew, Thai, Chinese, Japanese and Korean uses installed fonts
(see 3.16).

## 5.8 Reporting a bug

Please include:

1. The tool you used and the options you set (a screenshot is ideal).
2. The exact message you saw.
3. `PDFToolkit_error.log` from your home folder, if present.
4. If possible, a small PDF that shows the problem (or its page count, size, and whether it is scanned/encrypted).
5. Your system: Windows/macOS/Linux version and the Python version (`python --version`).
