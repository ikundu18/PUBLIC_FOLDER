# PDF Toolkit documentation

1. [Installation and Setup](01_Installation_and_Setup.md) - requirements, install, run, offline, build EXE
2. [Getting Started](02_Getting_Started.md) - the window, opening files, page notation
3. [Workflows and Recipes](03_Workflows_and_Recipes.md) - step-by-step jobs
4. [Tool Reference](04_Tool_Reference.md) - every tool and option
5. [Troubleshooting and FAQ](05_Troubleshooting_and_FAQ.md)
6. [Developer Guide](06_Developer_Guide.md)
7. [Features and Limitations](07_Features_and_Limitations.md) - everything it can do, and what it cannot

A single-file version: `PDF_Toolkit_User_Guide.html` and `PDF_Toolkit_User_Guide.pdf` (same content, printable).
