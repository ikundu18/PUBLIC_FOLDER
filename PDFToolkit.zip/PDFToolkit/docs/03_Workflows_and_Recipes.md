# 3. Workflows and Recipes

Practical, start-to-finish examples. Each recipe lists the tools in order. Between steps use
**Continue editing this file** in the result message so the output of one step becomes the input of the next.

---

## 3.1 Split a scanned book (two book pages per scan) into single pages

*Problem:* every scanned PDF page shows two book pages side by side.

1. **Page size & cutting > Cut pages into pieces** - Columns `2`, Rows `1`. Look at the preview: a red dashed
   line must run exactly between the two book pages. Pages `all`. For right-to-left books (manga, Arabic) tick
   **Right-to-left order**. Run.
2. *(if the scan has black edges)* **Crop margins** - drag the orange frame in the preview to trim the edges
   (the same trim is applied to every page), or tick **Auto-crop white borders**. Run.
3. **Resize page size** - choose `A5`, Content `Fit`. Run. Every page now has the same size.
4. **Page numbers / header / footer** - Preset `Page 1`, Position `bottom-center`. Run.

*Tip:* if the first page is a single cover, run the cut with Pages `2-last` - pages you do not select are copied
unchanged.

---

## 3.2 Make a PDF small enough to email

1. **Compress / reduce size** - start with **Medium**. The result message tells you the before/after size.
2. Still too big? Run again on the *original* with **High**, then **Extreme**. Or tick *Custom image settings*
   and lower *Image DPI* (for example 100) and *JPEG quality* (for example 50).
3. If the result says the file "could not be made smaller", the PDF is mostly text or already optimised - the
   original is kept untouched.

For scanned documents (pages are big pictures), compression usually saves the most. For documents that are mostly
text, expect only a small reduction.

---

## 3.3 Combine several PDFs into one document with page numbers

1. **Merge PDFs** - click **Add...**, select the files, put them in order (drag, or **Up** / **Down**, or
   **Sort A-Z**). Keep **Add a bookmark for each file** ticked. Run.
2. **Continue editing**, then **Page numbers** - Preset `Page 1 of 10`, Position `bottom-center`.
   Tick **Skip first page** if the first file is a cover. Run.

Password-protected source files: the program asks for each password before the merge starts.

---

## 3.4 Take out pages / keep only some pages

| Goal | Tool | Pages box |
|------|------|-----------|
| Remove the cover page | **Delete pages** | `1` |
| Remove pages 5 to 8 and the last page | **Delete pages** | `5-8,last` |
| Keep only chapter 3 (pages 40-62) | **Extract pages** | `40-62` |
| Keep only odd pages | **Extract pages** | `odd` |
| Pick pages in the thumbnails | select them with `Ctrl`+click, press **Picked** | (filled in automatically) |

---

## 3.5 Rearrange pages

* **Reverse a document** (for example a scan made back to front): **Reorder / reverse** > button **Reverse all pages**
  (this writes `last-1`) > Run.
* **Move page 10 to the front:** New order `10, 1-9, 11-last`.
* **Booklet order experiments:** New order `1,3,2,4` etc. Pages you leave out are dropped; pages you repeat are copied.
* **Make a duplicate of page 1** (for example for a double-sided cover): **Duplicate pages**, Pages `1`, Extra copies `1`.
* **Add a blank page after every page** (for notes): **Insert blank pages**, After page(s) `all`.
* **Add a blank first page:** After page(s) `0`.

---

## 3.6 Fix wrongly rotated pages

1. Click the thumbnail of a sideways page. Hold `Ctrl` and click the other sideways pages.
2. **Rotate pages**, press **Picked**, Rotation `90° clockwise` (or `counter-clockwise`). Run.

To turn every page: leave Pages as `all`.

---

## 3.7 Print several pages per sheet (handouts, saving paper)

1. **Multiple pages per sheet** - Layout `4 per sheet (2×2)`, Sheet size `A4`, tick **Draw a border around each page**
   if you like frames. Run.
2. Print the result at 100% / "Actual size".

Layouts: 2 per sheet (side by side), 4, 6, 9, 2 stacked, or *Custom* columns × rows. Pages are placed left to
right, top to bottom. Landscape sheets are used automatically when there are more columns than rows.

---

## 3.8 Convert to a different paper size (Letter to A4)

1. **Resize page size** - New size `A4`.
2. Content: **Fit** keeps everything visible (white bars appear if the shapes differ); **Fill** covers the
   whole page and crops the overflow; **Stretch** distorts to fit exactly.
3. Leave **Keep landscape pages landscape** ticked so wide pages become A4 landscape instead of being squeezed.

Use **Scale pages (%)** when you want a straight enlargement or reduction, for example 70%.

---

## 3.9 Prepare a document for an e-reader: crop wide margins

1. **Crop margins** - open the PDF, choose Units `mm`.
2. Drag the orange frame edges in the preview until only the text block is inside, or type the values.
3. Check a few other pages (use the page box above the preview): the *same* margins apply to all pages.
4. Pages `all`. Run. For pages with very different margins, use **Auto-crop white borders** instead
   (each page is trimmed to its own content, keeping the *Keep padding* in points).

> Cropping hides the removed margins; it does not erase them. If you need them gone for good, continue with
> **Rasterize (pages → pictures)**.

---

## 3.10 Share a document safely (remove hidden information)

1. **Properties (metadata)** - tick **Erase all metadata**. Run. (Removes author, title, software, dates, and XMP data.)
2. **Flatten forms & comments** - makes highlights, notes and typed form values permanent and uneditable.
3. *Maximum safety:* **Rasterize (pages → pictures)** at 150-200 DPI. This turns each page into a picture:
   hidden text, cropped-away content, and removed-but-still-stored data are gone. The text becomes unselectable.
4. **Password protect** if needed (see 3.11).

---

## 3.11 Protect a PDF with a password and a watermark

1. **Text watermark** - Text `CONFIDENTIAL`, Opacity `25 %`, Angle `45`. Run.
2. **Page numbers** *(optional)*.
3. **Password protect** - enter and repeat the password. Untick **Allow copying text** / **Allow printing** as
   needed. Run.

Always add the password protection **last** - afterwards the file can only be opened with the password.
The password **cannot be recovered**; keep a note of it.

---

## 3.12 Turn photos or scans into a PDF

1. **Convert > Images → PDF** - **Add...** the pictures (JPG, PNG, WebP, TIFF, BMP, GIF), order them.
2. Page size: `Same as image` keeps each picture's shape, or choose `A4` to get uniform pages (the picture is fitted;
   portrait photos get portrait pages, landscape photos get landscape pages).
3. Margin `5` mm if you want a white border. Run.

Phone photos are rotated automatically according to how the phone was held. Transparent PNGs get a white background.
JPG files are stored without any quality loss.

---

## 3.13 Turn a PDF into pictures, or get its text and images

| Goal | Tool | Notes |
|------|------|-------|
| Every page as a PNG/JPG | **PDF → Images** | DPI 150 for screens, 300 for printing |
| A page range as images | **PDF → Images** | Pages `3-7` |
| All text | **PDF → Text** | one `.txt` file; scanned pages are empty - run **OCR** first (3.18) |
| The photos inside the PDF | **Extract embedded images** | original quality; small icons skipped (below 32 px by default) |

---

## 3.14 Split a long PDF into chapters or parts

* **By chapter** (needs bookmarks): **Split PDF** > `Top-level bookmarks / chapters`. Each file is named with the
  bookmark title.
* **By page ranges:** `Custom page ranges` and type `1-12, 13-30, 31-last`. One file per item.
* **Every N pages:** for example every 10 pages.
* **Equal parts:** for example 4 parts - leftover pages are spread over the first parts.
* **One file per page:** `Every page`.

Choose an empty folder; files are named like `book_pages_1-12.pdf`.

---

## 3.15 Add a logo or signature stamp

1. **Image / logo watermark** - choose the PNG (transparent background works best).
2. Width `20 %` of the page, Opacity `100 %`, Position `bottom-right`, Margin `20` pt.
3. Pages: `last` for a signature page, or `all` for a logo on every page.

---

## 3.16 Non-English text in watermarks and page numbers (Hindi, Bengali, Tamil, Arabic, Chinese ...)

Just type the text. In **Text watermark** and **Page numbers / header / footer** the program:

* draws **English / Latin text as real PDF text** (small file, selectable and searchable), and
* draws **Hindi, Bengali, Tamil, Telugu, Kannada, Malayalam, Gujarati, Gurmukhi, Odia, Sinhala, Thai, Arabic, Hebrew,
  Chinese, Japanese, Korean, Greek, Cyrillic ...** with correct letter shaping (conjuncts, vowel signs, joined Arabic
  letters, right-to-left order), using a font that is already installed on your computer. This text is placed as a
  sharp picture (288 dpi), so it is **not selectable**.

You can mix scripts and placeholders, for example `पृष्ठ {n} / {total}` or `{file} - হিন্দি`.

**Font (optional)** - leave it empty normally. Use it only if you want a particular look: click **Browse...** and
choose a `.ttf` / `.otf` file.

If the program says *"No font installed on this computer can show ... text"*, install a font for that script
(for example the free **Noto Sans** family from fonts.google.com; Windows 10/11 and macOS already include fonts for
the major Indian scripts) or choose a font file in the **Font** field.

---

## 3.17 Typical chains at a glance

| Goal | Chain |
|------|-------|
| Clean scanned book | Cut → Crop → Resize → Page numbers → Compress |
| Email-ready report | Merge → Page numbers → Compress |
| Safe public copy | Metadata (erase) → Flatten forms → Rasterize → Password protect |
| Print handout | Delete pages → Multiple pages per sheet |
| Archive | Compress (Light) → Properties (set title/author) |

---

## 3.18 Make a scanned PDF searchable (OCR)

1. Open the scan. Choose **Edit, OCR & sign > OCR (make scans searchable)**.
2. **Language(s)**: `eng` for English, `hin` for Hindi, `eng+hin` for mixed pages (the box "Installed" lists what you have;
   more languages: see 1.1). Resolution `300`. Run.
3. Open the result and try `Ctrl+F` in any PDF viewer - the words in the pictures are now found and can be copied.
4. Optional: **Compress** to reduce the size, **PDF → Text** to export the text.

Tips: straighten crooked pages first (Rotate) and remove dark borders (Crop). Check names and numbers by eye - OCR is never perfect.

## 3.19 Correct a word or number in a PDF

1. **Find & replace text** - Find `Ravi Kumar`, Replace with `Anil Sharma`. Run.
2. Check the result in the preview. If the new text overlaps, keep **Shrink to avoid overlapping text** ticked or choose a shorter text.

For a scanned PDF run **OCR** first (3.18). This tool edits *words*; it does not re-flow paragraphs or change pictures.

## 3.20 Hide personal data before sharing (redaction)

1. **Redact** - tick **E-mail addresses**, **Phone numbers**, **Aadhaar numbers**, **PAN numbers** as needed, and/or type names
   (one per line). Run. The text is removed from the file, not only covered by a box.
2. **Properties (metadata)** - tick **Erase all metadata**. Run.
3. Open the result and search (`Ctrl+F`) for a removed word to confirm it is really gone.

For scanned documents: **OCR** first (so the program can find the words), then redact, then **Rasterize** if you want everything flattened.

## 3.21 Sign a PDF digitally

1. *(once)* **Create signing certificate** - enter your name, a password (twice), Run, and save the `.p12` file somewhere safe.
2. Finish all edits first. Then **Digital signature** - choose the `.p12`, enter its password, add a Reason, keep
   **visible signature box**, choose page and position. Run.
3. **Do not edit the signed file again** (a change breaks the signature). Send it as it is.
4. To check any file: **Check signatures** - saves a report telling whether the document is unchanged since signing.

A self-made certificate shows as *not trusted* in other programs; this is normal. The signature still proves that the file
was not changed after signing. A legally recognised class-2/3 certificate (.pfx from a licensed authority) works the same way.

## 3.22 Build or fix the table of contents (bookmarks and page labels)

* **Bookmarks:** open **Bookmarks (outline)**; the existing ones are listed. Write `Introduction | 1`, `  Background | 2`
  (two spaces = sub-item), `Chapter 1 | 5`. Run.
* **Page labels** (what viewers show as the page number): preface in roman numerals - Starting at page `1`, Numbering
  `i, ii, iii`, Run. Then continue on the result: Starting at page `5` (first chapter), Numbering `1, 2, 3`, First number `1`, Run.

## 3.23 Remove blank pages from a double-sided scan

1. **Remove blank pages** - Sensitivity `0.3`. Run. The message lists the removed pages.
2. If some blank pages stay (scanner noise), raise the sensitivity to `1`; if pages with only a few words are removed,
   lower it to `0.1`. Compare the page counts before accepting the result.

## 3.24 Fill in a form and highlight key words

* **Fill form fields**: change the values after `=` (for example `full_name = Asha Rao`, `agree = Yes`). Tick **Make the entries
  permanent** if the receiver should not be able to edit them. Run.
* **Highlight / underline text**: type the words (one per line), choose *highlight* and a colour. Run.
