# 7. Features and Limitations

## 7.1 Everything the program can do (37 tools)

| Group | Tools |
|-------|-------|
| **Organise** | Merge (bookmark per file) · Split (every page / every N / equal parts / ranges / by bookmarks) · Extract · Delete · Reorder & reverse · Duplicate · Insert blank pages · Remove blank pages · Rotate |
| **Page size & cutting** | Crop (visual, units, auto-crop) · Cut into pieces (double-page scans, N pieces, right-to-left) · Resize (A0-A6, B4/B5, Letter, Legal, Tabloid, custom; fit / fill / stretch) · Scale % · Multiple pages per sheet (2/4/6/9-up, custom) |
| **Optimise** | Compress (4 levels + custom DPI/quality) · Rasterize (pages to pictures, grayscale) |
| **Convert** | PDF → PNG/JPG/WebP/TIFF/BMP · Images → PDF · PDF → Text · Extract embedded images |
| **Watermark & numbers** | Text watermark (any script) · Image / logo watermark · Page numbers, headers, footers |
| **Security & properties** | Password protect (AES-256, permissions) · Remove password · Properties / erase metadata · Flatten forms & comments |
| **Edit, OCR & sign** | OCR · Find & replace text · Redact · Highlight / underline · Fill form fields · Bookmarks · Page labels · Create signing certificate · Digital signature · Check signatures |

Cross-cutting: preview and thumbnails, drag and drop, Ctrl-click page picking, *Continue editing* chains, background jobs with
Cancel, atomic saves, originals never overwritten, offline operation, Windows/macOS/Linux, Hindi/Bengali/Tamil/Arabic etc. text.

## 7.2 What is kept by which tool

| Item | Kept by |
|------|---------|
| Metadata, bookmarks | all tools except where page numbers change (Cut, Pages per sheet drop bookmarks) |
| File attachments | **all** tools |
| Page labels (i, ii, A-1 ...) | Extract, Delete, Reorder, Duplicate, Blank pages, Cut, Merge, Split, Resize, Scale, Rasterize, Crop, Rotate, Compress, stamping. Not Pages per sheet (sheets are not pages of the original). |
| Links | all tools; redrawing tools (Resize, Scale, Cut, Pages per sheet) carry them over |
| Annotations, form fields | kept by Crop, Rotate, Compress, stamping; *burned into the page* by Resize, Scale, Cut, Pages per sheet |
| Digital signatures | none: every edit invalidates them (sign last) |

## 7.3 What the program does not do

Honest limits, with the practical workaround:

| Not supported | Why / what to do instead |
|---------------|--------------------------|
| Word-processor style editing (re-flowing paragraphs, changing the font of existing text, moving text blocks) | PDF stores positioned characters, not paragraphs. Use *Find & replace text* for words and numbers; for big rewrites edit the source document (Word etc.) and export again. |
| Editing text inside pictures or scans | Run **OCR** first (adds searchable text), then replace/redact. The picture itself is not changed - use **Redact** or **Rasterize** to hide content. |
| Perfect OCR | OCR quality depends on the scan. Check names and numbers by eye. Handwriting is not recognised. Languages other than English and Hindi need a free language file (1.1). |
| Editing, replacing or deleting individual pictures in a PDF | Extract the pictures (Extract embedded images) and rebuild, or use Redact (blanks picture areas under a box). |
| Designing new fillable forms | Existing forms can be filled and flattened; creating form fields is not included. |
| Legally recognised (qualified / Aadhaar eSign) signatures from a government or CA service | The program signs with *your* .p12/.pfx certificate. A personal certificate is "not trusted" in other programs; a certificate issued by a licensed authority works the same way and will be trusted. Online eSign services are not available (the program is offline). Timestamp servers are not used. |
| Keeping an existing signature while editing | Impossible by design - edit first, sign last. |
| Opening a password-protected file without the password / password recovery | Not provided, by design. |
| Page-label styles through *Pages per sheet* | Sheets do not correspond to original pages. |
| Accessibility tags (tagged PDF structure) after tools that redraw pages | Redrawing tools create new pages; tags are not rebuilt. |
| Batch processing of many files in one click | One document at a time; Merge, Split, Images → PDF cover multi-file work. The engine can be scripted in Python (Developer Guide). |
| Translating a PDF, comparing two PDFs, PDF/A conversion, form/data extraction to Excel | Not included. |
| Interface in languages other than English | PDF *content* in any language works; the menus are English. |
