# 6. Developer Guide

## 6.1 Layout

```
main.py              entry point (startup error reporting)
pdfkit/ops.py        the engine: every PDF operation, no GUI code
pdfkit/advanced.py   OCR, replace text, redact, signatures, bookmarks, labels, blank pages
pdfkit/imaging.py    image + shaped-text helpers built on Qt (no Pillow)
gui/main_window.py   main window, background Worker, error log
gui/tools.py         one panel class per tool (37 panels)
gui/preview.py       page view, crop/grid overlays, thumbnails
gui/widgets.py       page-range field, file list, size chooser, pickers
tests/               pytest suite (104 tests)
```

## 6.2 Libraries

* **PyMuPDF** (`pymupdf`, pinned `>=1.24.2,<2`) - all PDF reading/writing/rendering.
* **PySide6-Essentials** - the GUI, plus `QImage`/`QPainter` for picture I/O and text shaping.
* **pyHanko** (+ `cryptography`, `tzdata`) - digital signatures (optional at run time: the tool explains if missing).
* OCR uses PyMuPDF's built-in Tesseract with the `.traineddata` files from `tessdata/`.
* No Pillow. Licences: PyMuPDF is AGPL-3.0 (or commercial), PySide6 is LGPL. Check these before distributing.

## 6.3 Using the engine from Python

```python
from pdfkit import ops
ops.merge_pdfs(["a.pdf", "b.pdf"], "all.pdf", bookmarks=True)
ops.extract_pages("all.pdf", "part.pdf", "1-3,last")
ops.compress_pdf("part.pdf", "small.pdf", level="medium")
```

All functions take a source, an output path and options; they never overwrite the source, raise `ops.PDFError`
(readable message) on user mistakes, and accept a `progress(done, total)` callback that may raise `ops.Cancelled`.
Results are written to a `.part` file and moved into place, so a failed run leaves no half-written output.

## 6.4 Design rules

1. Engine has no Qt-widget dependency; GUI only calls `ops`.
2. Widget values are copied into a `Frozen` snapshot on the GUI thread; the job runs in a `Worker` thread.
   PyMuPDF and Qt widgets are not thread-safe, so the window is locked while a job runs.
3. Rebuild tools bake page rotation first (`_upright_source`) and carry links (`_carry_links`).
4. Rebuild tools keep metadata, bookmarks and file attachments (`_finish_copy`, `_copy_attachments`). Page labels are
   carried per page (`_page_labels` / `_apply_labels`) through extract, delete, reorder, duplicate, blank, cut, merge, split,
   resize, scale, rasterize; Pages-per-sheet (n-up) cannot map sheets to pages.
5. Non-Latin text is rendered by Qt to a transparent PNG (`imaging.render_text`); Latin text stays real PDF text.

## 6.5 Adding a tool

1. Write `def my_tool(src, out, ..., progress=None)` in `pdfkit/ops.py`; call `_check_out(src, out)` first and `_save` last.
2. Add a `ToolPanel` subclass in `gui/tools.py` with `make_job()` returning a callable, and register its key.
3. Add tests in `tests/test_ops.py` and a section in `docs/04_Tool_Reference.md`.

## 6.6 Tests

```
pip install pytest
QT_QPA_PLATFORM=offscreen python -m pytest -q tests      # Windows: set QT_QPA_PLATFORM=offscreen first
```

## 6.7 Building a standalone program

`Build_Standalone_EXE.bat` (Windows) or `build_standalone.sh` installs PyInstaller in the `.venv` and creates
`dist/PDFToolkit/`. Building does not start the app.
