# 4. Tool Reference

All 37 tools, in the order they appear in the tool list. For every tool you find: what it does, every option,
what is saved, and good-to-know details.

**Conventions used below**

* **Pages** = the page-selection box described in section 2.5 (`all`, `1-3,7`, `odd`, `5-last` ...).
* Unless stated otherwise the result is a **new PDF** with the suggested name *original name + suffix*
  (for example `report_cropped.pdf`). The original is never changed.
* Bookmarks, document properties and links are kept wherever the operation allows it. Exceptions are listed per tool.

---

## Group 1 - Organise

### 4.1 Merge PDFs
Combine several PDFs into one, in the order of the list.

| Option | Meaning |
|--------|---------|
| File list | **Add...** files (several at once), **Remove**, **Clear**, **Up** / **Down**, **Sort A-Z**, or drag items. Drag PDFs from your file manager onto the window while this tool is selected. |
| Add the open PDF | puts the currently opened file into the list |
| Add a bookmark for each file | creates one top-level bookmark per file (named after the file) and keeps each file's own bookmarks nested below it. Default: on |

*Needs:* at least two files. *Default name:* `merged.pdf` in the folder of the first file.
Password-protected sources: you are asked for each password first. Empty PDFs are skipped.

### 4.2 Split PDF
Break one PDF into several files, written into a folder you choose.

| Option | Meaning |
|--------|---------|
| Split by | **Every page** (one file per page) · **Every N pages** · **Number of equal parts** · **Custom page ranges** · **Top-level bookmarks / chapters** |
| Pages per file | for *Every N pages* |
| Number of parts | for *equal parts*; if the pages do not divide evenly, the first parts get one extra page |
| Ranges | for *Custom*: comma-separated items, **each item becomes one file**. Example: `1-3, 4-7, 9, 10-last` |

*File names:* `name_page_5.pdf`, `name_pages_1-3.pdf`, `name_part_01.pdf` (parts / custom), or
`name_02_Chapter title.pdf` (bookmarks; pages before the first bookmark become `..._Front matter.pdf`).
Illegal characters in titles are replaced by `_`. Existing files are never overwritten (` (1)` is added).

### 4.3 Extract pages
Save the chosen pages as a new PDF, in their original order. *Option:* Pages. Suffix `_extracted`.

### 4.4 Delete pages
Remove the chosen pages and save the rest. *Option:* Pages. You cannot delete every page.
Suffix `_trimmed`.

### 4.5 Reorder / reverse
Build a new page sequence by typing the order.

| Option | Meaning |
|--------|---------|
| New order | for example `3,1,2` or `5-8,1-4` or `10, 1-9, 11-last` |
| **Reverse all pages** button | fills in `last-1` |
| **Fill current order** button | fills in `1-N` (all pages in order) so you can edit it |

Pages you do not list are **dropped**; pages you list twice are **duplicated**. Descending ranges (`5-1`) are allowed.
Suffix `_reordered`.

### 4.6 Duplicate pages
Repeat selected pages directly after themselves. *Options:* Pages; **Extra copies** (1-99). Suffix `_duplicated`.

### 4.7 Insert blank pages
| Option | Meaning |
|--------|---------|
| After page(s) | pages after which to insert, e.g. `1`, `2,5`, `all`. `0` = at the very beginning |
| Blank pages | how many blank pages at each place (1-50) |

Blank pages get the size of the neighbouring page. Suffix `_with_blanks`.

### 4.8 Rotate pages
*Options:* Pages; Rotation = **90° clockwise**, **180°**, **90° counter-clockwise**. The rotation is added to the
page's current rotation (so a page already turned 90° and rotated 90° more ends up at 180°). Text stays selectable.
Suffix `_rotated`.

---

## Group 2 - Page size & cutting

### 4.9 Crop margins
Remove margins from pages. An orange frame in the preview shows the area that will be **kept**; drag its edges or
corners (8 handles), or type numbers. Frame and numbers always stay in sync.

| Option | Meaning |
|--------|---------|
| Units | `mm`, `cm`, `in`, `pt`, `%` (of each page's own width/height) |
| Margins to remove | Left, Top, Right, Bottom |
| Auto-crop white borders | ignores the margins and trims every page to its own content (blank pages are left as they are) |
| Keep padding (pt) | free space kept around the content with auto-crop (default 5) |
| Pages | which pages to crop |
| Reset margins | sets all four to zero |

*Details:* the same *absolute* margin is applied to every selected page. A crop that would leave less than 10 points
raises an error naming the page. Rotated pages are cropped as you see them. Suffix `_cropped`.

> **Important:** cropping sets the visible page area, exactly like Adobe Acrobat. The cropped-away content is *still
> inside the file*. To remove it permanently use **Rasterize**.

### 4.10 Cut pages into pieces
Cut every selected page into a grid of new pages.

| Option | Meaning |
|--------|---------|
| Columns / Rows | 1-10 each (at least 2 pieces in total) |
| Quick buttons | *2 side by side*, *2 top / bottom*, *4 quarters* |
| Right-to-left order | order the pieces right to left (manga, Arabic books) |
| Pages | pages to cut; **pages you do not select are copied unchanged** |

Red dashed lines with numbers in the preview show the cuts and the resulting order (left to right, then top to
bottom). Each piece becomes its own page, so 10 pages cut 2×1 give 20 pages. Web links are carried over; bookmarks
are not (page numbers change). Suffix `_cut`.

### 4.11 Resize page size
Change the paper size and scale the content to fit.

| Option | Meaning |
|--------|---------|
| New size | A0-A6, B4, B5, Letter, Legal, Tabloid, Executive, or **Custom** (width × height with unit mm / cm / in / pt) |
| Content | **Fit** (keep proportions, everything visible, white bars if shapes differ) · **Fill** (cover the page, crop overflow) · **Stretch** (exact fit, distorts) |
| Margin (mm) | white border inside the new page |
| Keep landscape pages landscape | wide pages get the landscape version of the chosen size (square pages are left alone) |
| Pages | pages to resize; the others are copied unchanged |

Highlights, notes and typed form values are burned into the page (still visible, no longer editable); web links and
in-document links are kept (except on rotated pages). Suffix `_resized`.

### 4.12 Scale pages (%)
Enlarge or reduce the page together with its content. *Options:* **Scale** 5-1000 %, Pages. Suffix `_scaled`.

### 4.13 Multiple pages per sheet
Put several pages on one sheet ("N-up").

| Option | Meaning |
|--------|---------|
| Layout | 2 per sheet (2×1) · 4 (2×2) · 6 (3×2) · 9 (3×3) · 2 stacked (1×2) · **Custom** (columns, rows) |
| Sheet size | A0-A6, B4, B5, Letter, Legal, Tabloid, Executive |
| Margin / Gap (mm) | outer margin and space between pages |
| Draw a border around each page | thin grey frame |

Sheets are landscape when there are more columns than rows, otherwise portrait. Pages keep their proportions and are
placed left to right, top to bottom. Suffix `_nup`.

---

## Group 3 - Optimise

### 4.14 Compress / reduce size
Make the file smaller.

| Level | What it does |
|-------|--------------|
| **Light** | lossless: removes unused data, merges duplicate objects, compresses structures (and trims embedded fonts to the letters used, if the optional `fonttools` package is installed) |
| **Medium** (default) | additionally re-compresses images sharper than 170 dpi down to 130 dpi, JPEG quality 70 |
| **High** | images above 130 dpi → 96 dpi, quality 55 |
| **Extreme** | images above 90 dpi → 72 dpi, quality 40 |
| Custom image settings | tick it and set **Image DPI** (30-600) and **JPEG quality** (10-95) yourself |

The result message shows `before → after (xx % smaller)`. If the result would not be smaller, **a copy of the
original is saved** and you are told. Text, links and bookmarks are untouched. Suffix `_compressed`.

### 4.15 Rasterize (pages → pictures)
Redraw pages as pictures inside a new PDF.

| Option | Meaning |
|--------|---------|
| Resolution (DPI) | 36-600, default 150 |
| JPEG quality | 10-100, default 85 |
| Convert to grayscale | black-and-white-style output, smaller |
| Pages | pages to convert; the others are copied unchanged |

Use it to permanently remove cropped-away content, hidden text and invisible layers, to make a file look identical
on every device, or to reduce a complex file to simple pictures. Text is **no longer selectable or searchable**.
Suffix `_rasterized`.

---

## Group 4 - Convert

### 4.16 PDF → Images
Save pages as pictures into a folder you choose.

| Option | Meaning |
|--------|---------|
| Format | `png`, `jpg`, `webp`, `tiff`, `bmp` |
| Resolution (DPI) | 10-1200, default 150 (use 300 for print) |
| Quality (jpg/webp) | 10-100 |
| Pages | which pages |

Files are named `name_page_001.png` (number padded to at least 3 digits).

### 4.17 Images → PDF
Build a PDF from pictures (one picture per page).

| Option | Meaning |
|--------|---------|
| Image list | **Add...**, **Remove**, **Clear**, **Up** / **Down**, **Sort A-Z**, or drag. Drag image files onto the window while the tool is selected |
| Page size | `Same as image` (page shaped like the picture) or a paper size (picture fitted inside; page orientation follows the picture) |
| Image DPI | for *Same as image*: how large a pixel is (150 dpi = 1 inch per 150 pixels) |
| Margin (mm) | white border |

Reads JPG, PNG, WebP, TIFF, BMP and GIF. Phone photos are rotated correctly (EXIF orientation). Transparency becomes
white. Normal JPEG files are stored **without re-compression**. Default name `images.pdf`.

### 4.18 PDF → Text
Save the text as a UTF-8 `.txt` file. *Option:* Pages. Each page starts with a line `----- Page N -----`. Reading
order is sorted top-to-bottom, left-to-right. Pages without text (scans) are counted and reported - to make them searchable use **OCR** (4.30).

### 4.19 Extract embedded images
Save the pictures stored inside the PDF in their original quality.

| Option | Meaning |
|--------|---------|
| Skip images below (px) | ignore tiny icons and bullets (default 32) |
| Pages | which pages |

Each picture is saved once even when it appears on many pages; JPEG and PNG pictures keep their format, others are saved
as PNG (transparency masks are applied). Names: `name_p3_img1.jpg`.

---

## Group 5 - Watermark & numbers

### 4.20 Text watermark
Print text across pages.

| Option | Meaning |
|--------|---------|
| Text | type or pick: CONFIDENTIAL, DRAFT, COPY, SAMPLE, DO NOT COPY, APPROVED |
| Font size | 8-400 pt, default 60 |
| Colour | click the button to choose |
| Opacity | 5-100 %, default 25 |
| Angle (°) | counter-clockwise, -180 to 180, default 45 |
| Repeat over the whole page | tiles the text diagonally across the page |
| Font (optional) | a `.ttf` / `.otf` file to force a look (see below) |
| Pages | which pages |

**Languages:** Latin text becomes real PDF text. Scripts that need shaping (Hindi, Bengali, Tamil, Arabic ...) and
other non-Latin text are drawn correctly using an installed font as a sharp picture (see 3.16). Rotated pages are
handled so the watermark always reads upright. Suffix `_watermarked`.

### 4.21 Image / logo watermark
Stamp a picture on pages.

| Option | Meaning |
|--------|---------|
| Image | PNG (transparent background recommended), JPG, WebP, TIFF, BMP, GIF |
| Width (% of page) | 2-200 % of the page width |
| Opacity | 5-100 %, default 40 |
| Rotation (°) | counter-clockwise; the width setting applies to the rotated picture |
| Position | 9 positions (top/middle/bottom × left/center/right) |
| Margin (pt) | distance from the page edge |
| Repeat over the whole page | tiles the picture |
| Pages | which pages |

Suffix `_stamped`.

### 4.22 Page numbers / header / footer
Add text at one of six positions on selected pages.

| Option | Meaning |
|--------|---------|
| Preset | `Page 1` · `Page 1 of 10` · `- 1 -` · `File name and date` · Custom |
| Text | any text with placeholders: `{n}` page number, `{total}` last page number, `{file}` file name, `{date}` today (YYYY-MM-DD) |
| Position | top-left / top-center / top-right / bottom-left / bottom-center / bottom-right |
| Font size | 4-72 pt, default 10 |
| Colour | text colour |
| Distance from edge (pt) | default 28 |
| First page is numbered | the number printed on page 1 (default 1; use 0 or 5 etc. to offset). `{total}` follows it |
| Skip first page | leaves the cover without a number |
| Font (optional) | see 4.20 |
| Pages | which pages |

Suffix `_numbered`. Non-Latin text works as described in 4.20.

---

## Group 6 - Security & properties

### 4.23 Password protect
AES-256 encryption.

| Option | Meaning |
|--------|---------|
| Password / Repeat password | needed to open the file; **cannot be recovered** if forgotten |
| Show password | reveals the typed characters |
| Allow printing / copying text / editing / comments & form filling | permissions that PDF viewers honour |

A separate random *owner password* is created automatically, so the permission limits cannot be bypassed by someone who
only knows the opening password. Suffix `_protected`.

### 4.24 Remove password
Saves an unprotected copy of a protected PDF. *Option:* Password (leave empty if you already opened the file in the
program with the password). You must know the password - the program cannot break passwords. Suffix `_unlocked`.

### 4.25 Properties (metadata)
Edit Title, Author, Subject and Keywords (pre-filled from the open file), or tick **Erase all metadata** to remove every
property including creation dates, creator software and the hidden XMP block. Suffix `_meta`.

### 4.26 Flatten forms & comments
Burns form fields (with their typed values), highlights, stamps and comments into the page so they can no longer be
edited or removed. Suffix `_flattened`.

---

## Also available

* **Document info** (top bar): size, pages, version, encryption, bookmarks, links, annotations, form fields, page
  sizes, properties.
* **Open / Show folder / Continue editing this file** after each run.

---

## Group 7 - Edit, OCR & sign

### 4.27 Remove blank pages *(group Organise)*
Finds pages with no visible content (typical for double-sided scans) and deletes them. The 3 % border of each page is
ignored so scanner shadows do not count. *Option:* **Sensitivity** (% of dark pixels a page may contain and still count
as blank; default 0.3). If nothing is found, nothing is saved and the message says so. The message lists the page numbers
removed. Bookmarks, labels and attachments follow the kept pages. Suffix `_noblank`.

### 4.28 Find & replace text
Changes existing text of a text-based PDF.

| Option | Meaning |
|--------|---------|
| Find / Replace with | The exact text. Replace may be empty (deletes the text). |
| Match upper/lower case | Off by default. |
| Shrink to avoid overlapping text | New text that would run into the next word on the line is made smaller; with room to spare it keeps the original size. |
| Font (optional) | A `.ttf` / `.otf` file for letters the standard fonts do not have. |
| Pages | Which pages. |

How it works: the old text is **removed** from the page (not just covered), then the new text is drawn at the same place in
the same size and colour, using the closest standard font (Helvetica / Times / Courier, bold and italic kept). The original
embedded font is **not** reused, so the new words can look slightly different. Hindi, Bengali, Arabic etc. are shaped
correctly but placed as a picture (not selectable). Text inside pictures cannot be replaced; scans need **OCR** first.
Suffix `_replaced`. The message tells how many occurrences were replaced.

### 4.29 Redact (black out text)
Permanently removes sensitive text: the characters are deleted from the page content and pictures under the box are blanked,
then a coloured box is painted. Texts to remove: one per line. Tick patterns for **e-mail addresses**, **phone numbers**,
**Aadhaar numbers** (`1234 5678 9012`), **PAN numbers**, **card numbers**, or type **your own regular expression**.
Options: match case, box colour, pages. Suffix `_redacted`.
After redacting, run **Properties (metadata) > Erase all metadata**, and for scans of ID cards use **Rasterize** as well.
Only text that is really in the PDF can be found - scanned pages need OCR first.

### 4.30 OCR (make scans searchable)
Recognises text in scanned pages and adds an **invisible text layer**, so the document can be searched, selected and copied.

| Option | Meaning |
|--------|---------|
| Language(s) | Tesseract codes, joined with `+`: `eng`, `hin`, `eng+hin`. The box "Installed" lists the languages found. |
| Resolution (DPI) | 300 is a good balance; use 400 for small print. |
| Skip pages that already have text | On: only picture pages are processed. |
| Pages | Which pages. |

Each recognised page becomes **its picture plus hidden text** (the page looks the same). Pages are processed one by one
and the job can be cancelled. Accuracy depends on scan quality - straight, sharp, 300 DPI scans give the best results; the
result is never 100 % perfect. Needs the language file for each language (see 1.1). Suffix `_ocr`.

### 4.31 Bookmarks (outline)
Edit the table of contents. The box shows the existing bookmarks. One per line: `Title | page`; indent a line by two
spaces for a sub-item. Tick **Remove all bookmarks** to delete them. Errors name the line (unknown page, missing `|`).
Suffix `_bookmarks`.

### 4.32 Page labels (i, ii, A-1 ...)
Controls the page numbers PDF viewers display (not the printed numbers). Options: **Starting at page**, **Numbering**
(1,2,3 / i,ii,iii / I,II,III / a,b,c / A,B,C / none), **Prefix** (for example `A-`), **First number**, or **Remove all page
labels**. A rule runs until the next rule. Run the tool again for another section. Typical use: preface `i, ii, iii`,
then `1, 2, 3` from the first chapter. Suffix `_labels`.

### 4.33 Create signing certificate
Creates a personal **.p12** certificate (RSA 2048, SHA-256) from your name, optional organisation/e-mail, a password and a
validity (default 3 years). This file is your signing identity - **keep it and its password safe**. Does not need an open PDF.
Personal certificates are "not trusted" in other programs (only paid certificate authorities are); the signature still proves
the document is unchanged and who holds the certificate.

### 4.34 Digital signature
Signs the PDF with a `.p12` / `.pfx` certificate.

| Option | Meaning |
|--------|---------|
| Certificate file and password | Your `.p12` / `.pfx`. A wrong password gives a clear message. |
| Reason, Location | Stored in the signature and shown in the box. |
| Show a visible signature box | A framed box with signer, date, reason and location; choose page and position. |

The signature is added as an incremental update (PDF-standard, works in Adobe Reader, browsers and others). **Sign last:**
any later change (also by this program) breaks the signature. Password-protected files must be unlocked first. On a page
that is rotated the signature is added without a visible box. Suffix `_signed`.

### 4.35 Check signatures
Looks at every signature and saves a short `.txt` report: signer, whether the file is **unchanged since signing**, whether
it was extended afterwards, and whether the certificate is trusted. Files without signatures are reported as such.

### 4.36 Fill form fields
For PDFs with fillable forms. The list shows each field as `name = value`; change the values and run. Check boxes and
radio buttons: `Yes` / `No`. Fields you do not mention stay as they are; names that do not exist are reported. Tick
**Make the entries permanent (flatten)** to turn the form into normal page content. The program fills existing fields; it does
not design new forms. Suffix `_filled`.

### 4.37 Highlight / underline text
Marks every occurrence of the given words (one per line) with an annotation: *highlight*, *underline*, *strikeout* or
*squiggly*, in a colour of your choice. Options: match case, pages. The marks are normal PDF comments (editable in other
viewers; use **Flatten forms & comments** to make them permanent). Suffix `_marked`.
