# 1. Installation and Setup

PDF Toolkit is a desktop program written in Python. You do not need to know Python: the launcher
files install everything for you the first time you start it.

## 1.1 What you need

| Item | Requirement |
|------|-------------|
| Operating system | Windows 10/11, macOS 11 or newer, or a Linux desktop (X11 or Wayland) |
| Python | **3.9 or newer** (3.12 recommended). Download: <https://www.python.org/downloads/> |
| Disk space | about **450 MB** (the program itself is tiny; Python packages are about 350 MB) |
| Memory | 4 GB is fine for normal files; 8 GB or more helps with very large scans |
| Internet | **only for the first start** (to download the packages). Afterwards the program works fully offline |

The packages that get installed automatically (listed in `requirements.txt`):

| Package | Used for |
|---------|----------|
| **PyMuPDF** (1.x) | reading, editing and rendering PDF files |
| **PySide6-Essentials** | the window, plus reading/writing images (PNG, JPEG, WebP, TIFF, BMP, GIF) |
| **pyHanko** (+ cryptography) | digital signatures: signing, checking, creating a certificate |
| **tzdata** | time-zone data (signature time stamps; mainly needed on Windows) |

No other image library (such as Pillow) is needed.

**OCR language data (included).** The OCR tool needs small *Tesseract* language files. English (`eng`) and Hindi (`hin`) are
included in the `tessdata` folder. Other languages (Bengali `ben`, Tamil `tam`, Telugu `tel`, Marathi `mar`, Gujarati `guj`,
Kannada `kan`, Malayalam `mal`, Punjabi `pan`, Urdu `urd`, Arabic `ara`, French `fra` ...) are free: download the
`<code>.traineddata` file from <https://github.com/tesseract-ocr/tessdata_fast> and copy it into the `tessdata` folder.
No extra program has to be installed.

**Upgrading from an older version:** copy the new program files over the old folder (keep or delete `.venv`). The launcher
detects missing packages and installs them automatically.

## 1.2 Windows - step by step

1. **Install Python.** Download the Windows installer from python.org. On the first screen tick
   **"Add python.exe to PATH"**, then click *Install Now*.
2. **Extract the zip file.** Right-click `PDFToolkit.zip` and choose **Extract All...**.
   Do not start the program from inside the zip window - it only works from a normal folder.
   Any folder is fine, including folders with spaces or non-English letters in the name.
3. **Start it.** Open the extracted `PDFToolkit` folder and double-click **`Run_PDF_Toolkit.bat`**.
   * A black window opens on the very first start and installs the packages. This takes
     **3 to 10 minutes** depending on your internet speed. Leave it open.
   * When it finishes, the PDF Toolkit window appears and the black window closes.
   * From then on the program starts in about a second, with no black window.
4. **Make a shortcut (optional).** Right-click `Run_PDF_Toolkit.bat` > *Send to* > *Desktop (create shortcut)*.
   You can rename the shortcut to "PDF Toolkit".

> **"Windows protected your PC" message?** The `.bat` file is not digitally signed, so SmartScreen may warn.
> Click **More info** > **Run anyway**. The file is plain text - you can open it in Notepad and read it.

## 1.3 macOS

1. Install Python 3 from python.org (or with Homebrew: `brew install python@3.12`).
2. Extract the zip (double-click it in Finder).
3. Open **Terminal**, then type `cd ` (with a space), drag the extracted `PDFToolkit` folder into the
   Terminal window, and press Enter.
4. Run:

   ```bash
   chmod +x run_pdf_toolkit.sh      # only needed once - zip files can lose the "executable" flag
   ./run_pdf_toolkit.sh
   ```

The first start downloads the packages (3 to 10 minutes). After that, run `./run_pdf_toolkit.sh` again
whenever you want to use the program.

## 1.4 Linux

Install Python and the Qt system libraries once (Debian / Ubuntu shown):

```bash
sudo apt install python3 python3-venv libxcb-cursor0 libegl1 libgl1 libxkbcommon-x11-0
```

Then:

```bash
cd PDFToolkit
chmod +x run_pdf_toolkit.sh
./run_pdf_toolkit.sh
```

On Fedora use `sudo dnf install python3 xcb-util-cursor mesa-libEGL`.
If the window does not appear on a Wayland desktop, try `QT_QPA_PLATFORM=xcb ./run_pdf_toolkit.sh`.

## 1.5 Manual installation (any system)

If you prefer to do it yourself, or you want to use your own virtual environment:

```bash
cd PDFToolkit
python -m venv .venv

# Windows:            .venv\Scripts\activate
# macOS / Linux:      source .venv/bin/activate

python -m pip install -r requirements.txt
python main.py                 # start the program
python main.py "my file.pdf"   # start and open a file straight away
```

## 1.6 A standalone program (no Python needed on the target PC)

You can turn the project into a folder that runs on a computer **without** Python installed.
This must be done on the same type of system you will run it on (Windows for Windows, etc.).

* **Windows:** double-click `Build_Standalone_EXE.bat`. When it finishes, copy the whole
  `dist\PDFToolkit` folder anywhere and start `PDFToolkit.exe` inside it.
* **macOS / Linux:** run `./build_standalone.sh`; the result is in `dist/PDFToolkit`.

Keep the whole folder together (the `.exe` needs the files next to it). Building needs internet and takes
several minutes.

> **Licence reminder:** PyMuPDF is licensed under AGPL-3.0 (or a paid commercial licence). Using the program
> yourself is fine. If you give the program to other people, read the licence section in the Developer Guide.

## 1.7 Installing without internet (offline / locked-down PCs)

*On a computer with internet and the **same Python version and operating system** as the target:*

```bash
python -m pip download -r requirements.txt -d wheels
```

Copy the `PDFToolkit` folder together with the new `wheels` folder to the offline computer, then:

```bash
python -m venv .venv
.venv\Scripts\python -m pip install --no-index --find-links wheels -r requirements.txt     # Windows
.venv/bin/python -m pip install --no-index --find-links wheels -r requirements.txt         # macOS / Linux
```

After that the launcher (`Run_PDF_Toolkit.bat` / `run_pdf_toolkit.sh`) sees the finished `.venv` folder and just starts
the program. The easiest alternative is to build the standalone program (section 1.6) on the connected computer and
copy the result.

## 1.8 Behind a company proxy

Set the proxy before the first start, in the same Command Prompt:

```bat
set HTTPS_PROXY=http://proxy.example.com:8080
Run_PDF_Toolkit.bat
```

## 1.9 Checking that the installation works

The project ships with automated tests (83 of them). They create sample PDFs, run every tool and check the
results pixel by pixel.

```bash
python -m pip install pytest
python -m pytest -q                      # Windows / macOS
QT_QPA_PLATFORM=offscreen python -m pytest -q    # Linux without a screen
```

All tests should pass ("83 passed").

## 1.10 Updating, moving and removing

| Task | How |
|------|-----|
| Update to a new version | Extract the new zip into a **new** folder and start it. (Your PDFs are never stored inside the program folder.) |
| Move the program | Copy the whole folder. If the program stops starting after moving it to another drive or PC, delete the `.venv` folder inside it; it is re-created on the next start. |
| Remove the program | Delete the program folder. Optional leftovers: the settings (last-used folder) in the Windows registry under `HKEY_CURRENT_USER\Software\PDFToolkit`, or `~/.config/PDFToolkit` on Linux / `~/Library/Preferences` on macOS, and the error log `PDFToolkit_error.log` in your home folder. |

## 1.11 What is in the folder

```
PDFToolkit/
  Run_PDF_Toolkit.bat        Windows launcher (installs on first run, then starts the program)
  run_pdf_toolkit.sh         macOS / Linux launcher
  Build_Standalone_EXE.bat   Windows: build a program that needs no Python
  build_standalone.sh        macOS / Linux: same
  main.py                    program entry point
  requirements.txt           the packages that are installed
  tessdata/                  OCR language files (eng, hin included; add more here)
  README.md                  short overview
  CHANGELOG.md               what changed in each version
  pdfkit/                    the PDF engine (no window code; can be used from scripts)
    ops.py                     core PDF operations
    advanced.py                OCR, replace text, redact, signatures, bookmarks, labels, blank pages
    imaging.py                 image reading/writing helpers
  gui/                       the window (PySide6)
    main_window.py             main window, background worker
    preview.py                 page preview, thumbnails, crop overlay
    tools.py                   one panel per tool
    widgets.py                 small reusable controls
  tests/                     automated tests
  docs/                      this documentation
  .venv/                     created on first start (the installed packages)
```
