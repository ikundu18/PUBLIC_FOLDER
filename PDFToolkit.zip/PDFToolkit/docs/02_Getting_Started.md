# 2. Getting Started

## 2.1 The window at a glance

```
+--------------------------------------------------------------------------------------+
| [Open PDF...]  report.pdf · 24 pages · 1.8 MB         [Document info] [Close file]   |
+----------------+-------------------------+-------------------------------------------+
| TOOL LIST      |  TOOL OPTIONS           |   < [3] / 24 >                 - Fit +    |
|                |                         | +------+  +-------------------------------+|
| Organise       |  Crop margins           | |thumb |  |                               ||
|   Merge        |  Units      [mm]        | |thumb |  |        PAGE PREVIEW           ||
|   Split        |  Left   [ 12.0 ]        | |thumb |  |   (orange crop frame, red cut ||
|   ...          |  Top    [ 10.0 ]        | |thumb |  |    lines appear here)         ||
| Page size &    |  ...                    | |  ... |  |                               ||
|   cutting      |  Pages  [all] [Page]    | +------+  +-------------------------------+|
| Optimise       |         [Picked]        |                                           |
| Convert        |                         |                                           |
| Watermark ...  |        [   Run   ]      |                                           |
| Security ...   |                         |                                           |
+----------------+-------------------------+-------------------------------------------+
| status bar: messages · progress bar · Cancel                                         |
+--------------------------------------------------------------------------------------+
```

1. **Top bar** - open a file, see its name / page count / size, show detailed information, close the file.
2. **Tool list** (left) - all 37 tools in seven groups. Click one to show its options.
3. **Tool options** (middle) - the settings for the selected tool and the **Run** button.
4. **Preview** (right) - thumbnails of every page (left strip) and a large view of the current page.
5. **Status bar** (bottom) - messages, a progress bar while a job runs, and a **Cancel** button.

You can drag the dividers between the three panels to change their widths.

## 2.2 Opening a PDF

Any of these works:

* Click **Open PDF...** (or press `Ctrl+O`) and choose a file.
* **Drag a PDF** from your file manager into the program window.
* Start the program from a terminal with a file name: `python main.py "my file.pdf"`.
* After a tool finishes, click **Continue editing this file** to open the result and keep working on it.

**Password-protected PDFs:** the program asks for the password. If you type it correctly, it is remembered for
this session, so you can use every tool on that file without being asked again. The results are saved
*without* a password unless you use **Password protect**.

The program reads the file into memory and does not keep it open, so you can rename or delete the original file
in your file manager while the program is running. (Files larger than 150 MB are read directly from disk.)

## 2.3 The preview and thumbnails

| Action | How |
|--------|-----|
| Go to the next / previous page | the `>` and `<` buttons, or type a number into the page box |
| Show a page | click its thumbnail |
| Zoom | **+** / **-** buttons, or hold `Ctrl` and turn the mouse wheel; **Fit** shows the whole page |
| Move around a zoomed page | drag it with the mouse, or use the scroll bars |
| Select several pages | click thumbnails with `Ctrl` (add one) or `Shift` (a range) |

The page size in millimetres is shown above the preview.

Thumbnails are drawn in the background, so a large document opens immediately and the thumbnails fill in.

## 2.4 Running a tool - the basic routine

1. **Open a PDF** (except for *Merge* and *Images -> PDF*, which start from a list of files).
2. **Click a tool** in the list.
3. **Set the options.** Most tools have a **Pages** box - see 2.5.
4. Press **Run** (or `Ctrl+Enter`).
5. **Choose where to save.** A save dialog opens with a suggested name such as `report_cropped.pdf` in the same
   folder. For tools that create many files (Split, PDF -> Images, Extract images) you choose a *folder* instead.
6. A progress bar shows the work. When it finishes, a message lists the result and offers:
   * **Open** - open the new file in your normal PDF viewer
   * **Show folder** - open the folder in your file manager
   * **Continue editing this file** - load the result into PDF Toolkit so you can apply another tool

If something is wrong with your settings (for example no pages selected) you get a clear message *before* anything
is written.

### Safety rules the program follows

* **Your original file is never changed.** Every tool writes a *new* file. If you choose the original's own name
  as the destination, the program refuses.
* **Existing files are never overwritten by multi-file tools.** If `report_page_1.pdf` already exists, the new file
  is named `report_page_1 (1).pdf`.
* **A cancelled or failed job leaves no half-written file** (single-file results are written to a temporary file
  first and renamed when complete).
* While a job runs, the whole workspace is locked so nothing can change underneath it. Only **Cancel** stays active.

## 2.5 Choosing pages

Every **Pages** box understands the same short notation. Page numbers start at 1.

| You type | Meaning |
|----------|---------|
| `all` (or leave empty) | every page |
| `5` | page 5 |
| `1-3` | pages 1, 2, 3 |
| `1,4,9` | pages 1, 4 and 9 |
| `2-5, 8, 11-last` | pages 2 to 5, page 8, and page 11 to the end |
| `odd` / `even` | odd pages (1, 3, 5 ...) / even pages (2, 4, 6 ...) |
| `7-` | page 7 to the end |
| `-4` | pages 1 to 4 |
| `last` | the last page |
| `5-1` | pages 5, 4, 3, 2, 1 (a descending range - useful in *Reorder*) |

Two buttons next to the box fill it in for you:

* **Page** - the page currently shown in the preview.
* **Picked** - the thumbnails you selected (`Ctrl` / `Shift` + click). Example: select thumbnails 2, 3 and 5 and
  press *Picked* - the box shows `2-3,5`.

If you type a page that does not exist ("page 40 of a 24-page document") you are told exactly that.

## 2.6 Units

Crop and resize options accept **mm**, **cm**, **in** (inches), **pt** (points; 72 points = 1 inch) and, for
crop, **%** of the page size. Paper sizes available: A0-A6, B4, B5, Letter, Legal, Tabloid, Executive and *Custom*.

## 2.7 Cancelling

Press **Cancel** in the status bar. The job stops at the next page and **nothing is saved**. A few single steps
(for example the final writing of a very large file) cannot be interrupted and finish first.

## 2.8 Document info

**Document info** shows file size, page count, PDF version, whether it is encrypted, the number of bookmarks, links
and annotations, whether it has form fields, every distinct page size, and the title / author / creator / producer.

## 2.9 Keyboard shortcuts

| Keys | Action |
|------|--------|
| `Ctrl+O` | open a PDF |
| `Ctrl+W` | close the file |
| `Ctrl+Enter` | run the selected tool |
| `Ctrl+Q` | quit |
| `Ctrl` + mouse wheel (over the preview) | zoom |

## 2.10 What the program remembers

Only the last folder you used. Nothing else is stored, and nothing is ever sent anywhere - the program has no
network features.
