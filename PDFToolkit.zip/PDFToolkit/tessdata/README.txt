OCR language data (Tesseract, Apache License 2.0)
=================================================
This folder holds the language files used by the "OCR (make scans searchable)" tool.
Included: eng (English), hin (Hindi).

To add more languages download <code>.traineddata files (for example ben, tam, tel, mar, guj, kan, mal, pan, urd, ara, fra, deu ...)
from  https://github.com/tesseract-ocr/tessdata_fast  and copy them into this folder.
Then type the code in the Language box: eng+hin  (several languages joined with +).
