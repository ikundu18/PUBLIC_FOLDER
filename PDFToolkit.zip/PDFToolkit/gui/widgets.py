"""Small reusable widgets used by the tool panels."""
from __future__ import annotations

import os

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (
    QAbstractItemView, QColorDialog, QComboBox, QDoubleSpinBox, QFileDialog,
    QGridLayout, QHBoxLayout, QLineEdit, QListWidget, QListWidgetItem, QPushButton,
    QToolButton, QVBoxLayout, QWidget,
)

from pdfkit import ops


def ranges_text(indices) -> str:
    """[0,1,2,4] -> '1-3,5' (1-based, merged ranges)."""
    idx = sorted(set(indices))
    if not idx:
        return ""
    parts, start, prev = [], idx[0], idx[0]
    for i in idx[1:] + [None]:
        if i is not None and i == prev + 1:
            prev = i
            continue
        parts.append(str(start + 1) if start == prev else f"{start + 1}-{prev + 1}")
        if i is not None:
            start = prev = i
    return ",".join(parts)


class PageField(QWidget):
    """Page-range text box with 'current page' and 'selected thumbnails' buttons."""

    def __init__(self, ctx, default: str = "all", placeholder: str = "all, 1-3,7, odd, even, 5-last"):
        super().__init__()
        self.ctx = ctx
        self.edit = QLineEdit(default)
        self.edit.setPlaceholderText(placeholder)
        self.edit.setToolTip(
            "Pages to use.\n  all          every page\n  1-3,7        pages 1 to 3 and 7\n"
            "  odd / even   odd or even pages\n  5-last       page 5 to the end\n"
            "Buttons: 'Page' = the page shown in the preview, 'Picked' = thumbnails you selected on the left (Ctrl/Shift-click).")
        cur = QToolButton(); cur.setText("Page")
        cur.setToolTip("Use the page shown in the preview")
        cur.clicked.connect(lambda: self.edit.setText(str(ctx.current_page() + 1)))
        sel = QToolButton(); sel.setText("Picked")
        sel.setToolTip("Use the thumbnails selected on the left (Ctrl/Shift-click)")
        sel.clicked.connect(self._from_selection)
        lay = QHBoxLayout(self); lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(self.edit, 1); lay.addWidget(cur); lay.addWidget(sel)

    def _from_selection(self):
        t = ranges_text(self.ctx.selected_pages())
        if t:
            self.edit.setText(t)

    def text(self) -> str:
        return self.edit.text().strip() or "all"

    def setText(self, t: str):
        self.edit.setText(t)


class FileListWidget(QWidget):
    """Re-orderable list of files (merge, images -> PDF)."""
    changed = Signal()

    def __init__(self, title: str, file_filter: str, parent=None):
        super().__init__(parent)
        self.filter = file_filter
        self.title = title
        self.list = QListWidget()
        self.list.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.list.setDragDropMode(QAbstractItemView.InternalMove)
        self.list.setMinimumHeight(150)
        self.list.model().rowsMoved.connect(lambda *a: self.changed.emit())
        btns = QGridLayout()
        for n, (text, fn) in enumerate((("Add…", self.add_dialog), ("Remove", self.remove_selected),
                                        ("Clear", self.clear), ("Up", lambda: self.move(-1)),
                                        ("Down", lambda: self.move(1)), ("Sort A-Z", self.sort))):
            b = QPushButton(text); b.clicked.connect(fn); btns.addWidget(b, n // 3, n % 3)
        lay = QVBoxLayout(self); lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(self.list, 1); lay.addLayout(btns)

    def add_dialog(self):
        start = self.window().last_dir() if hasattr(self.window(), "last_dir") else ""
        files, _ = QFileDialog.getOpenFileNames(self, self.title, start, self.filter)
        if files:
            self.add_files(files)
            if hasattr(self.window(), "remember_dir"):
                self.window().remember_dir(files[0])

    def add_files(self, files):
        have = set(self.paths())
        for f in files:
            if f not in have and os.path.isfile(f):
                it = QListWidgetItem(os.path.basename(f))
                it.setToolTip(f); it.setData(Qt.UserRole, f)
                self.list.addItem(it)
        self.changed.emit()

    def paths(self) -> list[str]:
        return [self.list.item(i).data(Qt.UserRole) for i in range(self.list.count())]

    def remove_selected(self):
        for it in self.list.selectedItems():
            self.list.takeItem(self.list.row(it))
        self.changed.emit()

    def move(self, d):
        rows = sorted((self.list.row(i) for i in self.list.selectedItems()), reverse=d > 0)
        for r in rows:
            nr = r + d
            if 0 <= nr < self.list.count():
                it = self.list.takeItem(r); self.list.insertItem(nr, it); it.setSelected(True)
        self.changed.emit()

    def sort(self):
        items = sorted(self.paths(), key=lambda p: os.path.basename(p).lower())
        self.clear(); self.add_files(items)

    def clear(self):
        self.list.clear(); self.changed.emit()


class SizeChooser(QWidget):
    """Paper preset or custom width x height."""

    def __init__(self, default="A4", allow_custom=True):
        super().__init__()
        self.combo = QComboBox()
        self.combo.setMinimumContentsLength(8)
        self.combo.setSizeAdjustPolicy(QComboBox.AdjustToMinimumContentsLengthWithIcon)
        self.combo.addItems(list(ops.PAGE_SIZES))
        if allow_custom:
            self.combo.addItem("Custom")
        self.combo.setCurrentText(default)
        self.w = QDoubleSpinBox(); self.h = QDoubleSpinBox()
        for s in (self.w, self.h):
            s.setRange(5, 5000); s.setDecimals(1); s.setValue(210 if s is self.w else 297)
        self.unit = QComboBox(); self.unit.addItems(["mm", "cm", "in", "pt"])
        lay = QHBoxLayout(self); lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(self.combo)
        self.times = QLineEditLabel("×")
        lay.addWidget(self.w); lay.addWidget(self.times); lay.addWidget(self.h); lay.addWidget(self.unit)
        self.combo.currentTextChanged.connect(self._sync)
        self._sync()

    def _sync(self):
        custom = self.combo.currentText() == "Custom"
        for wdg in (self.w, self.times, self.h, self.unit):
            wdg.setVisible(custom)

    def value(self):
        """Return (size, unit) suitable for ops.resize_pages."""
        if self.combo.currentText() == "Custom":
            return (self.w.value(), self.h.value()), self.unit.currentText()
        return self.combo.currentText(), "mm"


def QLineEditLabel(text):
    from PySide6.QtWidgets import QLabel
    return QLabel(text)


class ColorButton(QPushButton):
    def __init__(self, color="#c00000"):
        super().__init__()
        self._c = QColor(color)
        self.clicked.connect(self._pick)
        self._paint()

    def _paint(self):
        self.setText(self._c.name())
        self.setStyleSheet(
            f"background:{self._c.name()}; color:{'#000' if self._c.lightness() > 128 else '#fff'};"
            "padding:4px 10px; border:1px solid #888; border-radius:3px;")

    def _pick(self):
        c = QColorDialog.getColor(self._c, self, "Choose colour")
        if c.isValid():
            self._c = c; self._paint()

    def value(self) -> str:
        return self._c.name()


class FilePicker(QWidget):
    """Line edit + Browse button for choosing one input file."""

    def __init__(self, title, file_filter, placeholder=""):
        super().__init__()
        self.title, self.filter = title, file_filter
        self.edit = QLineEdit(); self.edit.setPlaceholderText(placeholder)
        b = QPushButton("Browse…"); b.clicked.connect(self._browse)
        lay = QHBoxLayout(self); lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(self.edit, 1); lay.addWidget(b)

    def _browse(self):
        start = self.window().last_dir() if hasattr(self.window(), "last_dir") else ""
        f, _ = QFileDialog.getOpenFileName(self, self.title, start, self.filter)
        if f:
            self.edit.setText(f)
            if hasattr(self.window(), "remember_dir"):
                self.window().remember_dir(f)

    def value(self) -> str:
        return self.edit.text().strip()
