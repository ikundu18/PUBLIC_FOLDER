"""Page preview with a draggable crop rectangle and cut-line overlay."""
from __future__ import annotations

import pymupdf
from PySide6.QtCore import QItemSelectionModel, QPointF, QRectF, QSize, Qt, QTimer, Signal
from PySide6.QtGui import (
    QBrush, QColor, QCursor, QImage, QPainter, QPainterPath, QPen, QPixmap,
)
from PySide6.QtWidgets import (
    QGraphicsScene, QGraphicsView, QHBoxLayout, QLabel, QListWidget,
    QListWidgetItem, QSpinBox, QToolButton, QVBoxLayout, QWidget, QAbstractItemView,
)

from pdfkit import ops

EDGE = 9  # hit distance in screen pixels


def pix_to_qimage(pix: pymupdf.Pixmap) -> QImage:
    fmt = QImage.Format_RGB888 if pix.n == 3 else QImage.Format_Grayscale8
    return QImage(pix.samples, pix.width, pix.height, pix.stride, fmt).copy()


class PageView(QGraphicsView):
    marginsChanged = Signal(float, float, float, float)  # l, t, r, b fractions
    pageClicked = Signal()

    def __init__(self):
        super().__init__()
        self.setScene(QGraphicsScene(self))
        self.setBackgroundBrush(QColor(90, 94, 100))
        self.setRenderHints(QPainter.Antialiasing | QPainter.SmoothPixmapTransform)
        self.setDragMode(QGraphicsView.ScrollHandDrag)
        self.setMouseTracking(True)
        self.setAlignment(Qt.AlignCenter)
        self.doc: pymupdf.Document | None = None
        self.page_no = 0
        self.zoom = 1.0          # 1.0 = fit page in the viewport
        self.item = None
        self.mode: str | None = None     # None | 'crop' | 'grid'
        self.margins = [0.0, 0.0, 0.0, 0.0]
        self.grid = (2, 1)
        self.rtl = False
        self._drag: str | None = None
        self._timer = QTimer(self, singleShot=True, interval=120)
        self._timer.timeout.connect(self._render)
        self._msg = "Open a PDF to start\n(or drop one here)"

    # ------------------------------------------------------------ document
    def set_document(self, doc: pymupdf.Document | None):
        self.doc = doc
        self.page_no = 0
        self.zoom = 1.0
        self._render()

    def show_page(self, n: int):
        if self.doc and 0 <= n < self.doc.page_count and n != self.page_no:
            self.page_no = n
            self._render()

    def refresh(self):
        self._render()

    def _fit_scale(self, page: pymupdf.Rect) -> float:
        vp = self.viewport().size()
        return max(0.05, min((vp.width() - 24) / page.width, (vp.height() - 24) / page.height))

    def _render(self):
        sc = self.scene()
        sc.clear(); self.item = None
        if not self.doc or self.doc.page_count == 0:
            sc.setSceneRect(QRectF(0, 0, 10, 10))
            return
        page = self.doc[self.page_no]
        dpr = self.devicePixelRatioF()
        z = self._fit_scale(page.rect) * self.zoom
        pix = page.get_pixmap(matrix=pymupdf.Matrix(z * dpr, z * dpr), alpha=False)
        qp = QPixmap.fromImage(pix_to_qimage(pix))
        qp.setDevicePixelRatio(dpr)
        self.item = sc.addPixmap(qp)
        self.item.setTransformationMode(Qt.SmoothTransformation)
        r = QRectF(0, 0, qp.width() / dpr, qp.height() / dpr)
        pad = 12
        sc.setSceneRect(r.adjusted(-pad, -pad, pad, pad))
        self.viewport().update()

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self._timer.start()

    def wheelEvent(self, e):
        if e.modifiers() & Qt.ControlModifier:
            self.zoom = max(0.2, min(8.0, self.zoom * (1.15 if e.angleDelta().y() > 0 else 1 / 1.15)))
            self._timer.start()
            e.accept()
        else:
            super().wheelEvent(e)

    def zoom_by(self, f: float):
        self.zoom = max(0.2, min(8.0, self.zoom * f)); self._render()

    def zoom_fit(self):
        self.zoom = 1.0; self._render()

    # ------------------------------------------------------------- overlays
    def set_mode(self, mode: str | None):
        self.mode = mode
        self.viewport().update()

    def set_margins(self, l, t, r, b):
        self.margins = [max(0.0, min(0.95, v)) for v in (l, t, r, b)]
        self.viewport().update()

    def set_grid(self, cols: int, rows: int, rtl: bool = False):
        self.grid = (max(1, cols), max(1, rows)); self.rtl = rtl
        self.viewport().update()

    def _page_rect(self) -> QRectF:
        return self.item.sceneBoundingRect() if self.item else QRectF()

    def _crop_rect(self) -> QRectF:
        r = self._page_rect()
        l, t, rr, b = self.margins
        return QRectF(r.left() + l * r.width(), r.top() + t * r.height(),
                      r.width() * (1 - l - rr), r.height() * (1 - t - b))

    def drawForeground(self, p: QPainter, rect: QRectF):
        pr = self._page_rect()
        if pr.isEmpty():
            return
        if self.mode == "crop":
            cr = self._crop_rect()
            path = QPainterPath(); path.addRect(pr)
            hole = QPainterPath(); hole.addRect(cr)
            p.fillPath(path.subtracted(hole), QColor(0, 0, 0, 120))
            pen = QPen(QColor("#ff9f1c"), 1.6); pen.setCosmetic(True)
            p.setPen(pen); p.setBrush(Qt.NoBrush); p.drawRect(cr)
            p.setBrush(QBrush(QColor("#ff9f1c")))
            s = 4 / max(self.transform().m11(), 0.01)
            for pt in (cr.topLeft(), cr.topRight(), cr.bottomLeft(), cr.bottomRight(),
                       QPointF(cr.center().x(), cr.top()), QPointF(cr.center().x(), cr.bottom()),
                       QPointF(cr.left(), cr.center().y()), QPointF(cr.right(), cr.center().y())):
                p.drawRect(QRectF(pt.x() - s, pt.y() - s, 2 * s, 2 * s))
        elif self.mode == "grid":
            cols, rows = self.grid
            pen = QPen(QColor("#e63946"), 1.6, Qt.DashLine); pen.setCosmetic(True)
            p.setPen(pen)
            for c in range(1, cols):
                x = pr.left() + pr.width() * c / cols
                p.drawLine(QPointF(x, pr.top()), QPointF(x, pr.bottom()))
            for r in range(1, rows):
                y = pr.top() + pr.height() * r / rows
                p.drawLine(QPointF(pr.left(), y), QPointF(pr.right(), y))
            f = p.font(); f.setBold(True); f.setPointSizeF(max(10, min(pr.width() / cols, pr.height() / rows) / 5))
            p.setFont(f)
            p.setPen(QColor("#e63946"))
            k = 1
            for r in range(rows):
                order = range(cols - 1, -1, -1) if self.rtl else range(cols)
                for c in order:
                    cell = QRectF(pr.left() + pr.width() * c / cols, pr.top() + pr.height() * r / rows,
                                  pr.width() / cols, pr.height() / rows)
                    p.drawText(cell, Qt.AlignCenter, str(k)); k += 1

    # ----------------------------------------------------------- crop mouse
    def _hit(self, pos: QPointF) -> str | None:
        if self.mode != "crop" or not self.item:
            return None
        cr = self._crop_rect()
        tol = EDGE / max(self.transform().m11(), 0.01)
        near = lambda a, b: abs(a - b) <= tol
        inx = cr.left() - tol <= pos.x() <= cr.right() + tol
        iny = cr.top() - tol <= pos.y() <= cr.bottom() + tol
        h = ("l" if near(pos.x(), cr.left()) and iny else
             "r" if near(pos.x(), cr.right()) and iny else "")
        v = ("t" if near(pos.y(), cr.top()) and inx else
             "b" if near(pos.y(), cr.bottom()) and inx else "")
        return (v + h) or None

    def mousePressEvent(self, e):
        hit = self._hit(self.mapToScene(e.position().toPoint()))
        if hit and e.button() == Qt.LeftButton:
            self._drag = hit
            self.setDragMode(QGraphicsView.NoDrag)
            e.accept()
            return
        super().mousePressEvent(e)

    def mouseMoveEvent(self, e):
        pos = self.mapToScene(e.position().toPoint())
        if self._drag:
            pr = self._page_rect()
            fx = (pos.x() - pr.left()) / pr.width()
            fy = (pos.y() - pr.top()) / pr.height()
            l, t, r, b = self.margins
            if "l" in self._drag:
                l = max(0.0, min(fx, 1 - r - 0.05))
            if "r" in self._drag:
                r = max(0.0, min(1 - fx, 1 - l - 0.05))
            if "t" in self._drag:
                t = max(0.0, min(fy, 1 - b - 0.05))
            if "b" in self._drag:
                b = max(0.0, min(1 - fy, 1 - t - 0.05))
            self.margins = [l, t, r, b]
            self.viewport().update()
            self.marginsChanged.emit(l, t, r, b)
            e.accept()
            return
        hit = self._hit(pos)
        cur = {"l": Qt.SizeHorCursor, "r": Qt.SizeHorCursor, "t": Qt.SizeVerCursor,
               "b": Qt.SizeVerCursor, "tl": Qt.SizeFDiagCursor, "br": Qt.SizeFDiagCursor,
               "tr": Qt.SizeBDiagCursor, "bl": Qt.SizeBDiagCursor}.get(hit or "")
        if cur:
            self.viewport().setCursor(cur)
        else:
            self.viewport().unsetCursor()
        super().mouseMoveEvent(e)

    def mouseReleaseEvent(self, e):
        if self._drag:
            self._drag = None
            self.setDragMode(QGraphicsView.ScrollHandDrag)
            e.accept()
            return
        super().mouseReleaseEvent(e)

    def paintEvent(self, e):
        super().paintEvent(e)
        if not self.doc:
            p = QPainter(self.viewport())
            p.setPen(QColor(220, 224, 230))
            f = p.font(); f.setPointSize(13); p.setFont(f)
            p.drawText(self.viewport().rect(), Qt.AlignCenter, self._msg)


class Thumbnails(QListWidget):
    """Lazy-loaded page thumbnails; multi-select feeds the page fields."""
    THUMB_W = 84

    def __init__(self):
        super().__init__()
        self.setViewMode(QListWidget.ListMode)
        self.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.setUniformItemSizes(True)
        self.setMovement(QListWidget.Static)
        self.setFixedWidth(self.THUMB_W + 44)
        self.doc = None
        self._next = 0
        self._timer = QTimer(self, interval=8)
        self._timer.timeout.connect(self._more)

    def set_document(self, doc):
        self._timer.stop()
        self.clear()
        self.doc = doc
        self._next = 0
        if not doc:
            return
        pg = doc[0].rect
        h = int(self.THUMB_W * pg.height / pg.width) if pg.width else 110
        self.setIconSize(QSize(self.THUMB_W, min(max(h, 40), 160)))
        blank = QPixmap(self.iconSize()); blank.fill(QColor(235, 235, 235))
        for i in range(doc.page_count):
            it = QListWidgetItem(str(i + 1))
            it.setTextAlignment(Qt.AlignHCenter)
            it.setIcon(blank)
            self.addItem(it)
        self._timer.start()

    def _more(self):
        if not self.doc or self._next >= self.doc.page_count:
            self._timer.stop()
            return
        for _ in range(3):
            if self._next >= self.doc.page_count:
                break
            page = self.doc[self._next]
            z = self.THUMB_W / page.rect.width
            pix = page.get_pixmap(matrix=pymupdf.Matrix(z, z), alpha=False)
            self.item(self._next).setIcon(QPixmap.fromImage(pix_to_qimage(pix)))
            self._next += 1

    def selected_pages(self) -> list[int]:
        return sorted(self.row(i) for i in self.selectedItems())


class PreviewPane(QWidget):
    """Thumbnails + page view + navigation bar."""
    pageChanged = Signal(int)

    def __init__(self):
        super().__init__()
        self.view = PageView()
        self.thumbs = Thumbnails()
        bar = QHBoxLayout()
        self.prev = QToolButton(); self.prev.setText("◀")
        self.next = QToolButton(); self.next.setText("▶")
        self.spin = QSpinBox(); self.spin.setRange(1, 1)
        self.total = QLabel("/ 0")
        zi = QToolButton(); zi.setText("＋"); zo = QToolButton(); zo.setText("－")
        fit = QToolButton(); fit.setText("Fit")
        self.size_label = QLabel("")
        for w in (self.prev, self.spin, self.total, self.next):
            bar.addWidget(w)
        bar.addStretch(1)
        bar.addWidget(self.size_label)
        for w in (zo, fit, zi):
            bar.addWidget(w)
        main = QHBoxLayout(); main.setContentsMargins(0, 0, 0, 0)
        main.addWidget(self.thumbs); main.addWidget(self.view, 1)
        lay = QVBoxLayout(self); lay.setContentsMargins(0, 0, 0, 0)
        lay.addLayout(bar); lay.addLayout(main, 1)
        self.prev.clicked.connect(lambda: self.goto(self.view.page_no - 1))
        self.next.clicked.connect(lambda: self.goto(self.view.page_no + 1))
        self.spin.editingFinished.connect(lambda: self.goto(self.spin.value() - 1))
        zi.clicked.connect(lambda: self.view.zoom_by(1.25))
        zo.clicked.connect(lambda: self.view.zoom_by(0.8))
        fit.clicked.connect(self.view.zoom_fit)
        self.thumbs.currentRowChanged.connect(lambda r: r >= 0 and self.goto(r, from_thumbs=True))

    def set_document(self, doc):
        self.view.set_document(doc)
        self.thumbs.set_document(doc)
        n = doc.page_count if doc else 0
        self.spin.setRange(1, max(n, 1)); self.spin.setValue(1)
        self.total.setText(f"/ {n}")
        self._update_size()
        if n:
            self.thumbs.setCurrentRow(0, QItemSelectionModel.NoUpdate)

    def goto(self, n: int, from_thumbs: bool = False):
        d = self.view.doc
        if not d or not 0 <= n < d.page_count:
            return
        self.view.show_page(n)
        self.spin.setValue(n + 1)
        if not from_thumbs and self.thumbs.currentRow() != n:
            self.thumbs.blockSignals(True)
            self.thumbs.setCurrentRow(n, QItemSelectionModel.NoUpdate)
            self.thumbs.scrollToItem(self.thumbs.item(n))
            self.thumbs.blockSignals(False)
        self._update_size()
        self.pageChanged.emit(n)

    def _update_size(self):
        d = self.view.doc
        if d and d.page_count:
            r = d[self.view.page_no].rect
            self.size_label.setText(
                f"{r.width / ops.MM:.0f} × {r.height / ops.MM:.0f} mm  ")
        else:
            self.size_label.setText("")
