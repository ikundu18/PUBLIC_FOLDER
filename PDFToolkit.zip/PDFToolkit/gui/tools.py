"""One panel per tool. Each panel collects options from its widgets and calls
the matching function in pdfkit.ops (see ToolPanel.execute)."""
from __future__ import annotations

import os
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QDoubleSpinBox, QFormLayout, QHBoxLayout, QLabel,
    QLineEdit, QPlainTextEdit, QPushButton, QSizePolicy, QSlider, QSpinBox, QVBoxLayout, QWidget,
)

from pdfkit import advanced, ops
from .widgets import (
    ColorButton, FileListWidget, FilePicker, PageField, SizeChooser,
)

PDF_FILTER = "PDF files (*.pdf)"
IMG_FILTER = "Images (*.png *.jpg *.jpeg *.webp *.bmp *.tif *.tiff *.gif)"


class _FrozenPanel:
    """Plain attribute bag standing in for a panel inside the worker."""


def _free(path: Path) -> Path:
    if not path.exists():
        return path
    i = 1
    while True:
        c = path.with_name(f"{path.stem} ({i}){path.suffix}")
        if not c.exists():
            return c
        i += 1


class ToolPanel(QWidget):
    """Base class. Subclasses fill ``self.form`` and implement ``execute``."""
    key = ""
    title = ""
    group = ""
    blurb = ""
    needs_pdf = True
    output = "pdf"          # "pdf" | "folder" | "text"
    suffix = "_edited"
    overlay: str | None = None

    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        self.form = QFormLayout()
        self.form.setFieldGrowthPolicy(QFormLayout.ExpandingFieldsGrow)
        self.form.setLabelAlignment(Qt.AlignRight)
        lay = QVBoxLayout(self)
        self.note = QLabel(self.blurb)
        self.note.setWordWrap(True)
        self.note.setStyleSheet("color: palette(placeholder-text);")
        lay.addWidget(self.note)
        lay.addLayout(self.form)
        lay.addStretch(1)
        self.build()

    def freeze(self):
        """Copy every option widget's value (GUI thread). Returns an object
        that behaves like this panel for ``execute`` but holds no Qt widgets."""
        snap = _FrozenPanel()
        for name, val in list(self.__dict__.items()):
            if name in ("ctx", "form", "note"):
                continue
            setattr(snap, name, _freeze_value(val))
        return snap

    def make_job(self, src, out):
        """Return ``job(progress) -> message`` safe to run in a worker thread."""
        snap = self.freeze()
        cls = type(self)
        return lambda progress: cls.execute(snap, src, out, progress)

    # --- to override -----------------------------------------------------
    def build(self): ...
    def validate(self) -> str | None: return None
    def execute(self, src, out, progress) -> str: raise NotImplementedError
    def on_activate(self): ...
    def on_page_changed(self, n: int): ...
    def on_document_changed(self): ...

    # --- helpers -----------------------------------------------------------
    def add(self, label: str, widget):
        if isinstance(widget, QComboBox):
            compact_combo(widget)
        self.form.addRow(label, widget)
        return widget

    def pages_field(self, default="all", label="Pages") -> PageField:
        pf = PageField(self.ctx, default)
        self.form.addRow(label, pf)
        return pf

    def suggest(self, src) -> str:
        """Suggested output path (file) or folder for the save dialog."""
        p = Path(src) if src else Path.home() / "output.pdf"
        if self.output == "folder":
            return str(p.parent)
        ext = ".txt" if self.output == "text" else ".pdf"
        return str(_free(p.with_name(p.stem + self.suffix + ext)))


class Frozen:
    """Read-only copy of a widget's current value(s). The worker thread must
    never touch Qt widgets, so every option is copied on the GUI thread
    first (see ToolPanel.freeze) and ``execute`` reads these copies."""

    _GETTERS = ("text", "value", "isChecked", "currentText", "currentData", "paths", "toPlainText")

    def __init__(self, widget):
        self._vals = {}
        for name in self._GETTERS:
            fn = getattr(widget, name, None)
            if callable(fn):
                try:
                    self._vals[name] = fn()
                except TypeError:
                    pass
        # composite widgets expose their parts (SizeChooser.combo, FilePicker.edit ...)
        for part in ("combo", "w", "h", "unit", "edit"):
            sub = getattr(widget, part, None)
            if isinstance(sub, QWidget):
                setattr(self, part, Frozen(sub))

    def __getattr__(self, name):
        try:
            vals = object.__getattribute__(self, "_vals")
            val = vals[name]
        except KeyError:
            raise AttributeError(name) from None
        return lambda: val


def _freeze_value(v):
    if isinstance(v, QWidget):
        return Frozen(v)
    if isinstance(v, (list, tuple)):
        return type(v)(_freeze_value(x) for x in v)
    if isinstance(v, dict):
        return {k: _freeze_value(x) for k, x in v.items()}
    return v


def compact_combo(box: QComboBox) -> None:
    """Long item texts must not force the panel wider than its pane."""
    box.setSizeAdjustPolicy(QComboBox.AdjustToMinimumContentsLengthWithIcon)
    box.setMinimumContentsLength(14)
    box.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)


def spin(lo, hi, val, step=1, decimals=None, suffix=""):
    s = QDoubleSpinBox() if decimals is not None else QSpinBox()
    if decimals is not None:
        s.setDecimals(decimals)
    s.setRange(lo, hi); s.setValue(val); s.setSingleStep(step)
    if suffix:
        s.setSuffix(suffix)
    return s


# ======================================================================
# Organise
# ======================================================================
class MergePanel(ToolPanel):
    key, title, group = "merge", "Merge PDFs", "Organise"
    blurb = "Combine several PDFs into one. Drag items to reorder."
    needs_pdf = False
    suffix = "_merged"

    def build(self):
        self.files = FileListWidget("Choose PDFs to merge", PDF_FILTER)
        self.form.addRow(self.files)
        add_cur = QPushButton("Add the open PDF")
        add_cur.clicked.connect(lambda: self.ctx.path and self.files.add_files([self.ctx.path]))
        self.form.addRow(add_cur)
        self.bookmarks = QCheckBox("Add a bookmark for each file")
        self.bookmarks.setChecked(True)
        self.form.addRow(self.bookmarks)

    def validate(self):
        paths = self.files.paths()
        if len(paths) < 2:
            return "Add at least two PDFs to merge."
        for p in paths:          # GUI thread: ask for passwords before the worker starts
            if ops.needs_password(p) and not self.ctx.ask_password(p):
                return f"Password needed for {os.path.basename(p)}."
        return None

    def suggest(self, src):
        paths = self.files.paths()
        d = Path(paths[0]).parent if paths else Path.home()
        return str(_free(d / "merged.pdf"))

    def execute(self, src, out, progress):
        ops.merge_pdfs(self.files.paths(), out, self.bookmarks.isChecked(), progress)
        return f"Merged {len(self.files.paths())} files."


class SplitPanel(ToolPanel):
    key, title, group = "split", "Split PDF", "Organise"
    blurb = "Break one PDF into several files. Files are written into the folder you choose; existing files are never overwritten."
    output = "folder"

    def build(self):
        self.mode = self.add("Split by", QComboBox())
        for label, key in (("Every page (one file per page)", "each"),
                           ("Every N pages", "every"),
                           ("Number of equal parts", "parts"),
                           ("Custom page ranges", "ranges"),
                           ("Top-level bookmarks / chapters", "bookmarks")):
            self.mode.addItem(label, key)
        self.n = self.add("Pages per file", spin(1, 9999, 2))
        self.parts = self.add("Number of parts", spin(1, 999, 2))
        self.ranges = self.add("Ranges", QLineEdit())
        self.ranges.setPlaceholderText("1-3, 4-7, 9, 10-last   (each item = one file)")
        self.mode.currentIndexChanged.connect(self._sync)
        self._sync()

    def _sync(self):
        m = self.mode.currentData()
        for w, on in ((self.n, m == "every"), (self.parts, m == "parts"), (self.ranges, m == "ranges")):
            w.setVisible(on)
            self.form.labelForField(w).setVisible(on)

    def validate(self):
        if self.mode.currentData() == "ranges" and not self.ranges.text().strip():
            return "Enter the page ranges, e.g. 1-3, 4-7, 9"

    def execute(self, src, out, progress):
        files = ops.split_pdf(src, out, self.mode.currentData(), self.n.value(),
                              self.ranges.text(), self.parts.value(), progress)
        return f"Created {len(files)} files."


class ExtractPanel(ToolPanel):
    key, title, group = "extract", "Extract pages", "Organise"
    blurb = "Save the chosen pages as a new PDF."
    suffix = "_extracted"

    def build(self):
        self.pages = self.pages_field("1")

    def execute(self, src, out, progress):
        ops.extract_pages(src, out, self.pages.text(), progress)
        return "Pages extracted."


class DeletePanel(ToolPanel):
    key, title, group = "delete", "Delete pages", "Organise"
    blurb = "Remove the chosen pages and save the rest as a new PDF."
    suffix = "_trimmed"

    def build(self):
        self.pages = self.pages_field("1")

    def execute(self, src, out, progress):
        ops.delete_pages(src, out, self.pages.text(), progress)
        return "Pages deleted."


class ReorderPanel(ToolPanel):
    key, title, group = "reorder", "Reorder / reverse", "Organise"
    blurb = ("Type the new page order, e.g. 3,1,2 or 5-8,1-4. Pages you leave out are dropped, "
             "pages you repeat are duplicated. 'last-1' reverses the whole document.")
    suffix = "_reordered"

    def build(self):
        self.order = self.add("New order", QLineEdit())
        b = QHBoxLayout()
        rev = QPushButton("Reverse all pages"); rev.clicked.connect(lambda: self.order.setText("last-1"))
        cur = QPushButton("Fill current order"); cur.clicked.connect(self._fill)
        b.addWidget(rev); b.addWidget(cur)
        self.form.addRow(b)

    def _fill(self):
        n = self.ctx.page_count()
        if n:
            self.order.setText(f"1-{n}")

    def validate(self):
        if not self.order.text().strip():
            return "Type the new page order, e.g. 3,1,2"

    def execute(self, src, out, progress):
        ops.reorder_pages(src, out, self.order.text(), progress)
        return "Pages reordered."


class DuplicatePanel(ToolPanel):
    key, title, group = "duplicate", "Duplicate pages", "Organise"
    blurb = "Repeat chosen pages right after themselves."
    suffix = "_duplicated"

    def build(self):
        self.pages = self.pages_field("1")
        self.copies = self.add("Extra copies", spin(1, 99, 1))

    def execute(self, src, out, progress):
        ops.duplicate_pages(src, out, self.pages.text(), self.copies.value(), progress)
        return "Pages duplicated."


class BlankPanel(ToolPanel):
    key, title, group = "blank", "Insert blank pages", "Organise"
    blurb = "Insert blank pages after the listed pages. Use 0 to insert at the very beginning, 'all' after every page."
    suffix = "_with_blanks"

    def build(self):
        self.after = self.add("After page(s)", QLineEdit("1"))
        self.count = self.add("Blank pages", spin(1, 50, 1))

    def validate(self):
        if not self.after.text().strip():
            return "Say after which page(s) to insert."

    def execute(self, src, out, progress):
        ops.insert_blank_pages(src, out, self.after.text(), self.count.value(), progress)
        return "Blank pages inserted."


class RotatePanel(ToolPanel):
    key, title, group = "rotate", "Rotate pages", "Organise"
    blurb = "Turn pages clockwise or counter-clockwise."
    suffix = "_rotated"

    def build(self):
        self.pages = self.pages_field()
        self.angle = self.add("Rotation", QComboBox())
        for label, v in (("90° clockwise", 90), ("180°", 180), ("90° counter-clockwise", -90)):
            self.angle.addItem(label, v)

    def execute(self, src, out, progress):
        ops.rotate_pages(src, out, self.pages.text(), self.angle.currentData(), progress)
        return "Pages rotated."


# ======================================================================
# Edit page size
# ======================================================================
class CropPanel(ToolPanel):
    key, title, group = "crop", "Crop margins", "Page size & cutting"
    blurb = ("Remove margins from pages. Drag the orange edges in the preview or type values. "
             "The same margins are applied to every selected page. "
             "(Cropped-away content stays hidden inside the file; use Rasterize to remove it for good.)")
    suffix = "_cropped"
    overlay = "crop"

    def build(self):
        self.fr = [0.0, 0.0, 0.0, 0.0]      # l, t, r, b as fractions of the current page
        self.unit = self.add("Units", QComboBox())
        self.unit.addItems(["mm", "cm", "in", "pt", "%"])
        self.spins = []
        grid = QFormLayout()
        for name in ("Left", "Top", "Right", "Bottom"):
            s = spin(0, 5000, 0, 1, 2)
            s.valueChanged.connect(self._from_spins)
            self.spins.append(s)
            grid.addRow(name, s)
        w = QWidget(); w.setLayout(grid); grid.setContentsMargins(0, 0, 0, 0)
        self.form.addRow("Margins to remove", w)
        self.auto = self.add("", QCheckBox("Auto-crop white borders"))
        self.pad = self.add("Keep padding (pt)", spin(0, 200, 5))
        self.pages = self.pages_field()
        r = QPushButton("Reset margins"); r.clicked.connect(self.reset)
        self.form.addRow(r)
        self.unit.currentTextChanged.connect(lambda _: self._to_spins())
        self.ctx.preview.view.marginsChanged.connect(self._from_view)

    # unit conversion helpers -------------------------------------------
    def _page_pts(self):
        return self.ctx.page_size_pts()

    def _from_spins(self):
        pw, ph = self._page_pts()
        if not pw:
            return
        u = self.unit.currentText()
        v = [s.value() for s in self.spins]
        if u == "%":
            fr = [v[0] / 100, v[1] / 100, v[2] / 100, v[3] / 100]
        else:
            pts = [ops.to_points(x, u) for x in v]
            fr = [pts[0] / pw, pts[1] / ph, pts[2] / pw, pts[3] / ph]
        self.fr = fr
        self.ctx.preview.view.set_margins(*fr)

    def _to_spins(self):
        pw, ph = self._page_pts()
        if not pw:
            return
        u = self.unit.currentText()
        dims = (pw, ph, pw, ph)
        for s, f, d in zip(self.spins, self.fr, dims):
            s.blockSignals(True)
            s.setValue(f * 100 if u == "%" else ops.from_points(f * d, u))
            s.blockSignals(False)

    def _from_view(self, l, t, r, b):
        if self.isVisible():
            self.fr = [l, t, r, b]
            self._to_spins()

    def reset(self):
        for s in self.spins:
            s.blockSignals(True); s.setValue(0); s.blockSignals(False)
        self._from_spins()

    def on_activate(self):
        self._from_spins()

    def on_page_changed(self, n):
        self._from_spins()      # keep absolute margins when page size differs

    def on_document_changed(self):
        self._from_spins()

    def validate(self):
        if not self.auto.isChecked() and not any(s.value() for s in self.spins):
            return "Set at least one margin (drag the orange edges in the preview), or choose auto-crop."

    def execute(self, src, out, progress):
        ops.crop_pages(src, out, self.pages.text(), tuple(s.value() for s in self.spins),
                       self.unit.currentText(), self.auto.isChecked(), self.pad.value(), progress)
        return "Pages cropped."


class CutPanel(ToolPanel):
    key, title, group = "cut", "Cut pages into pieces", "Page size & cutting"
    blurb = ("Cut every selected page into a grid of new pages - e.g. split a scanned two-page "
             "spread into two pages, or cut a poster into quarters. Red lines in the preview show the cuts.")
    suffix = "_cut"
    overlay = "grid"

    def build(self):
        self.cols = self.add("Columns", spin(1, 10, 2))
        self.rows = self.add("Rows", spin(1, 10, 1))
        self.rtl = self.add("", QCheckBox("Right-to-left order (manga, Arabic)"))
        row = QHBoxLayout()
        for label, c, r in (("2 side by side", 2, 1), ("2 top / bottom", 1, 2), ("4 quarters", 2, 2)):
            b = QPushButton(label)
            b.clicked.connect(lambda _=False, c=c, r=r: (self.cols.setValue(c), self.rows.setValue(r)))
            row.addWidget(b)
        self.form.addRow(row)
        self.pages = self.pages_field()
        for w in (self.cols, self.rows):
            w.valueChanged.connect(self._sync)
        self.rtl.toggled.connect(self._sync)

    def _sync(self):
        self.ctx.preview.view.set_grid(self.cols.value(), self.rows.value(), self.rtl.isChecked())

    def on_activate(self):
        self._sync()

    def validate(self):
        if self.cols.value() * self.rows.value() < 2:
            return "Choose at least 2 pieces (columns × rows)."

    def execute(self, src, out, progress):
        ops.cut_pages(src, out, self.pages.text(), self.cols.value(), self.rows.value(),
                      self.rtl.isChecked(), progress)
        return "Pages cut."


class ResizePanel(ToolPanel):
    key, title, group = "resize", "Resize page size", "Page size & cutting"
    blurb = "Change the paper size (e.g. Letter → A4). Content is scaled to fit."
    suffix = "_resized"

    def build(self):
        self.size_box = self.add("New size", SizeChooser("A4"))
        self.mode = self.add("Content", QComboBox())
        for label, k in (("Fit - keep proportions, whole page visible", "fit"),
                         ("Fill - cover the page, crop the overflow", "fill"),
                         ("Stretch - ignore proportions", "stretch")):
            self.mode.addItem(label, k)
        self.margin = self.add("Margin (mm)", spin(0, 100, 0, 1, 1))
        self.orient = self.add("", QCheckBox("Keep landscape pages landscape"))
        self.orient.setChecked(True)
        self.pages = self.pages_field()

    def execute(self, src, out, progress):
        size, unit = self.size_box.value()
        ops.resize_pages(src, out, self.pages.text(), size, unit, self.mode.currentData(),
                         self.margin.value() if unit == "mm" else ops.from_points(
                             ops.to_points(self.margin.value(), "mm"), unit),
                         self.orient.isChecked(), progress)
        return "Pages resized."


class ScalePanel(ToolPanel):
    key, title, group = "scale", "Scale pages (%)", "Page size & cutting"
    blurb = "Make pages bigger or smaller by a percentage (page and content together)."
    suffix = "_scaled"

    def build(self):
        self.pct = self.add("Scale", spin(5, 1000, 50, 5, 0, " %"))
        self.pages = self.pages_field()

    def execute(self, src, out, progress):
        ops.scale_pages(src, out, self.pages.text(), self.pct.value(), progress)
        return "Pages scaled."


class NUpPanel(ToolPanel):
    key, title, group = "nup", "Multiple pages per sheet", "Page size & cutting"
    blurb = "Print several pages on one sheet (handouts, 2-up, 4-up ...)."
    suffix = "_nup"

    def build(self):
        self.layout_box = self.add("Layout", QComboBox())
        for label, c, r in (("2 per sheet (2×1)", 2, 1), ("4 per sheet (2×2)", 2, 2),
                            ("6 per sheet (3×2)", 3, 2), ("9 per sheet (3×3)", 3, 3),
                            ("2 stacked (1×2)", 1, 2), ("Custom", 0, 0)):
            self.layout_box.addItem(label, (c, r))
        self.cols = self.add("Columns", spin(1, 10, 2))
        self.rows = self.add("Rows", spin(1, 10, 2))
        self.paper = self.add("Sheet size", QComboBox())
        self.paper.addItems(list(ops.PAGE_SIZES)); self.paper.setCurrentText("A4")
        self.margin = self.add("Margin (mm)", spin(0, 50, 8, 1, 1))
        self.gap = self.add("Gap (mm)", spin(0, 50, 4, 1, 1))
        self.border = self.add("", QCheckBox("Draw a border around each page"))
        self.layout_box.currentIndexChanged.connect(self._sync)
        self._sync()

    def _sync(self):
        c, r = self.layout_box.currentData()
        custom = c == 0
        for w in (self.cols, self.rows):
            w.setVisible(custom); self.form.labelForField(w).setVisible(custom)

    def execute(self, src, out, progress):
        c, r = self.layout_box.currentData()
        if c == 0:
            c, r = self.cols.value(), self.rows.value()
        ops.n_up(src, out, c, r, self.paper.currentText(), None, self.margin.value(),
                 self.gap.value(), self.border.isChecked(), False, progress)
        return "Done."


# ======================================================================
# Optimise
# ======================================================================
class CompressPanel(ToolPanel):
    key, title, group = "compress", "Compress / reduce size", "Optimise"
    blurb = "Make the file smaller. Higher levels reduce image quality. If the result would not be smaller, the original is kept."
    suffix = "_compressed"

    def build(self):
        self.level = self.add("Level", QComboBox())
        for label, k in (("Light - lossless clean-up only", "light"),
                         ("Medium - good quality (recommended)", "medium"),
                         ("High - smaller, noticeable loss", "high"),
                         ("Extreme - smallest, low quality", "extreme")):
            self.level.addItem(label, k)
        self.level.setCurrentIndex(1)
        self.custom = self.add("", QCheckBox("Custom image settings"))
        self.dpi = self.add("Image DPI", spin(30, 600, 110))
        self.quality = self.add("JPEG quality", spin(10, 95, 60))
        self.custom.toggled.connect(self._sync)
        self._sync()

    def _sync(self):
        on = self.custom.isChecked()
        for w in (self.dpi, self.quality):
            w.setEnabled(on)

    def execute(self, src, out, progress):
        on = self.custom.isChecked()
        r = ops.compress_pdf(src, out, self.level.currentData(),
                             self.dpi.value() if on else None,
                             self.quality.value() if on else None, progress)
        b, a = r["before"], r["after"]
        msg = f"{ops.human_size(b)} → {ops.human_size(a)}  ({(1 - a / b) * 100:.0f}% smaller)" if b else ""
        if r["kept_original"]:
            msg = "The file could not be made smaller, so a copy of the original was saved."
        return msg


class RasterizePanel(ToolPanel):
    key, title, group = "raster", "Rasterize (pages → pictures)", "Optimise"
    blurb = ("Redraw pages as pictures. Permanently removes hidden or cropped-away content and "
             "text (text is no longer selectable). Can convert to grayscale.")
    suffix = "_rasterized"

    def build(self):
        self.dpi = self.add("Resolution (DPI)", spin(36, 600, 150))
        self.quality = self.add("JPEG quality", spin(10, 100, 85))
        self.gray = self.add("", QCheckBox("Convert to grayscale"))
        self.pages = self.pages_field()

    def execute(self, src, out, progress):
        ops.rasterize_pdf(src, out, self.dpi.value(), self.gray.isChecked(),
                          self.quality.value(), self.pages.text(), progress)
        return "Done."


# ======================================================================
# Convert
# ======================================================================
class ToImagesPanel(ToolPanel):
    key, title, group = "toimg", "PDF → Images", "Convert"
    blurb = "Save pages as image files (one per page) in the folder you choose."
    output = "folder"

    def build(self):
        self.fmt = self.add("Format", QComboBox()); self.fmt.addItems(["png", "jpg", "webp", "tiff", "bmp"])
        self.dpi = self.add("Resolution (DPI)", spin(10, 1200, 150))
        self.quality = self.add("Quality (jpg/webp)", spin(10, 100, 90))
        self.pages = self.pages_field()

    def execute(self, src, out, progress):
        f = ops.pdf_to_images(src, out, self.fmt.currentText(), self.dpi.value(),
                              self.pages.text(), self.quality.value(), progress)
        return f"Saved {len(f)} images."


class FromImagesPanel(ToolPanel):
    key, title, group = "fromimg", "Images → PDF", "Convert"
    blurb = "Build a PDF with one image per page. Drag to reorder."
    needs_pdf = False

    def build(self):
        self.files = FileListWidget("Choose images", IMG_FILTER)
        self.form.addRow(self.files)
        self.paper_box = self.add("Page size", QComboBox())
        self.paper_box.addItem("Same as image", "image")
        for k in ops.PAGE_SIZES:
            self.paper_box.addItem(k, k)
        self.dpi = self.add("Image DPI", spin(36, 1200, 150))
        self.margin = self.add("Margin (mm)", spin(0, 100, 0, 1, 1))

    def validate(self):
        return None if self.files.paths() else "Add at least one image."

    def suggest(self, src):
        p = self.files.paths()
        d = Path(p[0]).parent if p else Path.home()
        return str(_free(d / "images.pdf"))

    def execute(self, src, out, progress):
        ops.images_to_pdf(self.files.paths(), out, self.paper_box.currentData(), self.dpi.value(),
                          self.margin.value(), progress)
        return f"Created a PDF from {len(self.files.paths())} images."


class ToTextPanel(ToolPanel):
    key, title, group = "totext", "PDF → Text", "Convert"
    blurb = "Extract the text to a .txt file. (Scanned pages without a text layer produce no text.)"
    output = "text"
    suffix = ""

    def build(self):
        self.pages = self.pages_field()

    def execute(self, src, out, progress):
        r = ops.pdf_to_text(src, out, self.pages.text(), progress)
        msg = f"Extracted text from {r['pages']} pages."
        if r["empty_pages"]:
            msg += f"\n{r['empty_pages']} page(s) had no text (probably scanned images)."
        return msg


class ExtractImagesPanel(ToolPanel):
    key, title, group = "extimg", "Extract embedded images", "Convert"
    blurb = "Save the original pictures that are inside the PDF (photos, logos, scans)."
    output = "folder"

    def build(self):
        self.min = self.add("Skip images below (px)", spin(1, 2000, 32))
        self.pages = self.pages_field()

    def execute(self, src, out, progress):
        f = ops.extract_images(src, out, self.pages.text(), self.min.value(), progress)
        return f"Saved {len(f)} images." if f else "No images found in the selected pages."


# ======================================================================
# Stamp
# ======================================================================
POS9 = ["top-left", "top-center", "top-right", "middle-left", "middle-center",
        "middle-right", "bottom-left", "bottom-center", "bottom-right"]


class TextWatermarkPanel(ToolPanel):
    key, title, group = "wmtext", "Text watermark", "Watermark & numbers"
    blurb = ("Print text across the pages (DRAFT, CONFIDENTIAL ...). Hindi, Bengali, Tamil, Arabic and other "
             "scripts are shaped correctly using your installed fonts.")
    suffix = "_watermarked"

    def build(self):
        self.text = self.add("Text", QComboBox()); self.text.setEditable(True)
        self.text.addItems(["CONFIDENTIAL", "DRAFT", "COPY", "SAMPLE", "DO NOT COPY", "APPROVED"])
        self.fontsize = self.add("Font size", spin(8, 400, 60))
        self.color = self.add("Colour", ColorButton("#c00000"))
        self.opacity = self.add("Opacity", spin(5, 100, 25, 5, 0, " %"))
        self.angle = self.add("Angle (°)", spin(-180, 180, 45))
        self.tile = self.add("", QCheckBox("Repeat over the whole page"))
        self.fontfile = self.add("Font (optional)", FilePicker("Choose font", "Fonts (*.ttf *.otf)", "only to force a font"))
        self.pages = self.pages_field()

    def validate(self):
        if not self.text.currentText().strip():
            return "Enter the watermark text."

    def execute(self, src, out, progress):
        ops.add_text_watermark(src, out, self.text.currentText(), self.pages.text(), self.fontsize.value(),
                               self.color.value(), self.opacity.value() / 100, self.angle.value(),
                               self.tile.isChecked(), self.fontfile.value() or None, progress)
        return "Watermark added."


class ImageWatermarkPanel(ToolPanel):
    key, title, group = "wmimg", "Image / logo watermark", "Watermark & numbers"
    blurb = "Stamp a logo or signature (PNG with transparency works best)."
    suffix = "_stamped"

    def build(self):
        self.image = self.add("Image", FilePicker("Choose image", IMG_FILTER))
        self.scale = self.add("Width (% of page)", spin(2, 200, 40, 1, 0, " %"))
        self.opacity = self.add("Opacity", spin(5, 100, 40, 5, 0, " %"))
        self.angle = self.add("Rotation (°)", spin(-180, 180, 0))
        self.pos_box = self.add("Position", QComboBox()); self.pos_box.addItems(POS9); self.pos_box.setCurrentText("middle-center")
        self.margin = self.add("Margin (pt)", spin(0, 300, 20))
        self.tile = self.add("", QCheckBox("Repeat over the whole page"))
        self.pages = self.pages_field()

    def validate(self):
        if not self.image.value():
            return "Choose the image to stamp."

    def execute(self, src, out, progress):
        ops.add_image_watermark(src, out, self.image.value(), self.pages.text(), self.scale.value() / 100,
                                self.opacity.value() / 100, self.angle.value(), self.pos_box.currentText(),
                                self.margin.value(), self.tile.isChecked(), progress)
        return "Image added."


class StampPanel(ToolPanel):
    key, title, group = "stamp", "Page numbers / header / footer", "Watermark & numbers"
    blurb = ("Add page numbers or any header/footer text. Placeholders: {n} page, {total} page count, "
             "{file} file name, {date} today. Non-Latin scripts work too.")
    suffix = "_numbered"

    def build(self):
        self.preset = self.add("Preset", QComboBox())
        for label, t in (("Page 1", "{n}"), ("Page 1 of 10", "Page {n} of {total}"),
                         ("- 1 -", "- {n} -"), ("File name and date", "{file}  -  {date}"), ("Custom", None)):
            self.preset.addItem(label, t)
        self.text = self.add("Text", QLineEdit("Page {n} of {total}"))
        self.pos_box = self.add("Position", QComboBox()); self.pos_box.addItems(ops.POSITIONS)
        self.pos_box.setCurrentText("bottom-center")
        self.fontsize = self.add("Font size", spin(4, 72, 10))
        self.color = self.add("Colour", ColorButton("#000000"))
        self.margin = self.add("Distance from edge (pt)", spin(0, 200, 28))
        self.start = self.add("First page is numbered", spin(-999, 99999, 1))
        self.skip = self.add("", QCheckBox("Skip first page (cover)"))
        self.fontfile = self.add("Font (optional)", FilePicker("Choose font", "Fonts (*.ttf *.otf)", "only to force a font"))
        self.pages = self.pages_field()
        self.preset.currentIndexChanged.connect(self._preset)

    def _preset(self):
        t = self.preset.currentData()
        if t:
            self.text.setText(t)

    def execute(self, src, out, progress):
        ops.add_stamp(src, out, self.text.text(), self.pages.text(), self.pos_box.currentText(), self.fontsize.value(),
                      self.color.value(), self.margin.value(), self.start.value(), self.skip.isChecked(),
                      self.fontfile.value() or None, progress)
        return "Done."


# ======================================================================
# Security & properties
# ======================================================================
class ProtectPanel(ToolPanel):
    key, title, group = "protect", "Password protect", "Security & properties"
    blurb = ("AES-256 encryption. The password is needed to open the file. "
             "Remember it - it cannot be recovered.")
    suffix = "_protected"

    def build(self):
        self.pw = self.add("Password", QLineEdit()); self.pw.setEchoMode(QLineEdit.Password)
        self.pw2 = self.add("Repeat password", QLineEdit()); self.pw2.setEchoMode(QLineEdit.Password)
        self.show_pw = self.add("", QCheckBox("Show password"))
        self.show_pw.toggled.connect(lambda on: [e.setEchoMode(QLineEdit.Normal if on else QLineEdit.Password)
                                              for e in (self.pw, self.pw2)])
        self.print_ = self.add("", QCheckBox("Allow printing")); self.print_.setChecked(True)
        self.copy = self.add("", QCheckBox("Allow copying text")); self.copy.setChecked(True)
        self.modify = self.add("", QCheckBox("Allow editing / page changes"))
        self.annot = self.add("", QCheckBox("Allow comments / form filling"))

    def validate(self):
        if not self.pw.text():
            return "Enter a password."
        if self.pw.text() != self.pw2.text():
            return "The two passwords do not match."

    def execute(self, src, out, progress):
        ops.encrypt_pdf(src, out, self.pw.text(), None, self.print_.isChecked(), self.copy.isChecked(),
                        self.modify.isChecked(), self.annot.isChecked(), progress)
        return "The new file needs the password to open."


class UnlockPanel(ToolPanel):
    key, title, group = "unlock", "Remove password", "Security & properties"
    blurb = "Save an unprotected copy of a password-protected PDF (you must know the password)."
    suffix = "_unlocked"

    def build(self):
        self.pw = self.add("Password", QLineEdit()); self.pw.setEchoMode(QLineEdit.Password)
        self.pw.setPlaceholderText("leave empty if already unlocked in this program")

    def execute(self, src, out, progress):
        ops.decrypt_pdf(src, out, self.pw.text(), progress)
        return "Saved without password."


class MetadataPanel(ToolPanel):
    key, title, group = "meta", "Properties (metadata)", "Security & properties"
    blurb = "Edit the document title, author, subject and keywords - or erase all hidden metadata before sharing."
    suffix = "_meta"

    def build(self):
        self.fields = {}
        for k, label in (("title", "Title"), ("author", "Author"), ("subject", "Subject"), ("keywords", "Keywords")):
            self.fields[k] = self.add(label, QLineEdit())
        self.clear = self.add("", QCheckBox("Erase all metadata"))
        self.clear.toggled.connect(lambda on: [f.setEnabled(not on) for f in self.fields.values()])

    def on_document_changed(self):
        self.on_activate()

    def on_activate(self):
        meta = self.ctx.metadata()
        for k, f in self.fields.items():
            f.setText(meta.get(k, "") or "")

    def execute(self, src, out, progress):
        v = {k: f.text() for k, f in self.fields.items()}
        ops.set_metadata(src, out, v["title"], v["author"], v["subject"], v["keywords"], self.clear.isChecked())
        return "Properties saved."


class FlattenPanel(ToolPanel):
    key, title, group = "flatten", "Flatten forms & comments", "Security & properties"
    blurb = "Burn form fields, highlights and comments into the page so they can no longer be edited."
    suffix = "_flattened"

    def execute(self, src, out, progress):
        ops.flatten_pdf(src, out, progress)
        return "Done."


# ======================================================================
# Edit, OCR & sign
# ======================================================================
class OcrPanel(ToolPanel):
    key, title, group = "ocr", "OCR (make scans searchable)", "Edit, OCR & sign"
    blurb = ("Recognise the text of scanned pages and add an invisible text layer, so the text can be searched, "
             "selected and copied. Needs the free Tesseract language files (see the documentation).")
    suffix = "_ocr"

    def build(self):
        self.lang = self.add("Language(s)", QLineEdit("eng"))
        self.lang.setPlaceholderText("eng   or   eng+hin   (several joined by +)")
        self.avail = QLabel(); self.avail.setWordWrap(True)
        self.form.addRow("Installed", self.avail)
        self.dpi = self.add("Resolution (DPI)", spin(100, 600, 300))
        self.skip = self.add("", QCheckBox("Skip pages that already have text")); self.skip.setChecked(True)
        self.pages = self.pages_field()

    def on_activate(self):
        langs = advanced.ocr_languages()
        self.avail.setText(", ".join(langs) if langs else "none found - see the documentation (OCR language data)")

    def execute(self, src, out, progress):
        st = {}
        advanced.ocr_pdf(src, out, self.lang.text(), self.dpi.value(), self.pages.text(), self.skip.isChecked(),
                         progress, st)
        return f"Recognised {st['recognised']} page(s); {st['skipped']} copied unchanged."


class ReplaceTextPanel(ToolPanel):
    key, title, group = "replace", "Find & replace text", "Edit, OCR & sign"
    blurb = ("Change existing text in the PDF. The old text is removed and the new text is drawn in a similar "
             "standard font, size and colour. Works for text-based PDFs (scans: run OCR first).")
    suffix = "_replaced"

    def build(self):
        self.find = self.add("Find", QLineEdit())
        self.repl = self.add("Replace with", QLineEdit())
        self.case = self.add("", QCheckBox("Match upper/lower case"))
        self.shrink = self.add("", QCheckBox("Shrink to avoid overlapping text")); self.shrink.setChecked(True)
        self.fontfile = self.add("Font (optional)", FilePicker("Choose font", "Fonts (*.ttf *.otf)", "for non-standard letters"))
        self.pages = self.pages_field()

    def validate(self):
        if not self.find.text():
            return "Enter the text to find."

    def execute(self, src, out, progress):
        st = {}
        advanced.replace_text(src, out, self.find.text(), self.repl.text(), self.pages.text(), self.case.isChecked(),
                              self.shrink.isChecked(), self.fontfile.value() or None, progress, st)
        return f"Replaced {st['replaced']} occurrence(s)."


class RedactPanel(ToolPanel):
    key, title, group = "redact", "Redact (black out text)", "Edit, OCR & sign"
    blurb = ("Permanently remove sensitive text - it is deleted from the file, not just covered. "
             "Type one text per line and/or tick patterns. Remember to erase metadata afterwards.")
    suffix = "_redacted"

    def build(self):
        self.terms = self.add("Texts (one per line)", QPlainTextEdit())
        self.terms.setFixedHeight(90)
        self.pat = {}
        for k, label in (("email", "E-mail addresses"), ("phone", "Phone numbers"), ("aadhaar", "Aadhaar numbers (1234 5678 9012)"),
                         ("pan", "PAN numbers"), ("card", "Card numbers (16 digits)")):
            self.pat[k] = self.add("", QCheckBox(label))
        self.regex = self.add("Own pattern (regex)", QLineEdit()); self.regex.setPlaceholderText("optional, e.g. INV-\\d{6}")
        self.case = self.add("", QCheckBox("Match upper/lower case (texts)"))
        self.fill = self.add("Box colour", ColorButton("#000000"))
        self.pages = self.pages_field()

    def execute(self, src, out, progress):
        pats = [k for k, c in self.pat.items() if c.isChecked()]
        if self.regex.text().strip():
            pats.append("re:" + self.regex.text().strip())
        st = {}
        advanced.redact_text(src, out, self.terms.toPlainText().splitlines(), pats, self.pages.text(),
                             self.case.isChecked(), self.fill.value(), progress, st)
        return f"Removed {st['redacted']} item(s)."


class FormPanel(ToolPanel):
    key, title, group = "form", "Fill form fields", "Edit, OCR & sign"
    blurb = ("Fill in a PDF form. The list shows every field as  name = value  - change the values. "
             "Check boxes: Yes / No. Tick 'Make permanent' to flatten the form afterwards.")
    suffix = "_filled"

    def build(self):
        self.fields = self.add("Fields", QPlainTextEdit())
        self.fields.setMinimumHeight(170)
        self.flat = self.add("", QCheckBox("Make the entries permanent (flatten)"))

    def on_document_changed(self):
        self.on_activate()

    def on_activate(self):
        if self.ctx.path:
            try:
                txt = advanced.get_form_text(self.ctx.path)
            except Exception:
                txt = ""
            self.fields.setPlainText(txt)
            self.fields.setPlaceholderText("This PDF has no form fields.")

    def execute(self, src, out, progress):
        st = {}
        advanced.fill_form(src, out, self.fields.toPlainText(), self.flat.isChecked(), progress, st)
        msg = f"Filled {st['filled']} field(s)."
        if st["missing"]:
            msg += "\nNot found: " + ", ".join(st["missing"][:10])
        return msg


class HighlightPanel(ToolPanel):
    key, title, group = "highlight", "Highlight / underline text", "Edit, OCR & sign"
    blurb = "Mark every occurrence of words with a highlight, underline, strike-out or squiggly line (editable comments in the PDF)."
    suffix = "_marked"

    def build(self):
        self.terms = self.add("Texts (one per line)", QPlainTextEdit())
        self.terms.setFixedHeight(90)
        self.kind = self.add("Style", QComboBox()); self.kind.addItems(advanced.HIGHLIGHT_KINDS)
        self.color = self.add("Colour", ColorButton("#ffff00"))
        self.case = self.add("", QCheckBox("Match upper/lower case"))
        self.pages = self.pages_field()

    def execute(self, src, out, progress):
        st = {}
        advanced.highlight_text(src, out, self.terms.toPlainText().splitlines(), self.kind.currentText(),
                                self.color.value(), self.pages.text(), self.case.isChecked(), progress, st)
        return f"Marked {st['marked']} place(s)."


class SignPanel(ToolPanel):
    key, title, group = "sign", "Digital signature", "Edit, OCR & sign"
    blurb = ("Sign the PDF with your certificate (.p12 / .pfx). Anyone can then check that the file is unchanged. "
             "Do this as the LAST step - any later edit invalidates the signature. No certificate yet? "
             "Use 'Create signing certificate'.")
    suffix = "_signed"

    def build(self):
        self.cert = self.add("Certificate file", FilePicker("Choose certificate", "Certificates (*.p12 *.pfx)", ".p12 / .pfx"))
        self.pw = self.add("Certificate password", QLineEdit()); self.pw.setEchoMode(QLineEdit.Password)
        self.reason = self.add("Reason (optional)", QLineEdit())
        self.location = self.add("Location (optional)", QLineEdit())
        self.visible = self.add("", QCheckBox("Show a visible signature box")); self.visible.setChecked(True)
        self.page = self.add("On page", spin(1, 99999, 1))
        self.pos_box = self.add("Position", QComboBox())
        self.pos_box.addItems(["bottom-right", "bottom-left", "bottom-center", "top-right", "top-left", "top-center",
                               "middle-center"])
        self.visible.toggled.connect(lambda on: [w.setEnabled(on) for w in (self.page, self.pos_box)])

    def validate(self):
        if not self.cert.value():
            return "Choose the certificate file (.p12 / .pfx)."

    def execute(self, src, out, progress):
        st = {}
        advanced.sign_pdf(src, out, self.cert.value(), self.pw.text(), self.reason.text(), self.location.text(), "",
                          self.visible.isChecked(), self.page.value(), self.pos_box.currentText(), progress=progress, stats=st)
        msg = "Signed. Do not edit this file any more - changes would invalidate the signature."
        if st.get("invisible_because_rotated"):
            msg += "\n(The chosen page is rotated, so the signature was added without a visible box.)"
        return msg


class VerifyPanel(ToolPanel):
    key, title, group = "verify", "Check signatures", "Edit, OCR & sign"
    blurb = "Check whether the PDF is digitally signed and whether it was changed after signing. Saves a short report (.txt)."
    output = "text"
    suffix = "_signature_report"

    def execute(self, src, out, progress):
        sigs = advanced.verify_signatures(src)
        advanced.verify_report(src, out)
        if not sigs:
            return "No digital signatures found."
        ok = sum(1 for s in sigs if s["valid"] and s["whole_file"])
        return f"{len(sigs)} signature(s) found; {ok} valid and unchanged."


class CertPanel(ToolPanel):
    key, title, group = "cert", "Create signing certificate", "Edit, OCR & sign"
    blurb = ("Make a personal certificate file (.p12) for the Digital signature tool. Keep the file and its password "
             "safe. Personal certificates show as 'not trusted' in other programs - the signature still proves the file is unchanged.")
    needs_pdf = False
    output = "p12"

    def build(self):
        self.name = self.add("Your name", QLineEdit())
        self.org = self.add("Organisation (optional)", QLineEdit())
        self.email = self.add("E-mail (optional)", QLineEdit())
        self.pw = self.add("Password", QLineEdit()); self.pw.setEchoMode(QLineEdit.Password)
        self.pw2 = self.add("Repeat password", QLineEdit()); self.pw2.setEchoMode(QLineEdit.Password)
        self.days = self.add("Valid for (days)", spin(30, 7300, 1095))

    def suggest(self, src):
        return str(_free(Path.home() / "my_signing_certificate.p12"))

    def validate(self):
        if not self.name.text().strip():
            return "Enter your name."
        if self.pw.text() != self.pw2.text():
            return "The two passwords do not match."

    def execute(self, src, out, progress):
        advanced.create_certificate(out, self.name.text(), self.pw.text(), self.org.text(), self.email.text(), self.days.value())
        return "Certificate created. Keep it and its password safe."


class BookmarksPanel(ToolPanel):
    key, title, group = "bookmarks", "Bookmarks (outline)", "Edit, OCR & sign"
    blurb = ("Edit the table of contents. One bookmark per line:  Title | page.  Indent a line by two spaces to make "
             "it a sub-item.")
    suffix = "_bookmarks"

    def build(self):
        self.text_ = self.add("Bookmarks", QPlainTextEdit())
        self.text_.setMinimumHeight(160)
        self.text_.setPlaceholderText("Introduction | 1\n  Background | 2\nChapter 1 | 5")
        self.clear = self.add("", QCheckBox("Remove all bookmarks"))

    def on_document_changed(self):
        self.on_activate()

    def on_activate(self):
        if self.ctx.path:
            try:
                self.text_.setPlainText(advanced.get_bookmarks_text(self.ctx.path))
            except Exception:
                pass

    def execute(self, src, out, progress):
        advanced.set_bookmarks(src, out, self.text_.toPlainText(), self.clear.isChecked())
        return "Bookmarks saved."


class PageLabelsPanel(ToolPanel):
    key, title, group = "labels", "Page labels (i, ii, A-1 ...)", "Edit, OCR & sign"
    blurb = ("Change the page numbers that PDF viewers show (for example roman numerals for the preface, 1, 2, 3 "
             "from the first chapter). The rule starts at the chosen page. Run it again for more sections.")
    suffix = "_labels"

    def build(self):
        self.start = self.add("Starting at page", spin(1, 99999, 1))
        self.style_box = self.add("Numbering", QComboBox())
        for label, code in advanced.LABEL_STYLES.items():
            self.style_box.addItem(label, code)
        self.prefix = self.add("Prefix (optional)", QLineEdit()); self.prefix.setPlaceholderText("e.g. A-")
        self.first = self.add("First number", spin(1, 99999, 1))
        self.clear = self.add("", QCheckBox("Remove all page labels"))

    def execute(self, src, out, progress):
        advanced.set_page_labels(src, out, self.start.value(), self.style_box.currentData(), self.prefix.text(),
                                 self.first.value(), self.clear.isChecked())
        return "Page labels saved."


class BlankPagesPanel(ToolPanel):
    key, title, group = "blank_rm", "Remove blank pages", "Organise"
    blurb = ("Find and delete empty pages (typical in double-sided scans). Page edges are ignored, so scanner "
             "shadows do not count.")
    suffix = "_noblank"

    def build(self):
        self.sens = self.add("Sensitivity (% ink allowed)", spin(0, 20, 0.3, 0.1, 1))

    def execute(self, src, out, progress):
        st = {}
        advanced.remove_blank_pages(src, out, self.sens.value(), progress, st)
        pages = ", ".join(str(p) for p in st["removed"][:30]) + (" ..." if len(st["removed"]) > 30 else "")
        return f"Removed {len(st['removed'])} blank page(s): {pages}"


ALL_PANELS = [
    MergePanel, SplitPanel, ExtractPanel, DeletePanel, ReorderPanel, DuplicatePanel, BlankPanel, BlankPagesPanel, RotatePanel,
    CropPanel, CutPanel, ResizePanel, ScalePanel, NUpPanel,
    CompressPanel, RasterizePanel,
    ToImagesPanel, FromImagesPanel, ToTextPanel, ExtractImagesPanel,
    TextWatermarkPanel, ImageWatermarkPanel, StampPanel,
    ProtectPanel, UnlockPanel, MetadataPanel, FlattenPanel,
    OcrPanel, ReplaceTextPanel, RedactPanel, HighlightPanel, FormPanel, BookmarksPanel, PageLabelsPanel,
    SignPanel, VerifyPanel, CertPanel,
]
