"""Main window: tool list, option panels, preview, background worker."""
from __future__ import annotations

import os
import sys
import traceback
from pathlib import Path

import pymupdf
from PySide6.QtCore import QSettings, QThread, QUrl, Qt, Signal
from PySide6.QtGui import QAction, QDesktopServices, QKeySequence
from PySide6.QtWidgets import (
    QApplication, QFileDialog, QFrame, QHBoxLayout, QInputDialog, QLabel,
    QLineEdit, QMainWindow, QMessageBox, QProgressBar, QPushButton,
    QScrollArea, QSplitter, QStackedWidget, QTreeWidget, QTreeWidgetItem,
    QVBoxLayout, QWidget,
)

from pdfkit import ops
from .preview import PreviewPane
from .tools import ALL_PANELS, ToolPanel

APP_NAME = "PDF Toolkit"
VERSION = "1.2"


class Worker(QThread):
    """Runs one job off the GUI thread. The job only uses plain Python values
    that were copied from the option widgets before the thread started."""
    progress = Signal(int, int)
    succeeded = Signal(str)
    failed = Signal(str, str)      # message, technical details ("" for expected errors)
    cancelled = Signal()

    def __init__(self, job):
        super().__init__()
        self.job = job
        self._cancel = False

    def cancel(self):
        self._cancel = True

    def _cb(self, done, total):
        if self._cancel:
            raise ops.Cancelled()
        self.progress.emit(done, total)

    def run(self):
        try:
            self.succeeded.emit(self.job(self._cb) or "Done.")
        except ops.Cancelled:
            self.cancelled.emit()
        except ops.PDFError as e:
            self.failed.emit(str(e), "")
        except PermissionError as e:
            self.failed.emit("Cannot write the result - the file may be open in another program "
                             f"or the folder is read-only.\n\n{e}", "")
        except OSError as e:     # disk full, invalid file name, path too long ...
            self.failed.emit(f"Cannot save the result: {e.strerror or e}\n\n{getattr(e, 'filename', '') or ''}".strip(), "")
        except MemoryError:
            self.failed.emit("Not enough memory for this operation. Try a lower resolution "
                             "or process fewer pages at a time.", "")
        except Exception as e:  # unexpected
            self.failed.emit(f"{type(e).__name__}: {e}", traceback.format_exc())


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(APP_NAME)
        self.resize(1360, 820)
        self.setAcceptDrops(True)
        self.settings = QSettings("PDFToolkit", "PDFToolkit")
        self.path: str | None = None
        self.doc: pymupdf.Document | None = None
        self.worker: Worker | None = None
        self.last_result: str | None = None

        # ---- preview
        self.preview = PreviewPane()
        self.preview.pageChanged.connect(self._page_changed)

        # ---- top bar
        bar = QHBoxLayout()
        open_btn = QPushButton("Open PDF…"); open_btn.clicked.connect(self.open_dialog)
        self.file_label = QLabel("No file open"); self.file_label.setStyleSheet("font-weight:600;")
        info_btn = QPushButton("Document info"); info_btn.clicked.connect(self.show_info)
        close_btn = QPushButton("Close file"); close_btn.clicked.connect(self.close_file)
        bar.addWidget(open_btn); bar.addWidget(self.file_label, 1); bar.addWidget(info_btn); bar.addWidget(close_btn)

        # ---- tool tree + panels
        self.tree = QTreeWidget(); self.tree.setHeaderHidden(True); self.tree.setMinimumWidth(190)
        self.tree.setMaximumWidth(260); self.tree.setIndentation(12)
        self.stack = QStackedWidget()
        self.panels: dict[str, ToolPanel] = {}
        groups: dict[str, QTreeWidgetItem] = {}
        for cls in ALL_PANELS:
            panel = cls(self)
            self.panels[panel.key] = panel
            holder = QScrollArea(); holder.setWidgetResizable(True); holder.setFrameShape(QFrame.NoFrame)
            holder.setWidget(panel)
            self.stack.addWidget(holder)
            if panel.group not in groups:
                g = QTreeWidgetItem([panel.group]); g.setFlags(Qt.ItemIsEnabled)
                f = g.font(0); f.setBold(True); g.setFont(0, f)
                self.tree.addTopLevelItem(g); groups[panel.group] = g
            it = QTreeWidgetItem([panel.title]); it.setData(0, Qt.UserRole, panel.key)
            groups[panel.group].addChild(it)
        self.tree.expandAll()
        self.tree.currentItemChanged.connect(self._tool_selected)

        self.tool_title = QLabel(""); self.tool_title.setStyleSheet("font-size:17px; font-weight:700;")
        self.run_btn = QPushButton("Run"); self.run_btn.setDefault(True)
        self.run_btn.setStyleSheet("font-weight:700; padding:8px 18px;")
        self.run_btn.clicked.connect(self.run_current)

        mid = QWidget(); ml = QVBoxLayout(mid)
        ml.addWidget(self.tool_title); ml.addWidget(self.stack, 1); ml.addWidget(self.run_btn)
        mid.setMinimumWidth(340)

        split = QSplitter()
        split.addWidget(self.tree); split.addWidget(mid); split.addWidget(self.preview)
        split.setStretchFactor(0, 0); split.setStretchFactor(1, 0); split.setStretchFactor(2, 1)
        split.setSizes([220, 400, 740])

        central = QWidget(); cl = QVBoxLayout(central)
        cl.addLayout(bar); cl.addWidget(split, 1)
        self.setCentralWidget(central)

        # ---- status bar
        self.progress = QProgressBar(); self.progress.setMaximumWidth(220); self.progress.hide()
        self.cancel_btn = QPushButton("Cancel"); self.cancel_btn.hide(); self.cancel_btn.clicked.connect(self._cancel)
        self.statusBar().addPermanentWidget(self.progress)
        self.statusBar().addPermanentWidget(self.cancel_btn)

        # ---- menu
        m = self.menuBar().addMenu("&File")
        for text, key, fn in (("&Open PDF…", "Ctrl+O", self.open_dialog),
                              ("&Close file", "Ctrl+W", self.close_file),
                              ("&Quit", "Ctrl+Q", self.close)):
            a = QAction(text, self); a.setShortcut(key); a.triggered.connect(fn); m.addAction(a)
        t = self.menuBar().addMenu("&Tools")
        a = QAction("&Run current tool", self); a.setShortcuts(["Ctrl+Return", "Ctrl+Enter"]); a.triggered.connect(self.run_current)
        t.addAction(a)
        h = self.menuBar().addMenu("&Help")
        a = QAction("&About", self); a.triggered.connect(self.about); h.addAction(a)

        first = self.tree.topLevelItem(0).child(0)
        self.tree.setCurrentItem(first)
        self.statusBar().showMessage("Open a PDF (button above, Ctrl+O, or drag & drop) and choose a tool on the left.")

    # ------------------------------------------------------------ context API
    # (used by the tool panels)
    def current_page(self) -> int:
        return self.preview.view.page_no

    def selected_pages(self) -> list[int]:
        return self.preview.thumbs.selected_pages()

    def page_count(self) -> int:
        return self.doc.page_count if self.doc else 0

    def page_size_pts(self):
        if not self.doc:
            return 0.0, 0.0
        r = self.doc[self.current_page()].rect
        return r.width, r.height

    def metadata(self) -> dict:
        return dict(self.doc.metadata or {}) if self.doc else {}

    def last_dir(self) -> str:
        d = self.settings.value("last_dir", "")
        return d if d and os.path.isdir(d) else str(Path.home())

    def remember_dir(self, path: str):
        self.settings.setValue("last_dir", str(Path(path).parent))

    def ask_password(self, path: str) -> bool:
        for _ in range(3):
            pw, ok = QInputDialog.getText(self, "Password required",
                                          f"Password for {os.path.basename(path)}:", QLineEdit.Password)
            if not ok:
                return False
            ops.set_password(path, pw)
            try:
                ops.open_pdf(path).close()
                return True
            except ops.PasswordRequired:
                QMessageBox.warning(self, APP_NAME, "That password is not correct.")
        return False

    # -------------------------------------------------------------- file open
    def open_dialog(self):
        f, _ = QFileDialog.getOpenFileName(self, "Open PDF", self.last_dir(), "PDF files (*.pdf);;All files (*)")
        if f:
            self.open_file(f)

    def open_file(self, path: str) -> bool:
        if self.worker:
            QMessageBox.information(self, APP_NAME, "Please wait until the running task has finished.")
            return False
        path = os.path.abspath(path)
        try:
            if ops.needs_password(path) and not self.ask_password(path):
                return False
            doc = ops.open_pdf(path, in_memory=True)
        except ops.PDFError as e:
            QMessageBox.warning(self, APP_NAME, str(e))
            return False
        self._release_doc()
        self.doc, self.path = doc, path
        self.remember_dir(path)
        self.preview.set_document(doc)
        self.file_label.setText(f"{os.path.basename(path)}   ·   {doc.page_count} pages   ·   "
                                f"{ops.human_size(os.path.getsize(path))}")
        self.setWindowTitle(f"{os.path.basename(path)} - {APP_NAME}")
        for p in self.panels.values():
            p.on_document_changed()
        self.statusBar().showMessage(f"Opened {path}", 5000)
        return True

    def _release_doc(self):
        self.preview.set_document(None)
        if self.doc:
            self.doc.close()
        self.doc, self.path = None, None

    def close_file(self):
        if self.worker:
            return
        self._release_doc()
        self.file_label.setText("No file open")
        self.setWindowTitle(APP_NAME)

    def show_info(self):
        if not self.path:
            QMessageBox.information(self, APP_NAME, "Open a PDF first.")
            return
        try:
            i = ops.pdf_info(self.path)
        except ops.PDFError as e:
            QMessageBox.warning(self, APP_NAME, str(e)); return
        sizes = "\n".join(f"    {w / 72 * 25.4:.0f} × {h / 72 * 25.4:.0f} mm  -  {n} page(s)"
                          for (w, h), n in i["page_sizes"].items())
        m = i["metadata"]
        text = (f"File: {i['file']}\nSize: {ops.human_size(i['bytes'])}\nPages: {i['pages']}\n"
                f"Format: {i['format']}\nEncrypted: {'yes' if i['encrypted'] else 'no'}\n"
                f"Bookmarks: {i['bookmarks']}   Links: {i['links']}   Annotations: {i['annotations']}   "
                f"Form fields: {'yes' if i['has_form'] else 'no'}\n\nPage sizes:\n{sizes}\n\n"
                f"Title: {m.get('title', '')}\nAuthor: {m.get('author', '')}\nCreator: {m.get('creator', '')}\n"
                f"Producer: {m.get('producer', '')}\nCreated: {m.get('creationDate', '')}")
        QMessageBox.information(self, "Document info", text)

    # --------------------------------------------------------------- drag/drop
    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()

    def dropEvent(self, e):
        files = [u.toLocalFile() for u in e.mimeData().urls() if u.isLocalFile()]
        if not files:
            return
        panel = self.current_panel()
        if hasattr(panel, "files") and not panel.needs_pdf or panel.key == "merge":
            ext_ok = (lambda f: f.lower().endswith(".pdf")) if panel.key == "merge" else (
                lambda f: not f.lower().endswith(".pdf"))
            panel.files.add_files([f for f in files if ext_ok(f)])
        else:
            pdfs = [f for f in files if f.lower().endswith(".pdf")]
            if pdfs:
                self.open_file(pdfs[0])

    # ----------------------------------------------------------------- tools
    def current_panel(self) -> ToolPanel:
        return self.stack.currentWidget().widget()

    def _tool_selected(self, item, _prev=None):
        if not item:
            return
        key = item.data(0, Qt.UserRole)
        if not key:
            if item.childCount():
                self.tree.setCurrentItem(item.child(0))
            return
        for p in self.panels.values():
            pass
        panel = self.panels[key]
        self.stack.setCurrentIndex(list(self.panels).index(key))
        self.tool_title.setText(panel.title)
        self.preview.view.set_mode(panel.overlay)
        panel.on_activate()

    def _page_changed(self, n):
        self.current_panel().on_page_changed(n)

    # ------------------------------------------------------------------- run
    def _warn(self, text):
        QMessageBox.warning(self, APP_NAME, text)

    def run_current(self):
        if self.worker:
            return
        p = self.current_panel()
        if p.needs_pdf and not self.path:
            self._warn("Open a PDF first (button at the top, Ctrl+O, or drag a file into the window).")
            return
        err = p.validate()
        if err:
            self._warn(err)
            return
        if p.output == "folder":
            out = QFileDialog.getExistingDirectory(self, "Choose the folder for the results", p.suggest(self.path))
        else:
            ext, filt = {"text": (".txt", "Text (*.txt)"), "p12": (".p12", "Certificate (*.p12)")}.get(
                p.output, (".pdf", "PDF files (*.pdf)"))
            out, _ = QFileDialog.getSaveFileName(self, "Save result as", p.suggest(self.path), filt)
            if out and not out.lower().endswith(ext):
                out += ext
        if not out:
            return
        self.start(p, self.path, out)

    def start(self, panel: ToolPanel, src, out):
        self.worker = Worker(panel.make_job(src, out))
        w = self.worker
        w.progress.connect(self._progress)
        w.succeeded.connect(lambda msg: self._finished(panel, out, msg))
        w.failed.connect(self._failed)
        w.cancelled.connect(self._cancelled)
        w.finished.connect(self._worker_done)
        self._busy(True)
        w.start()

    def _busy(self, on: bool):
        # Lock the whole workspace while a job runs: options cannot change under it, and the
        # GUI thread stops rendering with PyMuPDF (it is not safe to use from two threads).
        self.centralWidget().setEnabled(not on)
        self.menuBar().setEnabled(not on)
        self.preview.thumbs.set_paused(on)
        self.progress.setVisible(on); self.cancel_btn.setVisible(on)
        self.progress.setRange(0, 0 if on else 1)
        if on:
            self.statusBar().showMessage("Working…  (Cancel stops it; nothing is saved if you cancel)")
            self.setCursor(Qt.BusyCursor)
        else:
            self.unsetCursor()

    def _progress(self, done, total):
        if total:
            self.progress.setRange(0, total); self.progress.setValue(done)

    def _cancel(self):
        if self.worker:
            self.worker.cancel(); self.cancel_btn.setEnabled(False)
            self.statusBar().showMessage("Cancelling…")

    def _worker_done(self):
        self.worker = None
        self._busy(False)
        self.cancel_btn.setEnabled(True)

    def _cancelled(self):
        self.statusBar().showMessage("Cancelled - no output was written.", 6000)

    def _failed(self, msg, details):
        self.statusBar().showMessage("Failed", 6000)
        box = QMessageBox(QMessageBox.Warning if not details else QMessageBox.Critical, APP_NAME,
                          msg if not details else f"Something unexpected went wrong:\n{msg}", parent=self)
        if details:
            box.setDetailedText(details)
        box.exec()

    def _finished(self, panel: ToolPanel, out: str, msg: str):
        self.last_result = out
        self.remember_dir(out if panel.output != "folder" else os.path.join(out, "x"))
        self.statusBar().showMessage(f"Done - {out}", 8000)
        box = QMessageBox(QMessageBox.Information, APP_NAME, f"{msg}\n\n{out}", parent=self)
        open_b = box.addButton("Open", QMessageBox.AcceptRole) if panel.output not in ("folder", "p12") else None
        folder_b = box.addButton("Show folder", QMessageBox.ActionRole)
        edit_b = box.addButton("Continue editing this file", QMessageBox.ActionRole) if panel.output == "pdf" else None
        box.addButton("Close", QMessageBox.RejectRole)
        box.exec()
        clicked = box.clickedButton()
        target = out if os.path.isdir(out) else os.path.dirname(out)
        if clicked is open_b:
            QDesktopServices.openUrl(QUrl.fromLocalFile(out))
        elif clicked is folder_b:
            QDesktopServices.openUrl(QUrl.fromLocalFile(target))
        elif edit_b is not None and clicked is edit_b:
            self.open_file(out)

    def about(self):
        QMessageBox.about(self, APP_NAME, f"<b>{APP_NAME} {VERSION}</b><br>All-in-one offline PDF tools.<br>"
                          "Your files never leave your computer and originals are never overwritten.<br><br>"
                          "Built with Python, PySide6 (Qt) and PyMuPDF.")

    def closeEvent(self, e):
        if self.worker:
            self.worker.cancel(); self.worker.wait(3000)
        self._release_doc()
        e.accept()


LOG_PATH = Path.home() / "PDFToolkit_error.log"


def _install_excepthook(parent_getter):
    """Show unexpected errors in a dialog (the Windows launcher has no console)
    and keep a copy in ~/PDFToolkit_error.log so it can be reported."""
    def hook(exc_type, exc, tb):
        text = "".join(traceback.format_exception(exc_type, exc, tb))
        try:
            with open(LOG_PATH, "a", encoding="utf-8") as f:
                f.write(text + "\n")
        except OSError:
            pass
        try:
            sys.__excepthook__(exc_type, exc, tb)
        except Exception:
            pass
        try:
            box = QMessageBox(QMessageBox.Critical, APP_NAME,
                              f"Unexpected error: {exc_type.__name__}: {exc}\n\n"
                              f"Your files were not changed. Details were saved to:\n{LOG_PATH}",
                              parent=parent_getter())
            box.setDetailedText(text)
            box.exec()
        except Exception:
            pass
    sys.excepthook = hook


def main(argv=None):
    argv = list(sys.argv if argv is None else argv)
    app = QApplication(argv)
    app.setApplicationName(APP_NAME)
    app.setStyle("Fusion")
    holder = {}
    _install_excepthook(lambda: holder.get("win"))
    win = MainWindow()
    holder["win"] = win
    win.show()
    for a in argv[1:]:
        if a.lower().endswith(".pdf") and os.path.isfile(a):
            win.open_file(a)
            break
    return app.exec()
