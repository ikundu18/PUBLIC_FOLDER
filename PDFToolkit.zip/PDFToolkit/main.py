"""PDF Toolkit - launch with:  python main.py  [optional.pdf]"""
import sys


def _report(text: str) -> None:
    """Show a start-up problem even when there is no console (pythonw)."""
    try:
        print(text)
    except Exception:
        pass
    try:
        from pathlib import Path
        (Path.home() / "PDFToolkit_error.log").write_text(text, encoding="utf-8")
    except Exception:
        pass
    if sys.platform == "win32":
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(0, text, "PDF Toolkit", 0x10)
        except Exception:
            pass


if __name__ == "__main__":
    try:
        from gui.main_window import main
    except ModuleNotFoundError as exc:
        _report(f"A required package is missing: {exc.name}\n\nFix: delete the '.venv' folder next to "
                f"main.py and start the program again (or run:\n{sys.executable} -m pip install -r requirements.txt)")
        raise SystemExit(1)
    except Exception as exc:  # e.g. missing system libraries for Qt
        import traceback
        _report("PDF Toolkit could not start:\n\n" + "".join(traceback.format_exception(exc)))
        raise SystemExit(1)
    raise SystemExit(main())
