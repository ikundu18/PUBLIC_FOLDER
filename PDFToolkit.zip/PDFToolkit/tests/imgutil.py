"""Image helpers for the tests - Qt + PyMuPDF only (no Pillow)."""
import os

import pymupdf
from PySide6.QtGui import QColor, QImage


class Img:
    """Tiny read-only view of a rendered page (replaces PIL.Image)."""

    def __init__(self, pix: pymupdf.Pixmap):
        self.pix = pix
        self.width, self.height = pix.width, pix.height
        self.size = (pix.width, pix.height)

    def getpixel(self, xy):
        return tuple(self.pix.pixel(*xy))[:3]

    def pixels(self):
        for y in range(self.height):
            for x in range(self.width):
                yield self.getpixel((x, y))


def make_image(path, size, color, fmt=None):
    """Write a solid-colour image. ``color`` is a Qt colour name or (r,g,b[,a])."""
    w, h = size
    c = QColor(*color) if isinstance(color, tuple) else QColor(color)
    img = QImage(w, h, QImage.Format_ARGB32)
    img.fill(c)
    if not str(path).lower().endswith((".png", ".webp", ".tif", ".tiff", ".bmp")):
        img = img.convertToFormat(QImage.Format_RGB32)
    assert img.save(str(path), fmt), f"cannot write {path}"
    return str(path)


def image_size(path):
    img = QImage(str(path))
    assert not img.isNull(), f"unreadable image {path}"
    return (img.width(), img.height())


def noise_jpg(path, size=(1600, 1200), quality=95):
    w, h = size
    pix = pymupdf.Pixmap(pymupdf.csRGB, w, h, os.urandom(w * h * 3), False)
    pix.save(str(path), jpg_quality=quality)
    return str(path)
