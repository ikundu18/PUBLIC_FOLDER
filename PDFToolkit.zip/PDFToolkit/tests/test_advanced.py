"""Tests for OCR, replace/redact, signatures, bookmarks, labels, blank pages and label preservation."""
import os
import sys
from pathlib import Path

import pymupdf
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from pdfkit import advanced, ops  # noqa: E402


@pytest.fixture()
def doc_path(tmp_path):
    d = pymupdf.open()
    for i in range(4):
        p = d.new_page()
        p.insert_text((72, 100), f"Invoice 100{i} for Ravi Kumar mail ravi@example.com", fontsize=14)
        p.insert_text((72, 140), "PAN ABCDE1234F Aadhaar 1234 5678 9012", fontsize=12)
    d.new_page()                                   # blank page 5
    path = tmp_path / "s.pdf"
    d.save(str(path))
    return str(path)


def labels(path):
    with pymupdf.open(path) as d:
        return [p.get_label() for p in d]


def test_labels_survive_page_changing_tools(tmp_path):
    d = pymupdf.open()
    for _ in range(8):
        d.new_page()
    d.set_page_labels([{"startpage": 0, "style": "r", "firstpagenum": 1},
                       {"startpage": 3, "prefix": "A-", "style": "D", "firstpagenum": 1}])
    src = str(tmp_path / "l.pdf"); d.save(src)
    o = str(tmp_path / "o.pdf")
    ops.extract_pages(src, o, "2-5");   assert labels(o) == ["ii", "iii", "A-1", "A-2"]
    ops.delete_pages(src, o, "1");      assert labels(o)[:2] == ["ii", "iii"]
    ops.reorder_pages(src, o, "8,1-7"); assert labels(o)[:2] == ["A-5", "i"]
    ops.duplicate_pages(src, o, "4", 1); assert labels(o)[3:5] == ["A-1", "A-1"]
    ops.insert_blank_pages(src, o, "3"); assert labels(o)[2:5] == ["iii", "", "A-1"]
    ops.cut_pages(src, o, "1");         assert labels(o)[:3] == ["i", "i", "ii"]
    ops.merge_pdfs([src, src], o);      assert labels(o)[7:9] == ["A-5", "i"]
    ops.split_pdf(src, str(tmp_path / "sp"), mode="ranges", ranges="3-6")
    part = next((tmp_path / "sp").glob("*.pdf"))
    assert labels(str(part)) == ["iii", "A-1", "A-2", "A-3"]


def test_replace_text(doc_path, tmp_path):
    out = str(tmp_path / "r.pdf"); st = {}
    advanced.replace_text(doc_path, out, "Ravi Kumar", "Anil Sharma", stats=st)
    with pymupdf.open(out) as d:
        assert st["replaced"] == 4 and "Anil Sharma" in d[0].get_text() and "Ravi" not in d[0].get_text()
    with pytest.raises(ops.PDFError):
        advanced.replace_text(doc_path, out, "nothing like this", "x")
    with pytest.raises(ops.PDFError):
        advanced.replace_text(doc_path, out, "RAVI", "x", match_case=True)


def test_replace_text_non_latin(doc_path, tmp_path):
    out = str(tmp_path / "h.pdf")
    advanced.replace_text(doc_path, out, "Invoice", "रसीद", pages="1")
    with pymupdf.open(out) as d:
        assert d[0].get_images() and "Invoice" not in d[0].get_text()


def test_redact_really_removes(doc_path, tmp_path):
    out = str(tmp_path / "x.pdf"); st = {}
    advanced.redact_text(doc_path, out, ["Ravi Kumar"], ["email", "pan", "aadhaar"], stats=st)
    with pymupdf.open(out) as d:
        text = "".join(p.get_text() for p in d)
    for secret in ("Ravi", "example.com", "ABCDE1234F", "5678"):
        assert secret not in text
    assert "Invoice" in text and st["redacted"] == 16
    with pytest.raises(ops.PDFError):
        advanced.redact_text(doc_path, out, ["zzzz"])
    with pytest.raises(ops.PDFError):
        advanced.redact_text(doc_path, out)


def test_remove_blank_pages(doc_path, tmp_path):
    out = str(tmp_path / "b.pdf"); st = {}
    advanced.remove_blank_pages(doc_path, out, stats=st)
    assert st["removed"] == [5] and ops.pdf_info(out)["pages"] == 4


def test_bookmarks_roundtrip(doc_path, tmp_path):
    out = str(tmp_path / "bm.pdf")
    advanced.set_bookmarks(doc_path, out, "Part A | 1\n  Chapter 1 | 2\nPart B | 4")
    with pymupdf.open(out) as d:
        assert d.get_toc() == [[1, "Part A", 1], [2, "Chapter 1", 2], [1, "Part B", 4]]
    assert advanced.get_bookmarks_text(out).splitlines()[1] == "  Chapter 1 | 2"
    with pytest.raises(ops.PDFError):
        advanced.set_bookmarks(doc_path, out, "Bad | 99")
    with pytest.raises(ops.PDFError):
        advanced.set_bookmarks(doc_path, out, "no page here")
    cleared = str(tmp_path / "c.pdf")
    advanced.set_bookmarks(out, cleared, "", clear=True)
    with pymupdf.open(cleared) as d:
        assert d.get_toc() == []


def test_page_labels_tool(doc_path, tmp_path):
    out = str(tmp_path / "pl.pdf")
    advanced.set_page_labels(doc_path, out, 2, "r")
    assert labels(out) == ["1", "i", "ii", "iii", "iv"]
    advanced.set_page_labels(out, str(tmp_path / "pl2.pdf"), 4, "A", "App-", 1)
    assert labels(str(tmp_path / "pl2.pdf"))[3:] == ["App-A", "App-B"]


@pytest.mark.skipif(not advanced.tessdata_dir() or "eng" not in advanced.ocr_languages(), reason="no OCR data")
def test_ocr_makes_scan_searchable(tmp_path):
    t = pymupdf.open(); pg = t.new_page(); pg.insert_text((72, 100), "Scanned OCR test 2026", fontsize=28)
    pix = pg.get_pixmap(dpi=150)
    s = pymupdf.open(); ip = s.new_page(width=pg.rect.width, height=pg.rect.height); ip.insert_image(ip.rect, pixmap=pix)
    src = str(tmp_path / "scan.pdf"); s.save(src)
    out = str(tmp_path / "ocr.pdf"); st = {}
    advanced.ocr_pdf(src, out, "eng", stats=st)
    with pymupdf.open(out) as d:
        assert "OCR test" in d[0].get_text() and st["recognised"] == 1
    with pytest.raises(ops.PDFError):          # already has text -> nothing to do
        advanced.ocr_pdf(out, str(tmp_path / "again.pdf"), "eng")
    with pytest.raises(ops.PDFError):
        advanced.ocr_pdf(src, out + "2", "xx_missing")


def test_fill_form_and_highlight(tmp_path):
    d = pymupdf.open(); pg = d.new_page(); pg.insert_text((72, 80), "Name and agree here, name twice", fontsize=12)
    for name, typ, rect in (("full_name", pymupdf.PDF_WIDGET_TYPE_TEXT, (72, 100, 250, 120)),
                            ("agree", pymupdf.PDF_WIDGET_TYPE_CHECKBOX, (72, 140, 90, 158))):
        wd = pymupdf.Widget(); wd.field_name, wd.field_type, wd.rect = name, typ, pymupdf.Rect(rect)
        pg.add_widget(wd)
    src = str(tmp_path / "f.pdf"); d.save(src)
    text = advanced.get_form_text(src)
    assert "full_name =" in text and "agree = No" in text
    out = str(tmp_path / "ff.pdf"); st = {}
    advanced.fill_form(src, out, "full_name = Asha Rao\nagree = Yes\nghost = 1", stats=st)
    assert st["filled"] == 2 and st["missing"] == ["ghost"]
    with pymupdf.open(out) as r:
        vals = {w.field_name: w.field_value for w in r[0].widgets()}
    assert vals["full_name"] == "Asha Rao" and vals["agree"] not in ("Off", False, None, "")
    flat = str(tmp_path / "flat.pdf")
    advanced.fill_form(src, flat, "full_name = Asha Rao", flatten=True)
    with pymupdf.open(flat) as r:
        assert not list(r[0].widgets() or []) and "Asha Rao" in r[0].get_text()
    with pytest.raises(ops.PDFError):
        advanced.fill_form(src, out, "nope = 1")
    marked = str(tmp_path / "m.pdf"); st = {}
    advanced.highlight_text(src, marked, ["name"], "underline", pages="1", stats=st)
    assert st["marked"] == 2
    with pymupdf.open(marked) as r:
        assert len(list(r[0].annots())) == 2
    with pytest.raises(ops.PDFError):
        advanced.highlight_text(src, marked, ["zzz"])


pyhanko = pytest.importorskip("pyhanko")


def test_sign_and_verify(doc_path, tmp_path):
    cert = advanced.create_certificate(tmp_path / "me.p12", "Test User", "secret1", org="Org")
    out = str(tmp_path / "signed.pdf")
    advanced.sign_pdf(doc_path, out, cert, "secret1", reason="Approved", page=1)
    s = advanced.verify_signatures(out)
    assert len(s) == 1 and s[0]["valid"] and s[0]["whole_file"] and "Test User" in s[0]["signer"]
    with pymupdf.open(out) as d:                      # still a normal readable PDF
        assert d.page_count == 5
    raw = bytearray(Path(out).read_bytes()); raw[200] ^= 1
    bad = tmp_path / "bad.pdf"; bad.write_bytes(bytes(raw))
    assert not advanced.verify_signatures(str(bad))[0]["intact"]
    with pytest.raises(ops.PDFError):
        advanced.sign_pdf(doc_path, str(tmp_path / "w.pdf"), cert, "wrong", page=1)
    with pytest.raises(ops.PDFError):
        advanced.sign_pdf(doc_path, str(tmp_path / "w.pdf"), cert, "secret1", page=99)
    rep = str(tmp_path / "rep.txt"); advanced.verify_report(out, rep)
    assert "VALID" in Path(rep).read_text()
    plain = advanced.verify_signatures(doc_path)
    assert plain == []


def test_replace_text_on_rotated_and_cropped_pages(tmp_path):
    for rot, crop in ((90, None), (180, None), (270, None), (90, (50, 50, 400, 500))):
        d = pymupdf.open(); p = d.new_page(); p.insert_text((72, 100), "Hello World keep", fontsize=16)
        if rot:
            p.set_rotation(rot)
        if crop:
            p.set_cropbox(pymupdf.Rect(*crop))
        src = str(tmp_path / "s.pdf"); d.save(src)
        for repl in ("Bye", "रसीद"):
            out = str(tmp_path / "o.pdf")
            advanced.replace_text(src, out, "Hello", repl)
            with pymupdf.open(out) as r:
                pg = r[0]
                assert "Hello" not in pg.get_text()
                if repl == "Bye":      # real text, normal size (not shrunk to nothing), same reading direction
                    spans = [s for b in pg.get_text("dict")["blocks"] for l in b["lines"] for s in l["spans"]
                             if "Bye" in s["text"]]
                    assert spans and spans[0]["size"] > 10
                else:                  # picture placed where the old word was
                    hit = pymupdf.open(src)[0].search_for("Hello")[0]
                    xr = pg.get_images()[0][0]
                    img = pg.get_image_rects(xr)[0]
                    assert abs(img.x0 - hit.x0) < 6 and abs(img.y0 - hit.y0) < 6
