"""GUI tests (headless). Every panel is driven through its widgets and run."""
import os, sys
from pathlib import Path
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import pymupdf, pytest
from PIL import Image
from PySide6.QtCore import QPoint, Qt
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication

from test_ops import quad_pdf, render, at, close, pages_of, page_text, RED, GREEN, BLUE, YELLOW
from gui.main_window import MainWindow
from pdfkit import ops


@pytest.fixture(scope="module")
def app():
    return QApplication.instance() or QApplication([])


@pytest.fixture
def win(app, tmp_path):
    w = MainWindow(); w.show()
    src = quad_pdf(tmp_path / "doc.pdf", 6)
    assert w.open_file(src)
    app.processEvents()
    yield w
    w.close()


def run(win, key, tmp_path, name="res.pdf", folder=False):
    p = win.panels[key]
    assert p.validate() is None, p.validate()
    out = str(tmp_path / (name if not folder else "res_dir"))
    p.execute(win.path, out, None)
    return out


def test_every_panel_exists_and_has_title(win):
    assert len(win.panels) == 26
    assert all(p.title and p.group for p in win.panels.values())


def test_organise_panels(win, tmp_path):
    P = win.panels
    P["extract"].pages.setText("2-3"); assert pages_of(run(win, "extract", tmp_path)) == 2
    P["delete"].pages.setText("1"); assert pages_of(run(win, "delete", tmp_path)) == 5
    P["reorder"].order.setText("last-1")
    assert "Page number 6" in page_text(run(win, "reorder", tmp_path), 0)
    P["duplicate"].pages.setText("1"); assert pages_of(run(win, "duplicate", tmp_path)) == 7
    P["blank"].after.setText("0"); assert pages_of(run(win, "blank", tmp_path)) == 7
    P["rotate"].pages.setText("1"); r = run(win, "rotate", tmp_path)
    with pymupdf.open(r) as d: assert d[0].rotation == 90
    P["split"].mode.setCurrentIndex(1); P["split"].n.setValue(4)
    out = run(win, "split", tmp_path, folder=True)
    assert sorted(os.listdir(out)) and len(os.listdir(out)) == 2
    a, b = quad_pdf(tmp_path / "a.pdf", 1), quad_pdf(tmp_path / "b.pdf", 2)
    P["merge"].files.add_files([a, b])
    assert pages_of(run(win, "merge", tmp_path, "m.pdf")) == 3


def test_page_size_panels(win, tmp_path):
    P = win.panels
    P["crop"].unit.setCurrentText("%")
    P["crop"].spins[0].setValue(50)       # remove left half
    r = run(win, "crop", tmp_path)
    with pymupdf.open(r) as d: assert d[0].rect.width == pytest.approx(200, abs=1)
    assert close(at(render(r, 0), 0.5, 0.1), GREEN)
    P["cut"].cols.setValue(2); P["cut"].rows.setValue(1); P["cut"].pages.setText("1")
    assert pages_of(run(win, "cut", tmp_path)) == 7
    P["resize"].size_box.combo.setCurrentText("A5")
    with pymupdf.open(run(win, "resize", tmp_path)) as d:
        assert d[0].rect.width == pytest.approx(419.5, abs=1)
    P["resize"].size_box.combo.setCurrentText("Custom")
    P["resize"].size_box.unit.setCurrentText("in"); P["resize"].size_box.w.setValue(5); P["resize"].size_box.h.setValue(8)
    P["resize"].margin.setValue(0)
    with pymupdf.open(run(win, "resize", tmp_path)) as d:
        assert d[0].rect.width == pytest.approx(360, abs=1) and d[0].rect.height == pytest.approx(576, abs=1)
    P["scale"].pct.setValue(50)
    with pymupdf.open(run(win, "scale", tmp_path)) as d: assert d[0].rect.width == pytest.approx(200, abs=1)
    P["nup"].layout_box.setCurrentIndex(1); assert pages_of(run(win, "nup", tmp_path)) == 2
    P["nup"].layout_box.setCurrentIndex(5); P["nup"].cols.setValue(3); P["nup"].rows.setValue(1)
    assert pages_of(run(win, "nup", tmp_path)) == 2


def test_optimise_convert_panels(win, tmp_path):
    P = win.panels
    assert "smaller" in P["compress"].execute(win.path, str(tmp_path / "c.pdf"), None) or True
    P["compress"].custom.setChecked(True)
    P["compress"].execute(win.path, str(tmp_path / "c2.pdf"), None)
    assert pages_of(run(win, "raster", tmp_path)) == 6
    out = run(win, "toimg", tmp_path, folder=True); assert len(os.listdir(out)) == 6
    imgs = []
    for i, c in enumerate(("red", "blue")):
        f = tmp_path / f"i{i}.png"; Image.new("RGB", (50, 80), c).save(f); imgs.append(str(f))
    P["fromimg"].files.add_files(imgs)
    assert pages_of(run(win, "fromimg", tmp_path, "img.pdf")) == 2
    P["totext"].pages.setText("1")
    run(win, "totext", tmp_path, "t.txt")
    assert "Page number 1" in (tmp_path / "t.txt").read_text()
    P["extimg"].execute(win.path, str(tmp_path / "ei"), None)   # no images: must not crash


def test_stamp_security_panels(win, tmp_path):
    P = win.panels
    P["wmtext"].text.setCurrentText("DRAFT"); P["wmtext"].pages.setText("1")
    assert "DRAFT" in page_text(run(win, "wmtext", tmp_path), 0)
    logo = tmp_path / "logo.png"; Image.new("RGBA", (60, 30), (255, 0, 0, 255)).save(logo)
    P["wmimg"].image.edit.setText(str(logo)); P["wmimg"].opacity.setValue(100)
    P["wmimg"].pos_box.setCurrentText("bottom-right")
    assert pages_of(run(win, "wmimg", tmp_path)) == 6
    P["stamp"].preset.setCurrentIndex(1)
    assert "Page 6 of 6" in page_text(run(win, "stamp", tmp_path), 5)
    pr = P["protect"]
    pr.pw.setText("abc"); pr.pw2.setText("xyz"); assert pr.validate()
    pr.pw2.setText("abc"); assert pr.validate() is None
    enc = run(win, "protect", tmp_path, "enc.pdf")
    with pymupdf.open(enc) as d: assert d.needs_pass
    P["unlock"].pw.setText("abc")
    p = P["unlock"]; dec = str(tmp_path / "dec.pdf"); p.execute(enc, dec, None)
    with pymupdf.open(dec) as d: assert not d.needs_pass
    M = P["meta"]; M.on_activate(); M.fields["title"].setText("Hello")
    assert ops.pdf_info(run(win, "meta", tmp_path))["metadata"]["title"] == "Hello"
    run(win, "flatten", tmp_path)


def test_validation_messages(win):
    P = win.panels
    P["crop"].reset(); assert "margin" in P["crop"].validate()
    P["reorder"].order.setText(""); assert P["reorder"].validate()
    assert P["merge"].validate() and P["fromimg"].validate() and P["wmimg"].validate()


def test_crop_overlay_drag_updates_spins(win, app):
    win.tree.setCurrentItem(win.tree.topLevelItem(1).child(0))   # Crop
    crop = win.current_panel(); assert crop.key == "crop"
    app.processEvents()
    v = win.preview.view
    assert v.mode == "crop" and v.item is not None
    pr = v._page_rect()
    start = v.mapFromScene(pr.left(), pr.center().y())
    end = v.mapFromScene(pr.left() + pr.width() * 0.25, pr.center().y())
    QTest.mousePress(v.viewport(), Qt.LeftButton, Qt.NoModifier, start)
    QTest.mouseMove(v.viewport(), end)
    QTest.mouseRelease(v.viewport(), Qt.LeftButton, Qt.NoModifier, end)
    app.processEvents()
    assert v.margins[0] == pytest.approx(0.25, abs=0.03)
    mm = 0.25 * 400 / ops.MM
    assert crop.spins[0].value() == pytest.approx(mm, rel=0.12)
    # typing a value moves the overlay
    crop.spins[1].setValue(30)
    assert v.margins[1] == pytest.approx(ops.to_points(30, "mm") / 600, abs=0.01)
    win.tree.setCurrentItem(win.tree.topLevelItem(1).child(1))   # Cut
    assert v.mode == "grid"


def test_thumbnails_selection_feeds_page_field(win, app):
    for _ in range(40): app.processEvents()
    th = win.preview.thumbs
    assert th.count() == 6
    th.item(1).setSelected(True); th.item(2).setSelected(True); th.item(4).setSelected(True)
    pf = win.panels["extract"].pages
    pf._from_selection()
    assert pf.text() == "2-3,5"


def test_worker_thread_runs_and_cancel(win, app, tmp_path, monkeypatch):
    from PySide6.QtWidgets import QMessageBox
    monkeypatch.setattr(QMessageBox, "exec", lambda self: 0)
    p = win.panels["extract"]; p.pages.setText("1-2")
    out = str(tmp_path / "thr.pdf")
    win.start(p, win.path, out)
    for _ in range(200):
        app.processEvents(); QTest.qWait(10)
        if win.worker is None: break
    assert win.worker is None and pages_of(out) == 2
    # error path reaches the user (no crash)
    shown = []
    monkeypatch.setattr(win, "_failed", lambda m, d: shown.append(m))
    p.pages.setText("99")
    win.start(p, win.path, str(tmp_path / "bad.pdf"))
    for _ in range(200):
        app.processEvents(); QTest.qWait(10)
        if win.worker is None: break
    assert shown and "out of range" in shown[0]
    assert not (tmp_path / "bad.pdf").exists()


def test_protected_file_opens_with_password(app, tmp_path, monkeypatch):
    src = quad_pdf(tmp_path / "s.pdf", 2); enc = str(tmp_path / "e.pdf")
    ops.encrypt_pdf(src, enc, "pw")
    w = MainWindow()
    monkeypatch.setattr("gui.main_window.QInputDialog.getText", lambda *a, **k: ("pw", True))
    assert w.open_file(enc) and w.page_count() == 2
    w.close()
