"""GUI tests (headless). Every panel is driven through its widgets and run."""
import os, sys
from pathlib import Path
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import pymupdf, pytest
from imgutil import make_image
from PySide6.QtCore import QPoint, Qt
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication

from test_ops import quad_pdf, render, at, close, pages_of, page_text, RED, GREEN, BLUE, YELLOW
from gui.main_window import MainWindow
from pdfkit import ops


@pytest.fixture(scope="module")
def app():
    return QApplication.instance() or QApplication([])


@pytest.fixture
def win(app, tmp_path):
    w = MainWindow(); w.show()
    src = quad_pdf(tmp_path / "doc.pdf", 6)
    assert w.open_file(src)
    app.processEvents()
    yield w
    w.close()


def run(win, key, tmp_path, name="res.pdf", folder=False):
    p = win.panels[key]
    assert p.validate() is None, p.validate()
    out = str(tmp_path / (name if not folder else "res_dir"))
    p.execute(win.path, out, None)
    return out


def test_every_panel_exists_and_has_title(win):
    assert len(win.panels) == 37
    assert all(p.title and p.group for p in win.panels.values())


def test_organise_panels(win, tmp_path):
    P = win.panels
    P["extract"].pages.setText("2-3"); assert pages_of(run(win, "extract", tmp_path)) == 2
    P["delete"].pages.setText("1"); assert pages_of(run(win, "delete", tmp_path)) == 5
    P["reorder"].order.setText("last-1")
    assert "Page number 6" in page_text(run(win, "reorder", tmp_path), 0)
    P["duplicate"].pages.setText("1"); assert pages_of(run(win, "duplicate", tmp_path)) == 7
    P["blank"].after.setText("0"); assert pages_of(run(win, "blank", tmp_path)) == 7
    P["rotate"].pages.setText("1"); r = run(win, "rotate", tmp_path)
    with pymupdf.open(r) as d: assert d[0].rotation == 90
    P["split"].mode.setCurrentIndex(1); P["split"].n.setValue(4)
    out = run(win, "split", tmp_path, folder=True)
    assert sorted(os.listdir(out)) and len(os.listdir(out)) == 2
    a, b = quad_pdf(tmp_path / "a.pdf", 1), quad_pdf(tmp_path / "b.pdf", 2)
    P["merge"].files.add_files([a, b])
    assert pages_of(run(win, "merge", tmp_path, "m.pdf")) == 3


def test_page_size_panels(win, tmp_path):
    P = win.panels
    P["crop"].unit.setCurrentText("%")
    P["crop"].spins[0].setValue(50)       # remove left half
    r = run(win, "crop", tmp_path)
    with pymupdf.open(r) as d: assert d[0].rect.width == pytest.approx(200, abs=1)
    assert close(at(render(r, 0), 0.5, 0.1), GREEN)
    P["cut"].cols.setValue(2); P["cut"].rows.setValue(1); P["cut"].pages.setText("1")
    assert pages_of(run(win, "cut", tmp_path)) == 7
    P["resize"].size_box.combo.setCurrentText("A5")
    with pymupdf.open(run(win, "resize", tmp_path)) as d:
        assert d[0].rect.width == pytest.approx(419.5, abs=1)
    P["resize"].size_box.combo.setCurrentText("Custom")
    P["resize"].size_box.unit.setCurrentText("in"); P["resize"].size_box.w.setValue(5); P["resize"].size_box.h.setValue(8)
    P["resize"].margin.setValue(0)
    with pymupdf.open(run(win, "resize", tmp_path)) as d:
        assert d[0].rect.width == pytest.approx(360, abs=1) and d[0].rect.height == pytest.approx(576, abs=1)
    P["scale"].pct.setValue(50)
    with pymupdf.open(run(win, "scale", tmp_path)) as d: assert d[0].rect.width == pytest.approx(200, abs=1)
    P["nup"].layout_box.setCurrentIndex(1); assert pages_of(run(win, "nup", tmp_path)) == 2
    P["nup"].layout_box.setCurrentIndex(5); P["nup"].cols.setValue(3); P["nup"].rows.setValue(1)
    assert pages_of(run(win, "nup", tmp_path)) == 2


def test_optimise_convert_panels(win, tmp_path):
    P = win.panels
    assert "smaller" in P["compress"].execute(win.path, str(tmp_path / "c.pdf"), None) or True
    P["compress"].custom.setChecked(True)
    P["compress"].execute(win.path, str(tmp_path / "c2.pdf"), None)
    assert pages_of(run(win, "raster", tmp_path)) == 6
    out = run(win, "toimg", tmp_path, folder=True); assert len(os.listdir(out)) == 6
    imgs = []
    for i, c in enumerate(("red", "blue")):
        f = tmp_path / f"i{i}.png"; make_image(f, (50, 80), c); imgs.append(str(f))
    P["fromimg"].files.add_files(imgs)
    assert pages_of(run(win, "fromimg", tmp_path, "img.pdf")) == 2
    P["totext"].pages.setText("1")
    run(win, "totext", tmp_path, "t.txt")
    assert "Page number 1" in (tmp_path / "t.txt").read_text()
    P["extimg"].execute(win.path, str(tmp_path / "ei"), None)   # no images: must not crash


def test_stamp_security_panels(win, tmp_path):
    P = win.panels
    P["wmtext"].text.setCurrentText("DRAFT"); P["wmtext"].pages.setText("1")
    assert "DRAFT" in page_text(run(win, "wmtext", tmp_path), 0)
    logo = tmp_path / "logo.png"; make_image(logo, (60, 30), (255, 0, 0, 255))
    P["wmimg"].image.edit.setText(str(logo)); P["wmimg"].opacity.setValue(100)
    P["wmimg"].pos_box.setCurrentText("bottom-right")
    assert pages_of(run(win, "wmimg", tmp_path)) == 6
    P["stamp"].preset.setCurrentIndex(1)
    assert "Page 6 of 6" in page_text(run(win, "stamp", tmp_path), 5)
    pr = P["protect"]
    pr.pw.setText("abc"); pr.pw2.setText("xyz"); assert pr.validate()
    pr.pw2.setText("abc"); assert pr.validate() is None
    enc = run(win, "protect", tmp_path, "enc.pdf")
    with pymupdf.open(enc) as d: assert d.needs_pass
    P["unlock"].pw.setText("abc")
    p = P["unlock"]; dec = str(tmp_path / "dec.pdf"); p.execute(enc, dec, None)
    with pymupdf.open(dec) as d: assert not d.needs_pass
    M = P["meta"]; M.on_activate(); M.fields["title"].setText("Hello")
    assert ops.pdf_info(run(win, "meta", tmp_path))["metadata"]["title"] == "Hello"
    run(win, "flatten", tmp_path)


def test_validation_messages(win):
    P = win.panels
    P["crop"].reset(); assert "margin" in P["crop"].validate()
    P["reorder"].order.setText(""); assert P["reorder"].validate()
    assert P["merge"].validate() and P["fromimg"].validate() and P["wmimg"].validate()


def test_crop_overlay_drag_updates_spins(win, app):
    win.tree.setCurrentItem(win.tree.topLevelItem(1).child(0))   # Crop
    crop = win.current_panel(); assert crop.key == "crop"
    app.processEvents()
    v = win.preview.view
    assert v.mode == "crop" and v.item is not None
    pr = v._page_rect()
    start = v.mapFromScene(pr.left(), pr.center().y())
    end = v.mapFromScene(pr.left() + pr.width() * 0.25, pr.center().y())
    QTest.mousePress(v.viewport(), Qt.LeftButton, Qt.NoModifier, start)
    QTest.mouseMove(v.viewport(), end)
    QTest.mouseRelease(v.viewport(), Qt.LeftButton, Qt.NoModifier, end)
    app.processEvents()
    assert v.margins[0] == pytest.approx(0.25, abs=0.03)
    mm = 0.25 * 400 / ops.MM
    assert crop.spins[0].value() == pytest.approx(mm, rel=0.12)
    # typing a value moves the overlay
    crop.spins[1].setValue(30)
    assert v.margins[1] == pytest.approx(ops.to_points(30, "mm") / 600, abs=0.01)
    win.tree.setCurrentItem(win.tree.topLevelItem(1).child(1))   # Cut
    assert v.mode == "grid"


def test_thumbnails_selection_feeds_page_field(win, app):
    for _ in range(40): app.processEvents()
    th = win.preview.thumbs
    assert th.count() == 6
    th.item(1).setSelected(True); th.item(2).setSelected(True); th.item(4).setSelected(True)
    pf = win.panels["extract"].pages
    pf._from_selection()
    assert pf.text() == "2-3,5"


def test_worker_thread_runs_and_cancel(win, app, tmp_path, monkeypatch):
    from PySide6.QtWidgets import QMessageBox
    monkeypatch.setattr(QMessageBox, "exec", lambda self: 0)
    p = win.panels["extract"]; p.pages.setText("1-2")
    out = str(tmp_path / "thr.pdf")
    win.start(p, win.path, out)
    for _ in range(200):
        app.processEvents(); QTest.qWait(10)
        if win.worker is None: break
    assert win.worker is None and pages_of(out) == 2
    # error path reaches the user (no crash)
    shown = []
    monkeypatch.setattr(win, "_failed", lambda m, d: shown.append(m))
    p.pages.setText("99")
    win.start(p, win.path, str(tmp_path / "bad.pdf"))
    for _ in range(200):
        app.processEvents(); QTest.qWait(10)
        if win.worker is None: break
    assert shown and "out of range" in shown[0]
    assert not (tmp_path / "bad.pdf").exists()


def test_protected_file_opens_with_password(app, tmp_path, monkeypatch):
    src = quad_pdf(tmp_path / "s.pdf", 2); enc = str(tmp_path / "e.pdf")
    ops.encrypt_pdf(src, enc, "pw")
    w = MainWindow()
    monkeypatch.setattr("gui.main_window.QInputDialog.getText", lambda *a, **k: ("pw", True))
    assert w.open_file(enc) and w.page_count() == 2
    w.close()


def test_no_panel_is_wider_than_its_pane(win, app):
    """Regression: long combo items / button rows used to force a horizontal
    scrollbar and clip controls."""
    too_wide = {k: p.minimumSizeHint().width() for k, p in win.panels.items()
                if p.minimumSizeHint().width() > 400}
    assert not too_wide, too_wide


# ------------------------------------------------ thread safety / locking / errors
import threading
from PySide6.QtCore import QObject
from PySide6.QtWidgets import QWidget


def _contains_qt(obj, seen=None):
    seen = seen if seen is not None else set()
    if id(obj) in seen:
        return False
    seen.add(id(obj))
    if isinstance(obj, (QObject, QWidget)):
        return True
    if isinstance(obj, dict):
        return any(_contains_qt(v, seen) for v in obj.values())
    if isinstance(obj, (list, tuple, set)):
        return any(_contains_qt(v, seen) for v in obj)
    if hasattr(obj, "__dict__"):
        return any(_contains_qt(v, seen) for v in vars(obj).values())
    return False


def _fill_valid_inputs(win, tmp_path):
    P = win.panels
    P["extract"].pages.setText("1-2"); P["delete"].pages.setText("1"); P["reorder"].order.setText("3,1,2")
    P["blank"].after.setText("1"); P["crop"].spins[0].setValue(10); P["split"].mode.setCurrentIndex(1)
    P["merge"].files.add_files([win.path, win.path])
    logo = make_image(tmp_path / "l.png", (40, 20), (255, 0, 0, 255))
    P["wmimg"].image.edit.setText(logo); P["fromimg"].files.add_files([logo, make_image(tmp_path / "b.png", (40, 20), "blue")])
    P["protect"].pw.setText("pw"); P["protect"].pw2.setText("pw")
    P["wmtext"].text.setCurrentText("DRAFT")
    P["replace"].find.setText("Page"); P["replace"].repl.setText("Sheet")
    P["redact"].terms.setPlainText("Page"); P["highlight"].terms.setPlainText("Page")
    P["form"].fields.setPlainText("nothing = x")
    P["bookmarks"].text_.setPlainText("First | 1\n  Sub | 2")
    P["cert"].name.setText("Test"); P["cert"].pw.setText("secret"); P["cert"].pw2.setText("secret")
    from pdfkit import advanced
    cert = advanced.create_certificate(tmp_path / "c.p12", "Tester", "secret")
    P["sign"].cert.edit.setText(cert); P["sign"].pw.setText("secret")


def test_every_panel_runs_from_a_frozen_snapshot_in_a_plain_thread(win, tmp_path):
    """The worker must never touch Qt widgets: run each tool's job in a bare Python thread
    from a snapshot that contains no Qt object at all."""
    _fill_valid_inputs(win, tmp_path)
    enc = str(tmp_path / "enc.pdf"); ops.encrypt_pdf(win.path, enc, "pw"); ops.set_password(enc, "pw")
    for key, panel in win.panels.items():
        src = enc if key == "unlock" else win.path
        if key == "unlock":
            panel.pw.setText("pw")
        out = str(tmp_path / f"job_{key}" / {"text": "r.txt", "p12": "r.p12"}.get(panel.output, "r.pdf"))
        if panel.output == "folder":
            out = str(tmp_path / f"job_{key}")
        job = panel.make_job(src, out)
        assert not _contains_qt(job.__closure__ and [c.cell_contents for c in job.__closure__]), key
        result = {}
        def target():
            try:
                result["msg"] = job(None)
            except Exception as e:           # noqa: BLE001
                result["err"] = f"{type(e).__name__}: {e}"
        t = threading.Thread(target=target); t.start(); t.join(60)
        if key in ("ocr", "blank_rm", "form"):     # the sample pages have text / no blank page: a clear PDFError is right
            assert result.get("err", "").startswith("PDFError"), (key, result)
            continue
        assert "err" not in result, (key, result.get("err"))
        assert os.path.exists(out) and (panel.output != "folder" or os.listdir(out) or key == "extimg"), key


def test_snapshot_ignores_later_widget_changes(win, tmp_path):
    p = win.panels["extract"]
    p.pages.setText("2-3")
    job = p.make_job(win.path, str(tmp_path / "x.pdf"))
    p.pages.setText("1")                         # user edits the field after pressing Run
    job(None)
    assert pages_of(str(tmp_path / "x.pdf")) == 2


def test_workspace_is_locked_while_a_job_runs(win, app, tmp_path, monkeypatch):
    import time
    from PySide6.QtWidgets import QMessageBox
    monkeypatch.setattr(QMessageBox, "exec", lambda self: 0)
    monkeypatch.setattr(QMessageBox, "information", staticmethod(lambda *a, **k: 0))
    cls = type(win.panels["rotate"])
    monkeypatch.setattr(cls, "execute", lambda self, src, out, progress: time.sleep(0.4) or "ok")
    win.start(win.panels["rotate"], win.path, str(tmp_path / "r.pdf"))
    app.processEvents()
    assert not win.centralWidget().isEnabled() and win.cancel_btn.isEnabled() is True
    assert win.preview.thumbs._paused
    assert win.open_file(win.path) is False          # cannot swap the document under a running job
    for _ in range(100):
        app.processEvents(); QTest.qWait(10)
        if win.worker is None: break
    assert win.centralWidget().isEnabled() and not win.preview.thumbs._paused


def test_original_file_is_not_kept_open(win):
    fd_dir = "/proc/self/fd"
    if not os.path.isdir(fd_dir):
        pytest.skip("needs /proc (Linux)")
    held = [os.readlink(os.path.join(fd_dir, f)) for f in os.listdir(fd_dir) if os.path.islink(os.path.join(fd_dir, f))]
    assert os.path.abspath(win.path) not in held


def test_in_memory_open_and_large_file_fallback(tmp_path, monkeypatch):
    src = quad_pdf(tmp_path / "m.pdf", 2)
    with ops.open_pdf(src, in_memory=True) as d:
        assert d.page_count == 2 and d.name in ("", None)
    monkeypatch.setattr(ops, "MEMORY_LIMIT", 0)
    with ops.open_pdf(src, in_memory=True) as d:
        assert d.page_count == 2 and d.name.endswith("m.pdf")


def test_filesystem_errors_are_explained_not_dumped(win, app, tmp_path, monkeypatch):
    shown = []
    monkeypatch.setattr(win, "_failed", lambda m, d: shown.append((m, d)))
    p = win.panels["extract"]; p.pages.setText("1")
    blocker = tmp_path / "iamafile"; blocker.write_text("x")
    win.start(p, win.path, str(blocker / "sub" / "out.pdf"))      # parent is a file -> OSError
    for _ in range(200):
        app.processEvents(); QTest.qWait(10)
        if win.worker is None: break
    assert shown and shown[0][1] == "" and "Cannot" in shown[0][0], shown


def test_hindi_watermark_through_the_gui_worker_without_choosing_a_font(win, app, tmp_path, monkeypatch):
    """Normal user flow: type Hindi text, press Run. A system font is picked automatically."""
    from PySide6.QtGui import QFontDatabase
    from PySide6.QtWidgets import QMessageBox
    if not QFontDatabase.families(QFontDatabase.WritingSystem.Devanagari):
        pytest.skip("no Devanagari font installed on this machine")
    monkeypatch.setattr(QMessageBox, "exec", lambda self: 0)
    p = win.panels["wmtext"]
    p.text.setCurrentText("हिन्दी भारत"); p.pages.setText("1")
    out = str(tmp_path / "hindi.pdf")
    shown = []
    monkeypatch.setattr(win, "_failed", lambda m, d: shown.append(m))
    win.start(p, win.path, out)
    for _ in range(300):
        app.processEvents(); QTest.qWait(10)
        if win.worker is None: break
    assert not shown, shown
    with pymupdf.open(out) as d:
        assert d[0].get_images()
