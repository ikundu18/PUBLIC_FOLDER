"""Engine tests. Run:  python -m pytest -q   (from the project folder)

PDFs are built with colour quadrants so every geometry operation can be
checked by looking at rendered pixels, not just "a file came out".
"""
import os
import sys
from pathlib import Path

import pymupdf
import pytest
from imgutil import Img, make_image, image_size, noise_jpg

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from pdfkit import ops  # noqa: E402

RED, GREEN, BLUE, YELLOW = (255, 0, 0), (0, 255, 0), (0, 0, 255), (255, 255, 0)


# ---------------------------------------------------------------- helpers
def quad_pdf(path, pages=1, w=400, h=600, rotation=0, label=True):
    """Page = 4 coloured quadrants: TL red, TR green, BL blue, BR yellow."""
    doc = pymupdf.open()
    for n in range(pages):
        p = doc.new_page(width=w, height=h)
        p.draw_rect((0, 0, w / 2, h / 2), fill=(1, 0, 0), color=None)
        p.draw_rect((w / 2, 0, w, h / 2), fill=(0, 1, 0), color=None)
        p.draw_rect((0, h / 2, w / 2, h), fill=(0, 0, 1), color=None)
        p.draw_rect((w / 2, h / 2, w, h), fill=(1, 1, 0), color=None)
        if label:
            p.insert_text((10, h / 2), f"Page number {n + 1}", fontsize=14, color=(1, 1, 1))
        if rotation:
            p.set_rotation(rotation)
    doc.save(path)
    doc.close()
    return str(path)


def render(path, page=0, dpi=36):
    with pymupdf.open(str(path)) as d:
        pix = d[page].get_pixmap(dpi=dpi, alpha=False)
        return Img(pix)


def at(img, fx, fy):
    """Colour at fractional position (0..1, 0..1) of the image."""
    return img.getpixel((min(int(fx * img.width), img.width - 1),
                         min(int(fy * img.height), img.height - 1)))


def close(c, ref, tol=40):
    return all(abs(a - b) <= tol for a, b in zip(c, ref))


def pages_of(path):
    with pymupdf.open(str(path)) as d:
        return d.page_count


def page_text(path, i):
    with pymupdf.open(str(path)) as d:
        return d[i].get_text()


@pytest.fixture
def src(tmp_path):
    return quad_pdf(tmp_path / "src.pdf", pages=6)


@pytest.fixture
def out(tmp_path):
    return str(tmp_path / "out.pdf")


# ------------------------------------------------------------ page parser
def test_parse_pages():
    p = ops.parse_pages
    assert p("all", 5) == [0, 1, 2, 3, 4]
    assert p("", 3) == [0, 1, 2]
    assert p("1-3,5", 6) == [0, 1, 2, 4]
    assert p("odd", 5) == [0, 2, 4]
    assert p("even", 5) == [1, 3]
    assert p("4-last", 6) == [3, 4, 5]
    assert p("3-", 5) == [2, 3, 4]
    assert p("-2", 5) == [0, 1]
    assert p("5-3", 6) == [4, 3, 2]
    assert p("2,2,1", 4) == [1, 0]
    assert p("2,2,1", 4, unique=False) == [1, 1, 0]
    assert p("last", 7) == [6]
    for bad in ("0", "9", "abc", "1-2-3"):
        with pytest.raises(ops.PDFError):
            p(bad, 5)


# ------------------------------------------------------------ merge/split
def test_merge_with_bookmarks(tmp_path, out):
    a = quad_pdf(tmp_path / "a.pdf", 2)
    b = quad_pdf(tmp_path / "b.pdf", 3)
    ops.merge_pdfs([a, b], out, bookmarks=True)
    assert pages_of(out) == 5
    with pymupdf.open(out) as d:
        toc = d.get_toc()
    assert [t[1] for t in toc if t[0] == 1] == ["a", "b"]
    assert [t[2] for t in toc if t[0] == 1] == [1, 3]


def test_merge_refuses_to_overwrite_source(tmp_path):
    a = quad_pdf(tmp_path / "a.pdf", 2)
    with pytest.raises(ops.PDFError):
        ops.merge_pdfs([a], a)
    assert pages_of(a) == 2


def test_split_modes(src, tmp_path):
    d = tmp_path / "s"
    assert len(ops.split_pdf(src, d / "each", "each")) == 6
    files = ops.split_pdf(src, d / "every", "every", n=4)
    assert [pages_of(f) for f in files] == [4, 2]
    files = ops.split_pdf(src, d / "parts", "parts", parts=4)
    assert [pages_of(f) for f in files] == [2, 2, 1, 1]
    files = ops.split_pdf(src, d / "ranges", "ranges", ranges="1-2, 4, 5-last")
    assert [pages_of(f) for f in files] == [2, 1, 2]
    assert "Page number 4" in page_text(files[1], 0)
    # running again must not overwrite
    again = ops.split_pdf(src, d / "ranges", "ranges", ranges="1-2")
    assert again[0] not in files


def test_split_by_bookmarks(tmp_path):
    p = quad_pdf(tmp_path / "book.pdf", 6)
    with pymupdf.open(p) as d:
        d.set_toc([[1, "Intro", 1], [2, "sub", 2], [1, "Chapter: Two?", 4]])
        d.save(str(tmp_path / "book2.pdf"))
    files = ops.split_pdf(str(tmp_path / "book2.pdf"), tmp_path / "bm", "bookmarks")
    assert [pages_of(f) for f in files] == [3, 3]
    assert "Chapter_ Two" in os.path.basename(files[1])
    with pytest.raises(ops.PDFError):
        ops.split_pdf(p, tmp_path / "bm2", "bookmarks")


# -------------------------------------------------------- organise pages
def test_extract_delete_reorder_reverse_duplicate(src, out):
    ops.extract_pages(src, out, "2,4-5")
    assert pages_of(out) == 3 and "Page number 4" in page_text(out, 1)
    ops.delete_pages(src, out, "1,6")
    assert pages_of(out) == 4 and "Page number 2" in page_text(out, 0)
    ops.reorder_pages(src, out, "3,1,2")
    assert [("Page number %d" % n) in page_text(out, k)
            for k, n in enumerate((3, 1, 2))] == [True] * 3
    ops.reverse_pages(src, out)
    assert "Page number 6" in page_text(out, 0) and "Page number 1" in page_text(out, 5)
    ops.duplicate_pages(src, out, "2", copies=2)
    assert pages_of(out) == 8
    assert all("Page number 2" in page_text(out, k) for k in (1, 2, 3))
    with pytest.raises(ops.PDFError):
        ops.delete_pages(src, out, "all")


def test_duplicated_pages_are_independent(src, out, tmp_path):
    ops.duplicate_pages(src, out, "1")
    out2 = str(tmp_path / "rot.pdf")
    ops.rotate_pages(out, out2, "1", 90)
    with pymupdf.open(out2) as d:
        assert d[0].rotation == 90 and d[1].rotation == 0


def test_insert_blank(src, out):
    ops.insert_blank_pages(src, out, after="0,2", count=2)
    assert pages_of(out) == 10
    with pymupdf.open(out) as d:
        blank = [i for i in range(d.page_count) if not d[i].get_text().strip()]
    assert blank == [0, 1, 4, 5]
    assert page_text(out, 2).strip().startswith("Page number 1")


def test_rotate(src, out):
    ops.rotate_pages(src, out, "2-3", 90)
    with pymupdf.open(out) as d:
        assert [p.rotation for p in d] == [0, 90, 90, 0, 0, 0]
    ops.rotate_pages(src, out, "all", -90)
    with pymupdf.open(out) as d:
        assert {p.rotation for p in d} == {270}
    with pytest.raises(ops.PDFError):
        ops.rotate_pages(src, out, "all", 45)


# -------------------------------------------------------------- crop / cut
def test_crop_margins_mm_and_visual_check(src, out):
    # cut 25 % off the left and top by percent -> only BR quadrant-ish remains
    ops.crop_pages(src, out, "1", (50, 50, 0, 0), "%")
    with pymupdf.open(out) as d:
        assert d[0].rect.width == pytest.approx(200, abs=0.5)
        assert d[0].rect.height == pytest.approx(300, abs=0.5)
        assert d[1].rect.width == pytest.approx(400, abs=0.5)  # untouched page
    img = render(out, 0)
    assert close(at(img, 0.1, 0.1), YELLOW) and close(at(img, 0.9, 0.9), YELLOW)


def test_crop_points_all_sides(src, out):
    ops.crop_pages(src, out, "all", (10, 20, 30, 40), "pt")
    with pymupdf.open(out) as d:
        assert d[3].rect.width == pytest.approx(400 - 40, abs=0.5)
        assert d[3].rect.height == pytest.approx(600 - 60, abs=0.5)


def test_crop_twice_keeps_geometry(src, out, tmp_path):
    """Second crop on an already cropped page must trim the visible area."""
    mid = str(tmp_path / "mid.pdf")
    ops.crop_pages(src, mid, "1", (200, 300, 0, 0), "pt")      # BR quadrant
    ops.crop_pages(mid, out, "1", (0, 0, 100, 150), "pt")      # left half of BR
    with pymupdf.open(out) as d:
        assert d[0].rect.width == pytest.approx(100, abs=0.5)
        assert d[0].rect.height == pytest.approx(150, abs=0.5)
    img = render(out, 0)
    assert close(at(img, 0.5, 0.5), YELLOW) and close(at(img, 0.05, 0.05), YELLOW)
    assert close(at(img, 0.95, 0.95), YELLOW)


def test_crop_rotated_page(tmp_path, out):
    p = quad_pdf(tmp_path / "rot.pdf", 1, rotation=90)
    # rotated 90 cw: visual width 600 x height 400. Cut left 300 -> keep right half
    ops.crop_pages(p, out, "1", (300, 0, 0, 0), "pt")
    with pymupdf.open(out) as d:
        assert d[0].rect.width == pytest.approx(300, abs=0.5)
        assert d[0].rect.height == pytest.approx(400, abs=0.5)
    ref = render(p, 0)         # visual reference of full page
    got = render(out, 0)
    # right half of the reference should equal the crop (compare centre colours)
    assert close(at(got, 0.25, 0.25), at(ref, 0.75, 0.25))
    assert close(at(got, 0.25, 0.75), at(ref, 0.75, 0.75))


def test_crop_validation(src, out):
    with pytest.raises(ops.PDFError):
        ops.crop_pages(src, out, "1", (200, 0, 200, 0), "pt")
    with pytest.raises(ops.PDFError):
        ops.crop_pages(src, out, "1", (-1, 0, 0, 0), "pt")


def test_auto_crop(tmp_path, out):
    doc = pymupdf.open()
    p = doc.new_page(width=400, height=600)
    p.draw_rect((100, 200, 300, 400), fill=(0, 0, 0), color=None)
    doc.new_page()  # blank page must be skipped, not crash
    doc.save(tmp_path / "w.pdf")
    ops.crop_pages(str(tmp_path / "w.pdf"), out, "all", auto=True, padding=10)
    with pymupdf.open(out) as d:
        assert d[0].rect.width == pytest.approx(220, abs=8)
        assert d[0].rect.height == pytest.approx(220, abs=8)
        assert d[1].rect.width == pytest.approx(595, abs=2)   # blank untouched


def test_cut_pages_two_columns(src, out):
    ops.cut_pages(src, out, "1", cols=2, rows=1)
    assert pages_of(out) == 7
    with pymupdf.open(out) as d:
        assert d[0].rect.width == pytest.approx(200, abs=0.5)
        assert d[0].rect.height == pytest.approx(600, abs=0.5)
    left, right = render(out, 0), render(out, 1)
    assert close(at(left, 0.5, 0.1), RED) and close(at(left, 0.5, 0.9), BLUE)
    assert close(at(right, 0.5, 0.1), GREEN) and close(at(right, 0.5, 0.9), YELLOW)
    assert page_text(out, 2).strip().startswith("Page number 2")  # rest intact


def test_cut_pages_right_to_left_and_grid(src, out):
    ops.cut_pages(src, out, "1", cols=2, rows=2, right_to_left=True)
    assert pages_of(out) == 9
    cols = [at(render(out, k), 0.5, 0.5) for k in range(4)]
    assert close(cols[0], GREEN) and close(cols[1], RED)
    assert close(cols[2], YELLOW) and close(cols[3], BLUE)
    with pytest.raises(ops.PDFError):
        ops.cut_pages(src, out, "1", cols=1, rows=1)


def test_cut_rotated_and_cropped_source(tmp_path, out):
    p = quad_pdf(tmp_path / "rot.pdf", 1, rotation=90)
    ops.cut_pages(p, out, "1", cols=2, rows=1)
    ref = render(p, 0)
    a, b = render(out, 0), render(out, 1)
    assert close(at(a, 0.5, 0.5), at(ref, 0.25, 0.5)) and close(at(b, 0.5, 0.5), at(ref, 0.75, 0.5))
    # cut after a crop (page origin offset)
    mid = str(tmp_path / "mid.pdf")
    ops.crop_pages(quad_pdf(tmp_path / "q.pdf", 1), mid, "1", (200, 300, 0, 0), "pt")
    ops.cut_pages(mid, out, "1", cols=2, rows=1)
    assert close(at(render(out, 0), 0.5, 0.5), YELLOW)
    assert close(at(render(out, 1), 0.5, 0.5), YELLOW)


# ----------------------------------------------------- resize / scale / nup
def test_resize_fit_a4_portrait_and_orientation(tmp_path, out):
    p = quad_pdf(tmp_path / "q.pdf", 1, w=300, h=300)
    ops.resize_pages(p, out, "1", "A4", mode="fit")
    with pymupdf.open(out) as d:
        assert d[0].rect.width == pytest.approx(595.28, abs=0.5)
        assert d[0].rect.height == pytest.approx(841.89, abs=0.5)
    img = render(out, 0)
    assert close(at(img, 0.5, 0.05), (255, 255, 255))      # letterbox top
    assert close(at(img, 0.25, 0.42), RED)
    # landscape page keeps landscape target
    ls = quad_pdf(tmp_path / "ls.pdf", 1, w=600, h=300)
    ops.resize_pages(ls, out, "1", "A4")
    with pymupdf.open(out) as d:
        assert d[0].rect.width > d[0].rect.height
    ops.resize_pages(ls, out, "1", "A4", auto_orient=False)
    with pymupdf.open(out) as d:
        assert d[0].rect.width < d[0].rect.height


def test_resize_fill_and_stretch_and_custom(tmp_path, out):
    p = quad_pdf(tmp_path / "q.pdf", 1, w=400, h=400)
    ops.resize_pages(p, out, "1", (200, 100), "pt", mode="fill")
    with pymupdf.open(out) as d:
        assert (round(d[0].rect.width), round(d[0].rect.height)) == (200, 100)
    img = render(out, 0)
    # fill crops top/bottom of square: only the middle band remains
    assert close(at(img, 0.25, 0.1), RED) and close(at(img, 0.25, 0.9), BLUE)
    ops.resize_pages(p, out, "1", (200, 100), "mm", mode="stretch", margin=5)
    with pymupdf.open(out) as d:
        assert d[0].rect.width == pytest.approx(200 * ops.MM, abs=0.5)


def test_resize_only_selected_pages(src, out):
    ops.resize_pages(src, out, "2", "A5")
    with pymupdf.open(out) as d:
        assert d[1].rect.width == pytest.approx(419.5, abs=1)
        assert d[0].rect.width == pytest.approx(400, abs=0.5)
        assert d.page_count == 6


def test_scale(src, out):
    ops.scale_pages(src, out, "all", 50)
    with pymupdf.open(out) as d:
        assert d[0].rect.width == pytest.approx(200, abs=0.5)
    assert close(at(render(out, 0), 0.25, 0.25), RED)
    with pytest.raises(ops.PDFError):
        ops.scale_pages(src, out, "all", 1)


def test_resize_rotated_source(tmp_path, out):
    p = quad_pdf(tmp_path / "rot.pdf", 1, rotation=90)
    ops.scale_pages(p, out, "1", 100)
    ref, got = render(p, 0), render(out, 0)
    assert got.size == ref.size
    for fx, fy in ((0.25, 0.25), (0.75, 0.25), (0.25, 0.75), (0.75, 0.75)):
        assert close(at(got, fx, fy), at(ref, fx, fy))


def test_n_up(src, out):
    ops.n_up(src, out, cols=2, rows=1, size="A4", border=True)
    assert pages_of(out) == 3
    with pymupdf.open(out) as d:
        assert d[0].rect.width > d[0].rect.height
    ops.n_up(src, out, cols=2, rows=2, size="A4")
    assert pages_of(out) == 2


# --------------------------------------------------------------- compress
def make_heavy_pdf(path):
    import random
    random.seed(1)
    buf = path.with_suffix(".jpg")
    noise_jpg(buf)
    doc = pymupdf.open()
    for _ in range(3):
        p = doc.new_page(width=595, height=842)
        p.insert_image((20, 20, 575, 420), filename=str(buf))
        p.insert_text((50, 500), "hello compress", fontsize=20)
    doc.save(path)
    return str(path)


def test_compress_levels(tmp_path):
    heavy = make_heavy_pdf(tmp_path / "heavy.pdf")
    sizes = {}
    for level in ("light", "medium", "high", "extreme"):
        o = str(tmp_path / f"c_{level}.pdf")
        r = ops.compress_pdf(heavy, o, level)
        sizes[level] = r["after"]
        assert pages_of(o) == 3 and "hello compress" in page_text(o, 0)
        assert r["after"] <= r["before"]
    assert sizes["medium"] < sizes["light"]
    assert sizes["extreme"] < sizes["medium"]
    # custom
    r = ops.compress_pdf(heavy, str(tmp_path / "cc.pdf"), "medium", dpi=60, quality=30)
    assert r["after"] < sizes["medium"]


def test_compress_never_grows_file(src, out):
    r = ops.compress_pdf(src, out, "medium")
    assert r["after"] <= r["before"]
    assert pages_of(out) == 6


def test_rasterize_gray(src, out):
    ops.rasterize_pdf(src, out, dpi=60, gray=True)
    assert pages_of(out) == 6
    assert page_text(out, 0).strip() == ""
    px = at(render(out, 0), 0.25, 0.1)
    assert abs(px[0] - px[1]) < 6 and abs(px[1] - px[2]) < 6   # grey


# ---------------------------------------------------------------- convert
def test_pdf_to_images(src, tmp_path):
    for fmt in ("png", "jpg", "webp", "tiff", "bmp"):
        files = ops.pdf_to_images(src, tmp_path / fmt, fmt, dpi=50, pages="1-2")
        assert len(files) == 2
        assert image_size(files[0]) == (round(400 * 50 / 72), round(600 * 50 / 72)), fmt
    with pytest.raises(ops.PDFError):
        ops.pdf_to_images(src, tmp_path / "x", "gif")


def test_images_to_pdf(tmp_path, out):
    a, b, c, d = (tmp_path / n for n in ("a.png", "b.jpg", "c.webp", "d.png"))
    make_image(a, (300, 200), "red")
    make_image(b, (200, 300), "green")
    make_image(c, (100, 100), "blue")
    make_image(d, (100, 100), (0, 0, 255, 0))                    # fully transparent
    ops.images_to_pdf([a, b, c, d], out, "image", dpi=100)
    assert pages_of(out) == 4
    with pymupdf.open(out) as doc:
        assert doc[0].rect.width == pytest.approx(300 * 0.72, abs=0.5)
    assert close(at(render(out, 0), 0.5, 0.5), (255, 0, 0))
    assert close(at(render(out, 3), 0.5, 0.5), (255, 255, 255))  # transparent -> white
    ops.images_to_pdf([a, b], out, "A4", margin_mm=10)
    with pymupdf.open(out) as doc:
        assert doc[0].rect.width > doc[0].rect.height          # landscape image
        assert doc[1].rect.width < doc[1].rect.height
    with pytest.raises(ops.PDFError):
        ops.images_to_pdf([tmp_path / "missing.png"], out)


def test_text_and_image_extraction(src, tmp_path):
    res = ops.pdf_to_text(src, tmp_path / "t.txt", "1-2")
    txt = (tmp_path / "t.txt").read_text(encoding="utf-8")
    assert "Page number 1" in txt and "Page number 2" in txt and res["empty_pages"] == 0
    heavy = make_heavy_pdf(tmp_path / "heavy.pdf")
    files = ops.extract_images(heavy, tmp_path / "imgs")
    assert len(files) == 1 and image_size(files[0]) == (1600, 1200)


# -------------------------------------------------------- stamps / security
def test_text_watermark_diagonal_and_rotated_page(tmp_path, out):
    p = quad_pdf(tmp_path / "w.pdf", 1, label=False)
    white = tmp_path / "white.pdf"
    d = pymupdf.open(); d.new_page(width=400, height=600); d.save(white)
    ops.add_text_watermark(str(white), out, "DRAFT", fontsize=90, color="#000000",
                           opacity=1, angle=45)
    img = render(out, 0, dpi=72)
    def dark(x0, y0, x1, y1):
        return sum(1 for x in range(int(x0 * img.width), int(x1 * img.width), 2)
                   for y in range(int(y0 * img.height), int(y1 * img.height), 2)
                   if img.getpixel((x, y))[0] < 100)
    # text rises bottom-left -> top-right: lower-left & upper-right of the centre
    # contain ink, the opposite diagonal corners do not
    assert dark(0.3, 0.5, 0.5, 0.6) + dark(0.5, 0.4, 0.7, 0.5) > 50
    assert dark(0.05, 0.05, 0.3, 0.15) == 0 and dark(0.7, 0.85, 0.95, 0.95) == 0
    ops.add_text_watermark(str(white), out, "TILE", fontsize=30, tile=True, opacity=0.5)
    assert "TILE" in page_text(out, 0)
    # rotated page keeps its look, text appears upright for the viewer
    rp = quad_pdf(tmp_path / "rot.pdf", 1, rotation=90, label=False)
    ops.add_text_watermark(rp, out, "WM", fontsize=40, angle=0)
    with pymupdf.open(out) as doc:
        t = doc[0].get_text("dict")
    assert "WM" in doc_text(out)
    assert close(at(render(out, 0), 0.25, 0.25), at(render(rp, 0), 0.25, 0.25))


def doc_text(path):
    with pymupdf.open(path) as d:
        return "".join(p.get_text() for p in d)


def test_empty_watermark_text_is_rejected(src, out):
    with pytest.raises(ops.PDFError):
        ops.add_text_watermark(src, out, "   ")


def test_image_watermark(tmp_path, out):
    white = tmp_path / "white.pdf"
    d = pymupdf.open(); d.new_page(width=400, height=600); d.save(white)
    logo = tmp_path / "logo.png"
    make_image(logo, (100, 50), (255, 0, 0, 255))
    ops.add_image_watermark(str(white), out, logo, scale=0.5, opacity=1,
                            position="bottom-right", margin=10)
    img = render(out, 0)
    assert close(at(img, 0.8, 0.95), RED, 60)
    assert close(at(img, 0.1, 0.1), (255, 255, 255))
    ops.add_image_watermark(str(white), out, logo, scale=0.2, opacity=0.3, tile=True, angle=30)
    assert pages_of(out) == 1


def test_page_numbers_header_footer(src, out):
    ops.add_stamp(src, out, "Page {n} of {total}", "all", "bottom-right", start=1,
                  skip_first=True)
    assert "Page 1 of 6" not in page_text(out, 0)
    assert "Page 2 of 6" in page_text(out, 1) and "Page 6 of 6" in page_text(out, 5)
    ops.add_stamp(src, out, "{file} - {date}", "1", "top-center")
    assert "src.pdf" in page_text(out, 0)
    ops.add_stamp(src, out, "{n}", "3-4", position="top-left", start=10)
    assert "12" in page_text(out, 2) and "13" in page_text(out, 3)
    # position check: bottom-right text sits in the bottom-right corner
    with pymupdf.open(out) as d:
        pass
    ops.add_stamp(src, out, "XYZ", "1", "bottom-right")
    with pymupdf.open(out) as d:
        hit = d[0].search_for("XYZ")[0]
    assert hit.x0 > 300 and hit.y0 > 550


def test_stamp_on_rotated_page(tmp_path, out):
    p = quad_pdf(tmp_path / "rot.pdf", 1, rotation=90, label=False)
    ops.add_stamp(p, out, "FOOT", "1", "bottom-center")
    with pymupdf.open(out) as d:
        hit = d[0].search_for("FOOT")[0]
        r = d[0].rect
    assert hit.y0 > r.height * 0.85 and abs((hit.x0 + hit.x1) / 2 - r.width / 2) < 20


def test_encrypt_decrypt_roundtrip(src, tmp_path):
    enc, dec = str(tmp_path / "enc.pdf"), str(tmp_path / "dec.pdf")
    ops.encrypt_pdf(src, enc, "secret", allow_print=True, allow_copy=False)
    with pymupdf.open(enc) as d:
        assert d.needs_pass
        assert d.authenticate("secret")
        assert not (d.permissions & pymupdf.PDF_PERM_COPY)
        assert d.permissions & pymupdf.PDF_PERM_PRINT
    with pytest.raises(ops.PasswordRequired):
        ops.decrypt_pdf(enc, dec, "wrong")
    ops.decrypt_pdf(enc, dec, "secret")
    with pymupdf.open(dec) as d:
        assert not d.needs_pass and d.page_count == 6
    with pytest.raises(ops.PDFError):
        ops.decrypt_pdf(src, dec)          # not encrypted
    with pytest.raises(ops.PDFError):
        ops.encrypt_pdf(src, dec, "")


def test_operations_on_encrypted_pdf_use_remembered_password(src, tmp_path):
    enc = str(tmp_path / "enc.pdf")
    ops.encrypt_pdf(src, enc, "pw1")
    out = str(tmp_path / "ext.pdf")
    with pytest.raises(ops.PasswordRequired):
        ops.extract_pages(enc, out, "1")
    assert ops.needs_password(enc)
    ops.set_password(enc, "pw1")
    assert not ops.needs_password(enc)
    ops.extract_pages(enc, out, "1-2")
    with pymupdf.open(out) as d:
        assert not d.needs_pass and d.page_count == 2     # output is unprotected


def test_metadata_and_info(src, out, tmp_path):
    ops.set_metadata(src, out, title="My Title", author="Me", keywords="a,b")
    info = ops.pdf_info(out)
    assert info["metadata"]["title"] == "My Title" and info["metadata"]["author"] == "Me"
    assert info["pages"] == 6 and info["page_sizes"] == {(400, 600): 6}
    out2 = str(tmp_path / "clean.pdf")
    ops.set_metadata(out, out2, clear_all=True)
    meta = ops.pdf_info(out2)["metadata"]
    assert not meta.get("title") and not meta.get("author")


def test_flatten_form(tmp_path, out):
    doc = pymupdf.open()
    p = doc.new_page()
    w = pymupdf.Widget()
    w.field_type = pymupdf.PDF_WIDGET_TYPE_TEXT
    w.field_name = "name"
    w.field_value = "Flatten me"
    w.rect = pymupdf.Rect(50, 50, 250, 80)
    p.add_widget(w)
    doc.save(tmp_path / "form.pdf")
    assert ops.pdf_info(str(tmp_path / "form.pdf"))["has_form"]
    ops.flatten_pdf(str(tmp_path / "form.pdf"), out)
    assert not ops.pdf_info(out)["has_form"]


# ------------------------------------------------------------- robustness
def test_bad_inputs(tmp_path, out):
    bad = tmp_path / "bad.pdf"
    bad.write_bytes(b"this is not a pdf")
    txt = tmp_path / "x.txt"
    txt.write_text("hi")
    with pytest.raises(ops.PDFError):
        ops.extract_pages(str(bad), out, "1")
    with pytest.raises(ops.PDFError):
        ops.extract_pages(str(tmp_path / "nope.pdf"), out, "1")
    with pytest.raises(ops.PDFError):
        ops.extract_pages(str(txt), out, "1")


def test_cancel_leaves_no_partial_output(src, out):
    def cancel(done, total):
        raise ops.Cancelled()
    with pytest.raises(ops.Cancelled):
        ops.rotate_pages(src, out, "all", 90, progress=cancel)
    assert not os.path.exists(out) and not os.path.exists(out + ".part")


def test_progress_reaches_total(src, out):
    seen = []
    ops.rotate_pages(src, out, "all", 90, progress=lambda d, t: seen.append((d, t)))
    assert seen[-1] == (6, 6)


def test_output_is_valid_after_every_operation(src, tmp_path):
    """Smoke: reopen results and render every page."""
    o = str(tmp_path / "o.pdf")
    for fn in (lambda: ops.cut_pages(src, o, "all", 2, 2),
               lambda: ops.n_up(src, o, 3, 3),
               lambda: ops.scale_pages(src, o, "all", 200),
               lambda: ops.add_stamp(src, o, "{n}")):
        fn()
        with pymupdf.open(o) as d:
            for pg in d:
                pg.get_pixmap(dpi=20)


# ------------------------------------------- regressions: annotations & links
def annotated_pdf(path, cropped=False):
    d = pymupdf.open()
    p = d.new_page(width=400, height=600)
    p.insert_text((50, 100), "LINKTEXT", fontsize=20)
    p.insert_link({"kind": pymupdf.LINK_URI, "from": pymupdf.Rect(45, 80, 200, 105),
                   "uri": "https://example.com"})
    a = p.add_rect_annot(pymupdf.Rect(40, 200, 200, 300))
    a.set_colors(stroke=(1, 0, 0), fill=(1, 0, 0)); a.update()
    w = pymupdf.Widget()
    w.field_type = pymupdf.PDF_WIDGET_TYPE_TEXT
    w.field_name, w.field_value = "f", "FIELDVAL"
    w.rect = pymupdf.Rect(40, 400, 300, 430)
    p.add_widget(w)
    if cropped:
        p.set_cropbox(pymupdf.Rect(20, 30, 400, 600))
    d.save(path)
    return str(path)


def red_pixels(path, page=0):
    img = render(path, page)
    return sum(1 for px in img.pixels() if px[0] > 200 and px[1] < 60 and px[2] < 60)


@pytest.mark.parametrize("op", ["scale", "resize", "nup", "cut"])
def test_annotations_and_form_values_survive(tmp_path, out, op):
    p = annotated_pdf(tmp_path / "ann.pdf")
    {"scale": lambda: ops.scale_pages(p, out, "all", 80),
     "resize": lambda: ops.resize_pages(p, out, "all", "A5"),
     "nup": lambda: ops.n_up(p, out, 2, 1),
     "cut": lambda: ops.cut_pages(p, out, "all", 1, 2)}[op]()
    with pymupdf.open(out) as d:
        total_red = sum(red_pixels(out, i) for i in range(d.page_count))
        text = "".join(pg.get_text() for pg in d)
    assert total_red > 300, "red annotation vanished"
    assert "FIELDVAL" in text, "form value vanished"


@pytest.mark.parametrize("cropped", [False, True])
@pytest.mark.parametrize("op", ["scale", "resize", "nup"])
def test_web_links_are_carried_and_land_on_text(tmp_path, out, op, cropped):
    p = annotated_pdf(tmp_path / "ann.pdf", cropped)
    {"scale": lambda: ops.scale_pages(p, out, "all", 150),
     "resize": lambda: ops.resize_pages(p, out, "all", "A4"),
     "nup": lambda: ops.n_up(p, out, 2, 1)}[op]()
    with pymupdf.open(out) as d:
        links = [l for l in d[0].get_links() if l["kind"] == pymupdf.LINK_URI]
        assert links and links[0]["uri"] == "https://example.com"
        hit = d[0].search_for("LINKTEXT")[0]
        assert pymupdf.Rect(links[0]["from"]).intersects(hit)


def test_cut_carries_link_into_the_right_piece(tmp_path, out):
    p = annotated_pdf(tmp_path / "ann.pdf")
    ops.cut_pages(p, out, "all", 1, 2)          # link is in the top half
    with pymupdf.open(out) as d:
        assert any(l["kind"] == pymupdf.LINK_URI for l in d[0].get_links())
        assert not any(l["kind"] == pymupdf.LINK_URI for l in d[1].get_links())


def test_rotated_page_with_annotation_keeps_look(tmp_path, out):
    p = annotated_pdf(tmp_path / "ann.pdf")
    with pymupdf.open(p) as d:
        d[0].set_rotation(90); d.save(str(tmp_path / "rot.pdf"))
    ops.scale_pages(str(tmp_path / "rot.pdf"), out, "all", 100)
    assert red_pixels(out) == pytest.approx(red_pixels(str(tmp_path / "rot.pdf")), rel=0.1)


def test_compress_of_protected_pdf_always_outputs_unprotected(src, tmp_path):
    enc, out = str(tmp_path / "enc.pdf"), str(tmp_path / "c.pdf")
    ops.encrypt_pdf(src, enc, "pw")
    ops.set_password(enc, "pw")
    ops.compress_pdf(enc, out, "light")      # tiny file: cannot shrink -> must not copy encrypted bytes
    with pymupdf.open(out) as d:
        assert not d.needs_pass and d.page_count == 6


# ------------------------------------------------ imaging without Pillow
def jpeg_with_exif_orientation(path, size=(300, 200), orientation=6):
    """Landscape JPEG (left half red, right half blue) carrying an EXIF
    orientation tag, built by hand (no image library)."""
    from PySide6.QtGui import QColor, QImage, QPainter
    img = QImage(size[0], size[1], QImage.Format_RGB32)
    img.fill(QColor("red"))
    p = QPainter(img); p.fillRect(size[0] // 2, 0, size[0] // 2, size[1], QColor("blue")); p.end()
    tmp = str(path) + ".plain.jpg"
    assert img.save(tmp, "JPEG", 95)
    raw = open(tmp, "rb").read()
    tiff = (b"MM\x00\x2a\x00\x00\x00\x08" + b"\x00\x01" +
            b"\x01\x12\x00\x03\x00\x00\x00\x01" + orientation.to_bytes(2, "big") + b"\x00\x00" +
            b"\x00\x00\x00\x00")
    seg = b"Exif\x00\x00" + tiff
    app1 = b"\xff\xe1" + (len(seg) + 2).to_bytes(2, "big") + seg
    open(path, "wb").write(raw[:2] + app1 + raw[2:])
    return str(path), tmp


def test_exif_rotation_is_applied(tmp_path, out):
    exif, plain = jpeg_with_exif_orientation(tmp_path / "phone.jpg")
    ops.images_to_pdf([exif], out, "image", dpi=72)
    with pymupdf.open(out) as d:
        assert d[0].rect.width == pytest.approx(200, abs=1)       # was 300 x 200
        assert d[0].rect.height == pytest.approx(300, abs=1)
    img = render(out, 0)
    # orientation 6 = rotate 90 deg clockwise: red (left) ends up on top, blue at the bottom
    assert close(at(img, 0.5, 0.1), RED, 60) and close(at(img, 0.5, 0.9), BLUE, 60)
    # same picture without the tag stays landscape
    ops.images_to_pdf([plain], out, "image", dpi=72)
    with pymupdf.open(out) as d:
        assert d[0].rect.width > d[0].rect.height


def test_plain_jpeg_is_embedded_byte_identical_and_png_losslessly(tmp_path, out):
    jp = noise_jpg(tmp_path / "n.jpg", (400, 300))
    pn = make_image(tmp_path / "p.png", (80, 60), "green")
    ops.images_to_pdf([jp, pn], out, "A4")
    with pymupdf.open(out) as d:
        jpeg_bytes = d.extract_image(d.get_page_images(0)[0][0])["image"]
    assert jpeg_bytes == open(jp, "rb").read()            # no re-compression, no quality loss
    assert close(at(render(out, 1), 0.5, 0.5), (0, 128, 0), 8)   # PNG pixels exact (Qt "green" = 0,128,0)


@pytest.mark.parametrize("ext", ["webp", "tif", "bmp"])
def test_other_image_formats_become_pages(tmp_path, out, ext):
    f = make_image(tmp_path / f"i.{ext}", (120, 80), "red", fmt=ext.upper() if ext != "tif" else "TIFF")
    ops.images_to_pdf([f], out, "image", dpi=72)
    assert close(at(render(out, 0), 0.5, 0.5), RED, 50)


def test_gif_is_readable(tmp_path, out):
    gif = tmp_path / "red.gif"          # hand-made 1x1 red GIF (Qt can read but not write GIF)
    gif.write_bytes(b"GIF89a\x01\x00\x01\x00\x80\x00\x00\xff\x00\x00\xff\xff\xff,"
                    b"\x00\x00\x00\x00\x01\x00\x01\x00\x00\x02\x02D\x01\x00;")
    ops.images_to_pdf([gif], out, "A4")
    assert close(at(render(out, 0), 0.5, 0.5), RED, 20)


def test_corrupt_and_missing_images_give_clear_errors(tmp_path, out):
    bad = tmp_path / "bad.png"; bad.write_bytes(b"not an image at all")
    with pytest.raises(ops.PDFError, match="bad.png"):
        ops.images_to_pdf([bad], out)
    with pytest.raises(ops.PDFError):
        ops.images_to_pdf([tmp_path / "ghost.png"], out)


def test_jpeg_quality_changes_file_size(tmp_path):
    heavy = make_heavy_pdf(tmp_path / "heavy.pdf")
    lo = ops.pdf_to_images(heavy, tmp_path / "lo", "jpg", dpi=60, pages="1", quality=15)[0]
    hi = ops.pdf_to_images(heavy, tmp_path / "hi", "jpg", dpi=60, pages="1", quality=95)[0]
    assert os.path.getsize(lo) < os.path.getsize(hi) * 0.7
    a = ops.rasterize_pdf(heavy, str(tmp_path / "r_lo.pdf"), dpi=60, quality=15)
    b = ops.rasterize_pdf(heavy, str(tmp_path / "r_hi.pdf"), dpi=60, quality=95)
    assert os.path.getsize(a) < os.path.getsize(b) * 0.7


def test_watermark_opacity_and_rotation(tmp_path, out):
    white = tmp_path / "white.pdf"
    d = pymupdf.open(); d.new_page(width=400, height=600); d.save(white)
    logo = make_image(tmp_path / "logo.png", (100, 50), (255, 0, 0, 255))
    ops.add_image_watermark(str(white), out, logo, scale=0.5, opacity=0.5, position="middle-center")
    px = at(render(out, 0), 0.5, 0.5)
    assert px[0] > 240 and 90 < px[1] < 170 and 90 < px[2] < 170          # half-transparent red on white
    ops.add_image_watermark(str(white), out, logo, scale=0.25, opacity=1, angle=90, position="middle-center")
    img = render(out, 0)
    # scale applies to the rotated picture: 100 pt wide x 200 pt tall, centred -> x 150-250, y 200-400
    assert close(at(img, 0.5, 0.40), RED, 60) and close(at(img, 0.5, 0.60), RED, 60)
    assert close(at(img, 0.2, 0.5), (255, 255, 255), 10) and close(at(img, 0.5, 0.1), (255, 255, 255), 10)
    with pytest.raises(ops.PDFError):
        ops.add_image_watermark(str(white), out, tmp_path / "ghost.png")


def test_auto_crop_bbox_is_exact_and_not_transposed(tmp_path, out):
    d = pymupdf.open(); p = d.new_page(width=400, height=600)
    p.draw_rect((50, 100, 150, 400), fill=(0, 0, 0), color=None)       # 100 wide x 300 tall
    d.save(tmp_path / "a.pdf")
    ops.crop_pages(str(tmp_path / "a.pdf"), out, "all", auto=True, padding=0)
    with pymupdf.open(out) as r:
        assert r[0].rect.width == pytest.approx(100, abs=8)
        assert r[0].rect.height == pytest.approx(300, abs=8)
        assert r[0].cropbox.x0 == pytest.approx(50, abs=8)
        assert r[0].cropbox.y0 == pytest.approx(100, abs=8)


# ----------------------------------------- shaped text for Indic / Arabic scripts
def find_indic_font():
    import glob
    for pattern in ("/usr/share/fonts/**/FreeSans.ttf", "/usr/share/fonts/**/NotoSansDevanagari*.ttf",
                    "/usr/share/fonts/**/Lohit-Devanagari*.ttf", "C:/Windows/Fonts/Nirmala.ttf",
                    "C:/Windows/Fonts/mangal.ttf", "/System/Library/Fonts/Supplemental/*Devanagari*.ttc",
                    "/Library/Fonts/*Devanagari*"):
        hits = glob.glob(pattern, recursive=True)
        if hits:
            return hits[0]
    return None


needs_font = pytest.mark.skipif(find_indic_font() is None, reason="no font with Devanagari/Bengali installed")
HINDI = "\u0915\u094d\u0937\u0924\u094d\u0930\u093f\u092f \u0939\u093f\u0928\u094d\u0926\u0940"   # kshatriya hindi


def white_pdf(path, w=420, h=200):
    d = pymupdf.open(); d.new_page(width=w, height=h); d.save(path); return str(path)


@needs_font
def test_hindi_text_is_shaped_not_letter_by_letter(tmp_path, out):
    font = find_indic_font()
    ops.add_text_watermark(white_pdf(tmp_path / "w.pdf"), out, HINDI, fontfile=font, fontsize=34,
                           angle=0, opacity=1, color="#000000")
    with pymupdf.open(out) as d:
        assert d[0].get_images(), "shaped text must be placed as a picture"
        # the picture is only as wide as the SHAPED text: a letter-by-letter writer is clearly wider
        naive = pymupdf.Font(fontfile=font).text_length(HINDI, fontsize=34)
        info = d[0].get_image_info()[0]
        assert info["bbox"][2] - info["bbox"][0] < naive * 0.92 + 2 * 34 * 0.2
    img = render(out, 0, dpi=72)
    dark = sum(1 for px in img.pixels() if px[0] < 120)
    assert dark > 200, "text is missing"


@needs_font
def test_bengali_page_numbers_and_mixed_text(tmp_path, out):
    font = find_indic_font()
    src = white_pdf(tmp_path / "\u0986\u09ae\u09be\u09b0 file.pdf")           # non-Latin file name too
    ops.add_stamp(src, out, "\u09aa\u09c3\u09b7\u09cd\u09a0\u09be {n} / {total} - {file}", fontfile=font,
                  fontsize=16, position="top-center")
    with pymupdf.open(out) as d:
        assert d[0].get_images()
        info = d[0].get_image_info()[0]["bbox"]
        assert info[1] < 60 and abs((info[0] + info[2]) / 2 - 210) < 40      # top-centre


@needs_font
def test_tiled_and_rotated_shaped_watermark(tmp_path, out):
    ops.add_text_watermark(white_pdf(tmp_path / "w.pdf", 400, 600), out, HINDI, fontfile=find_indic_font(),
                           fontsize=30, tile=True, angle=30, opacity=0.4)
    with pymupdf.open(out) as d:
        assert len(d[0].get_image_info()) > 3
    ops.add_text_watermark(white_pdf(tmp_path / "w.pdf", 400, 600), out, HINDI, fontfile=find_indic_font(),
                           fontsize=40, angle=45)
    assert pages_of(out) == 1


def test_latin_text_stays_real_selectable_text(tmp_path, out):
    ops.add_text_watermark(white_pdf(tmp_path / "w.pdf"), out, "DRAFT", fontsize=40)
    with pymupdf.open(out) as d:
        assert "DRAFT" in d[0].get_text() and not d[0].get_images()
    ops.add_stamp(white_pdf(tmp_path / "w.pdf"), out, "Page {n}")
    with pymupdf.open(out) as d:
        assert "Page 1" in d[0].get_text() and not d[0].get_images()


def test_missing_font_for_a_script_gives_a_clear_message(tmp_path, out, monkeypatch):
    from PySide6.QtGui import QFontDatabase
    monkeypatch.setattr(QFontDatabase, "families", staticmethod(lambda *a, **k: []))
    with pytest.raises(ops.PDFError, match="font"):
        ops.add_text_watermark(white_pdf(tmp_path / "w.pdf"), out, HINDI)
    with pytest.raises(ops.PDFError, match="font"):
        ops.add_stamp(white_pdf(tmp_path / "w.pdf"), out, HINDI + " {n}")


def test_bad_font_file_is_reported(tmp_path, out):
    bad = tmp_path / "bad.ttf"; bad.write_bytes(b"not a font")
    with pytest.raises(ops.PDFError):
        ops.add_text_watermark(white_pdf(tmp_path / "w.pdf"), out, HINDI, fontfile=str(bad))


@needs_font
def test_shaped_text_works_from_a_worker_thread(tmp_path):
    import threading
    res = {}
    def job():
        try:
            ops.add_text_watermark(white_pdf(tmp_path / "w.pdf"), str(tmp_path / "t.pdf"), HINDI,
                                   fontfile=find_indic_font(), fontsize=30)
            res["ok"] = True
        except Exception as e:      # noqa: BLE001
            res["err"] = repr(e)
    t = threading.Thread(target=job); t.start(); t.join(60)
    assert res.get("ok"), res


def test_font_choice_avoids_monospace_and_bitmap_fonts():
    from pdfkit.imaging import _font_rank
    families = ["FreeMono", "Unifont", "FreeSerif", "DejaVu Sans Mono", "FreeSans", "Noto Sans Devanagari"]
    assert min(families, key=_font_rank) == "Noto Sans Devanagari"
    assert min(["FreeMono", "FreeSerif", "FreeSans"], key=_font_rank) == "FreeSans"
    assert min(["Unifont", "FreeMono"], key=_font_rank) in ("FreeMono", "Unifont")   # last resort only
    assert _font_rank("Nirmala UI") < _font_rank("Courier New")


def test_attachments_survive_rebuild_tools(tmp_path):
    import pymupdf
    doc = pymupdf.open()
    for i in range(4):
        doc.new_page().insert_text((72, 72), f"p{i}")
    doc.embfile_add("a.txt", b"hello", filename="a.txt", ufilename="a.txt")
    src = tmp_path / "s.pdf"
    doc.save(str(src))
    jobs = {
        "extract": lambda o: ops.extract_pages(src, o, "1-2"),
        "resize": lambda o: ops.resize_pages(src, o, size="A5"),
        "cut": lambda o: ops.cut_pages(src, o),
        "nup": lambda o: ops.n_up(src, o),
        "raster": lambda o: ops.rasterize_pdf(src, o, dpi=40),
        "merge": lambda o: ops.merge_pdfs([src, src], o),
    }
    for name, job in jobs.items():
        out = tmp_path / f"{name}.pdf"
        job(out)
        with pymupdf.open(str(out)) as r:
            assert "a.txt" in r.embfile_names(), name
