# PDF Toolkit

An offline, all-in-one desktop PDF tool for Windows, macOS and Linux.
Your files never leave your computer, and **your original file is never overwritten** -
every tool writes a new file.

## Start it

| System  | How |
|---------|-----|
| Windows | Double-click **`Run_PDF_Toolkit.bat`** |
| macOS / Linux | Run **`./run_pdf_toolkit.sh`** in a terminal |

Needs **Python 3.9+** (https://www.python.org/downloads/ - on Windows tick *Add python.exe to PATH*).
The first start downloads the packages once (internet, ~1 minute); after that it starts instantly and works offline.

Manual start: `pip install -r requirements.txt` then `python main.py [file.pdf]`

**Want a real .exe / app with no Python needed?** Run `Build_Standalone_EXE.bat` (Windows) or
`./build_standalone.sh` (macOS/Linux). The finished program appears in the `dist/PDFToolkit` folder.

## How to use

1. **Open PDF** (button, `Ctrl+O`, or drag a file into the window). Pages appear as thumbnails and in the preview.
2. Pick a tool on the left, set the options, press **Run** (`Ctrl+Enter`), choose where to save.
3. Press **Continue editing this file** in the result dialog to chain tools (e.g. crop -> resize -> add page numbers).

**Page selections** (every "Pages" box): `all` · `1-3,7` · `odd` · `even` · `5-last` · `last-1` (reverse).
Select thumbnails (Ctrl/Shift-click) and press **Selected**, or press **Current** to use the page you are viewing.

## All tools

**Organise** - Merge (with bookmarks) · Split (every page / every N / equal parts / custom ranges / by bookmarks) ·
Extract · Delete · Reorder & reverse · Duplicate · Insert blank pages · Rotate

**Page size & cutting** - **Crop margins** (drag the orange edges on the preview, or type mm/cm/in/pt/%;
auto-crop white borders) · **Cut pages into pieces** (split double-page scans, 2/4/N pieces, right-to-left option) ·
**Resize** (A0-A6, B4/B5, Letter, Legal, Tabloid, custom; fit / fill / stretch) · Scale by % ·
Multiple pages per sheet (2-up, 4-up, 6-up, 9-up, custom)

**Optimise** - Compress (4 levels + custom DPI/quality, never makes a file bigger) · Flatten to images / grayscale

**Convert** - PDF -> PNG/JPG/WebP/TIFF/BMP · Images -> PDF · PDF -> text · Extract embedded images

**Watermark & numbers** - Text watermark (diagonal, tiled, colour, opacity) · Image/logo watermark ·
Page numbers, headers & footers (`{n}` `{total}` `{file}` `{date}`)

**Security & properties** - AES-256 password protect with permissions · Remove password ·
Edit/erase metadata · Flatten forms & comments

## Good to know

* **Crop** sets the visible page area, like Acrobat. The hidden part stays inside the file - use
  *Flatten to images* afterwards if it must be removed for good (e.g. before sharing).
* **Passwords:** a protected PDF asks for its password when opened; results are saved unprotected unless you use *Password protect*.
  A forgotten password cannot be recovered. This tool does not crack passwords.
* **Text in watermarks/numbers** uses a built-in Latin font. For Hindi, Bengali, Arabic, Chinese etc. pick a `.ttf`/`.otf`
  font file that supports the script in the "Font file" box - otherwise you get a clear message instead of garbage.
* Not included: OCR (making scans searchable), editing existing text, digital signatures.
* **Resize / scale / cut / multiple-per-sheet** burn highlights, comments and filled-in form fields into the page
  (they stay visible but are no longer editable) and keep web links. Links inside rotated pages are not carried over.
* **If something goes wrong** an error window appears and details are saved to `PDFToolkit_error.log` in your home folder.
* Very large files: work runs in the background and can be cancelled; nothing is written if you cancel.

## For developers

* `pdfkit/ops.py` - the whole PDF engine, no GUI code (usable from scripts).
* `gui/` - the PySide6 interface. `tests/` - 66 automated tests: `pip install pytest` then `python -m pytest -q`.

## License note

This program uses **PyMuPDF** (AGPL-3.0 / commercial) and **PySide6** (LGPL). Personal and internal use is fine.
If you distribute the app to others, you must comply with the AGPL (publish your source) or buy a PyMuPDF commercial licence.
