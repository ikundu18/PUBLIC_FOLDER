# PDF Toolkit

An offline, all-in-one desktop PDF tool for Windows, macOS and Linux.
Your files never leave your computer, and **your original file is never overwritten** -
every tool writes a new file.

## Start it

| System  | How |
|---------|-----|
| Windows | Double-click **`Run_PDF_Toolkit.bat`** |
| macOS / Linux | Run **`./run_pdf_toolkit.sh`** in a terminal |

Needs **Python 3.9+** (https://www.python.org/downloads/ - on Windows tick *Add python.exe to PATH*).
The first start downloads the packages once (internet, ~350 MB, a few minutes); after that it starts instantly and works offline.

Manual start: `pip install -r requirements.txt` then `python main.py [file.pdf]`

**Want a real .exe / app with no Python needed?** Run `Build_Standalone_EXE.bat` (Windows) or
`./build_standalone.sh` (macOS/Linux). The finished program appears in the `dist/PDFToolkit` folder.

## How to use

1. **Open PDF** (button, `Ctrl+O`, or drag a file into the window). Pages appear as thumbnails and in the preview.
2. Pick a tool on the left, set the options, press **Run** (`Ctrl+Enter`), choose where to save.
3. Press **Continue editing this file** in the result dialog to chain tools (e.g. crop -> resize -> add page numbers).

**Page selections** (every "Pages" box): `all` · `1-3,7` · `odd` · `even` · `5-last` · `last-1` (reverse).
Select thumbnails (Ctrl/Shift-click) and press **Picked**, or press **Page** to use the page you are viewing.

## All tools

**Organise** - Merge (with bookmarks) · Split (every page / every N / equal parts / custom ranges / by bookmarks) ·
Extract · Delete · Reorder & reverse · Duplicate · Insert blank pages · Rotate

**Page size & cutting** - **Crop margins** (drag the orange edges on the preview, or type mm/cm/in/pt/%;
auto-crop white borders) · **Cut pages into pieces** (split double-page scans, 2/4/N pieces, right-to-left option) ·
**Resize** (A0-A6, B4/B5, Letter, Legal, Tabloid, custom; fit / fill / stretch) · Scale by % ·
Multiple pages per sheet (2-up, 4-up, 6-up, 9-up, custom)

**Optimise** - Compress (4 levels + custom DPI/quality, never makes a file bigger) · Rasterize (pages → pictures / grayscale)

**Convert** - PDF -> PNG/JPG/WebP/TIFF/BMP · Images -> PDF · PDF -> text · Extract embedded images

**Watermark & numbers** - Text watermark (diagonal, tiled, colour, opacity) · Image/logo watermark ·
Page numbers, headers & footers (`{n}` `{total}` `{file}` `{date}`)

**Security & properties** - AES-256 password protect with permissions · Remove password ·
Edit/erase metadata · Flatten forms & comments

**Edit, OCR & sign** - OCR (English + Hindi included, more by adding language files) · Find & replace text · Redact ·
Highlight/underline · Fill form fields · Bookmarks · Page labels · Create certificate · Digital signature · Check signatures

(Also: Remove blank pages under *Organise*.)

## Documentation

Full manual in the **`docs/`** folder (setup, workflows, every tool, troubleshooting, developer guide) and as one file: `docs/PDF_Toolkit_User_Guide.html`. See `CHANGELOG.md`.

## Good to know

* **Crop** sets the visible page area, like Acrobat. The hidden part stays inside the file - use
  *Rasterize* afterwards if it must be removed for good (e.g. before sharing).
* **Passwords:** a protected PDF asks for its password when opened; results are saved unprotected unless you use *Password protect*.
  A forgotten password cannot be recovered. This tool does not crack passwords.
* **Text in watermarks/numbers:** Latin text is real PDF text. Hindi, Bengali, Tamil, Arabic, Chinese etc. are shaped correctly
  using an installed font (or pick a `.ttf`/`.otf` in the Font box) and placed as a sharp picture.
* Not included: word-processor style editing (re-flowing paragraphs), editing pictures, designing new forms, online eSign
  services. See `docs/07_Features_and_Limitations.md` for the full list.
* **Resize / scale / cut / multiple-per-sheet** burn highlights, comments and filled-in form fields into the page
  (they stay visible but are no longer editable) and keep links, bookmarks (where page numbers stay valid) and file attachments.
* **If something goes wrong** an error window appears and details are saved to `PDFToolkit_error.log` in your home folder.
* Very large files: work runs in the background and can be cancelled; nothing is written if you cancel.

## Dependencies

Packages: **PyMuPDF** (all PDF work, OCR), **PySide6-Essentials** (window + images), **pyHanko** (signatures), **tzdata**. No Pillow.
Supported image formats: PDF -> PNG, JPG, WebP, TIFF, BMP; Images -> PDF from JPG, PNG, WebP, TIFF, BMP, GIF
(phone-photo rotation is applied; plain JPEGs are embedded without any quality loss).
Python 3.9 - 3.13.

## For developers

* `pdfkit/ops.py` - the whole PDF engine, no GUI code (usable from scripts).
* `gui/` - the PySide6 interface. `tests/` - 104 automated tests: `pip install pytest` then `python -m pytest -q`.

## License note

This program uses **PyMuPDF** (AGPL-3.0 / commercial) and **PySide6** (LGPL). Personal and internal use is fine.
If you distribute the app to others, you must comply with the AGPL (publish your source) or buy a PyMuPDF commercial licence.
