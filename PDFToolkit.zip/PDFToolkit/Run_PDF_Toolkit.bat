@echo off
setlocal
cd /d "%~dp0"
title PDF Toolkit

rem --- find Python (py launcher first, then python) ---
set PY=
where py >nul 2>nul && set PY=py -3
if "%PY%"=="" where python >nul 2>nul && set PY=python
if "%PY%"=="" (
  echo Python 3.9 or newer was not found.
  echo Install it from https://www.python.org/downloads/  ^(tick "Add python.exe to PATH"^), then run this file again.
  pause
  exit /b 1
)

rem --- first run: create a private environment and install the packages ---
if not exist ".venv\Scripts\pythonw.exe" (
  echo First run: installing required packages. This needs internet and takes about a minute...
  %PY% -m venv .venv || goto :fail
  ".venv\Scripts\python.exe" -m pip install --upgrade pip >nul
  ".venv\Scripts\python.exe" -m pip install -r requirements.txt || goto :fail
)
start "" ".venv\Scripts\pythonw.exe" main.py %*
exit /b 0

:fail
echo.
echo Setup failed. Check your internet connection and try again.
rmdir /s /q .venv 2>nul
pause
exit /b 1
