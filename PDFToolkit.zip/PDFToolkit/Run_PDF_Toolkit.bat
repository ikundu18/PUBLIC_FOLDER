@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title PDF Toolkit

rem --- Is this folder usable? (running straight from inside a zip file does not work) ---
if not exist "main.py" (
  echo main.py was not found next to this file.
  echo Please EXTRACT the whole zip file first ^(right-click - Extract All^), then run this file again.
  pause
  exit /b 1
)

rem --- Already installed? start it right away ---
if exist ".venv\Scripts\pythonw.exe" goto :launch

rem --- find the best Python: py launcher (3.12 ... 3.9), then the newest 'py -3', then 'python' ---
set PY=
where py >nul 2>nul
if not errorlevel 1 (
  for %%V in (3.12 3.13 3.11 3.10 3.9) do (
    if not defined PY (
      py -%%V -c "import sys" >nul 2>nul
      if not errorlevel 1 set PY=py -%%V
    )
  )
  if not defined PY set PY=py -3
)
if not defined PY (
  where python >nul 2>nul
  if not errorlevel 1 set PY=python
)
if not defined PY goto :nopython

rem --- needs Python 3.9 or newer ---
%PY% -c "import sys; sys.exit(0 if sys.version_info[:2]>=(3,9) else 1)" >nul 2>nul
if errorlevel 1 goto :badversion

echo First run: installing the required packages ^(PyMuPDF, PySide6 and pyHanko, about 350 MB^).
echo This needs internet and takes a few minutes. Please wait...
%PY% -m venv .venv
if errorlevel 1 goto :fail
".venv\Scripts\python.exe" -m pip install --upgrade pip >nul 2>nul
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto :fail

rem --- upgrade of an older install: fetch packages added later (digital signatures) ---
:launch
".venv\Scripts\python.exe" -c "import pyhanko, tzdata" >nul 2>nul
if errorlevel 1 (
  echo Installing newly added packages ^(digital signatures^) - one moment...
  ".venv\Scripts\python.exe" -m pip install -r requirements.txt
)
start "" ".venv\Scripts\pythonw.exe" main.py %*
exit /b 0

:nopython
echo Python was not found.
echo Install Python 3.12 from https://www.python.org/downloads/  ^(tick "Add python.exe to PATH"^),
echo then run this file again.
pause
exit /b 1

:badversion
echo This program needs Python 3.9 or newer. Your version is:
%PY% --version
echo Please install Python 3.12 from https://www.python.org/downloads/ and run this file again.
pause
exit /b 1

:fail
echo.
echo Setup failed. Check your internet connection ^(or proxy / antivirus^) and try again.
echo If it keeps failing: install Python 3.12 from python.org, delete the ".venv" folder here, run this file again.
rmdir /s /q .venv 2>nul
pause
exit /b 1
