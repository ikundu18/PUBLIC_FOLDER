#!/usr/bin/env bash
# Builds a standalone app (dist/PDFToolkit) for the OS you run this on.
cd "$(dirname "$0")" || exit 1
PY=$(command -v python3 || command -v python)
[ -x .venv/bin/python ] || { "$PY" -m venv .venv && .venv/bin/python -m pip install -r requirements.txt; }
.venv/bin/python -m pip install pyinstaller && \
.venv/bin/python -m PyInstaller --noconfirm --windowed --name PDFToolkit --collect-all pymupdf --collect-all pyhanko --collect-all pyhanko_certvalidator --collect-all tzdata --add-data tessdata:tessdata main.py \
  && echo "Done: dist/PDFToolkit"
