# Changelog

## 1.2
* Fixed: Find & replace text on rotated pages (new text came out tiny or missing), non-Latin replacement misplaced on rotated pages with a crop box, text always shrunk to the old word's width (now only when it would overlap the next word); 3x faster on large documents.
* **New: OCR** (make scans searchable; English and Hindi data included, other languages by adding a file).
* **New: Find & replace text**, **Redact** (e-mail, phone, Aadhaar, PAN, card patterns), **Highlight / underline text**.
* **New: Digital signatures** - create a certificate, sign (visible or invisible), check signatures.
* **New: Fill form fields**, **Bookmarks editor**, **Page labels editor**, **Remove blank pages**.
* Fixed: page labels (i, ii, A-1 ...) are now kept by Extract, Delete, Reorder, Duplicate, Blank pages, Cut, Merge and Split.
* New documentation chapter 7: all features and honest limitations.
* Launchers install packages added since an older install. 104 tests.

## 1.1
* Fixed: file attachments were lost by Extract/Delete/Reorder/Duplicate, Resize, Scale, Cut, Pages per sheet, Rasterize and Merge.
* Fixed: page labels lost by Resize, Scale and Rasterize.
* Fixed: annotations/form fields and links lost on Resize, Scale, Cut, Pages per sheet; rotated pages mis-placed.
* Fixed: crop on already-cropped pages; text placement after rotation removal; owner/user password clash; decrypt detection.
* Fixed: password prompts and PyMuPDF/Qt calls from the worker thread (crashes); window locked during jobs; Cancel.
* Fixed: slow saves on large files; panels too wide; Hindi/Indic/Arabic text shaping and font choice.
* Fixed: launcher rejected newer Python; standalone-build script started the app.
* Changed: Pillow removed (Qt does image work); PyMuPDF pinned `<2`; PySide6-Essentials.
* Added: complete documentation (docs/), 93 tests.

## 1.0
* First release.
