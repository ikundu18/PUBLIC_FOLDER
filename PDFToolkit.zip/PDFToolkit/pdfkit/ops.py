"""PDF Toolkit engine.

Every PDF operation lives in this module. It has no GUI imports, so it can be
used from scripts and tested on its own.

Conventions
-----------
* Page numbers given to / shown by users are 1-based. Internally pages are
  0-based indices.
* Page selections are strings such as ``"all"``, ``"1-3,7,10-last"``, ``"odd"``.
* Source files are never modified. Output paths must differ from the source.
* Outputs are written without password protection (use ``encrypt_pdf`` to
  protect a result).
* Long operations accept ``progress(done, total)``. The callback may raise
  :class:`Cancelled` to abort.
"""
from __future__ import annotations

import io
import os
import re
import secrets
import shutil
import datetime as _dt
from pathlib import Path
from typing import Callable, Iterable, Sequence

import pymupdf
from . import imaging

Progress = Callable[[int, int], None] | None

pymupdf.TOOLS.mupdf_display_errors(False)


# --------------------------------------------------------------------------
# Errors, units, page sizes
# --------------------------------------------------------------------------
class PDFError(Exception):
    """A problem the user can understand and fix (bad input, bad range ...)."""


class PasswordRequired(PDFError):
    """The PDF is encrypted and no valid password is known."""


class Cancelled(Exception):
    """Raised from a progress callback to abort an operation."""


MM = 72.0 / 25.4
UNITS = {"pt": 1.0, "mm": MM, "cm": MM * 10, "in": 72.0}


def to_points(value: float, unit: str) -> float:
    return float(value) * UNITS[unit]


def from_points(value: float, unit: str) -> float:
    return float(value) / UNITS[unit]


def _mm(w, h):
    return (w * MM, h * MM)


PAGE_SIZES: dict[str, tuple[float, float]] = {
    "A0": _mm(841, 1189), "A1": _mm(594, 841), "A2": _mm(420, 594),
    "A3": _mm(297, 420), "A4": _mm(210, 297), "A5": _mm(148, 210),
    "A6": _mm(105, 148), "B4": _mm(250, 353), "B5": _mm(176, 250),
    "Letter": (612.0, 792.0), "Legal": (612.0, 1008.0),
    "Tabloid": (792.0, 1224.0), "Executive": (522.0, 756.0),
}


def _tick(progress: Progress, done: int, total: int) -> None:
    if progress:
        progress(done, total)


# --------------------------------------------------------------------------
# Opening, saving, helpers
# --------------------------------------------------------------------------
_PASSWORDS: dict[str, str] = {}


def _key(path) -> str:
    return os.path.normcase(os.path.abspath(str(path)))


def set_password(path, password: str) -> None:
    """Remember the password for ``path`` so later operations can open it."""
    _PASSWORDS[_key(path)] = password


def needs_password(path) -> bool:
    try:
        with pymupdf.open(str(path)) as d:
            return bool(d.needs_pass) and not _PASSWORDS.get(_key(path))
    except Exception:
        return False


MEMORY_LIMIT = 150 * 1024 * 1024   # files up to this size can be loaded without keeping a file handle


def open_pdf(path, password: str | None = None, in_memory: bool = False) -> pymupdf.Document:
    """Open a PDF. With ``in_memory`` (used by the GUI preview) the file is read
    completely and closed at once, so the original stays free to be renamed or
    deleted by the user (Windows keeps open files locked). Files larger than
    MEMORY_LIMIT are opened normally."""
    path = str(path)
    if not os.path.isfile(path):
        raise PDFError(f"File not found:\n{path}")
    try:
        if in_memory and os.path.getsize(path) <= MEMORY_LIMIT:
            with open(path, "rb") as fh:
                doc = pymupdf.open(stream=fh.read(), filetype="pdf")
        else:
            doc = pymupdf.open(path)
    except Exception as exc:  # corrupt / not a document
        raise PDFError(f"Cannot open '{os.path.basename(path)}': {exc}") from exc
    if not doc.is_pdf:
        doc.close()
        raise PDFError(f"'{os.path.basename(path)}' is not a PDF file.")
    if doc.needs_pass:
        pw = password or _PASSWORDS.get(_key(path))
        if not pw or not doc.authenticate(pw):
            doc.close()
            raise PasswordRequired(
                f"'{os.path.basename(path)}' is password protected "
                "(missing or wrong password)."
            )
    return doc


def _check_out(src, out) -> None:
    if not str(out):
        raise PDFError("No output file was chosen.")
    if _key(src) == _key(out):
        raise PDFError(
            "The output file must be different from the source file "
            "(your original is never overwritten)."
        )


def _save(doc: pymupdf.Document, out, **kw) -> str:
    """Save atomically (temp file, then rename) so a failure never leaves a
    half-written output behind."""
    out = str(out)
    Path(out).parent.mkdir(parents=True, exist_ok=True)
    kw.setdefault("garbage", 4)   # 4 = merge duplicates by content hash: fast and smaller (3 is O(n^2))
    kw.setdefault("deflate", True)
    kw.setdefault("encryption", pymupdf.PDF_ENCRYPT_NONE)
    tmp = out + ".part"
    try:
        doc.save(tmp, **kw)
        os.replace(tmp, out)
    finally:
        if os.path.exists(tmp):
            try:
                os.remove(tmp)
            except OSError:
                pass
    return out


def _free_path(path: Path) -> Path:
    """Return ``path`` or ``name (1).ext`` etc. so nothing is overwritten."""
    if not path.exists():
        return path
    for i in range(1, 10000):
        cand = path.with_name(f"{path.stem} ({i}){path.suffix}")
        if not cand.exists():
            return cand
    raise PDFError("Too many files with the same name in the output folder.")


def _safe_name(text: str, limit: int = 60) -> str:
    text = re.sub(r'[\\/:*?"<>|\x00-\x1f]+', "_", text).strip(" ._")
    return (text or "untitled")[:limit]


def _read_attachments(doc: pymupdf.Document) -> list[tuple]:
    """Embedded file attachments of ``doc`` as (name, data, filename, ufilename, desc)."""
    out = []
    try:
        for name in doc.embfile_names():
            info = doc.embfile_info(name)
            out.append((name, doc.embfile_get(name), info.get("filename") or name,
                        info.get("ufilename") or name, info.get("desc") or ""))
    except Exception:
        pass
    return out


def _write_attachments(items: list[tuple], dst: pymupdf.Document) -> None:
    for name, data, filename, ufilename, desc in items:
        try:
            existing = set(dst.embfile_names())
            new, k = name, 1
            while new in existing:          # merging files that carry the same attachment name
                new, k = f"{k}_{name}", k + 1
            dst.embfile_add(new, data, filename=filename, ufilename=ufilename, desc=desc)
        except Exception:
            pass


def _copy_attachments(src: pymupdf.Document, dst: pymupdf.Document) -> None:
    _write_attachments(_read_attachments(src), dst)


def _copy_page_labels(src: pymupdf.Document, dst: pymupdf.Document) -> None:
    """Carry page labels over when pages map 1:1."""
    if src.page_count == dst.page_count:
        _apply_labels(dst, _page_labels(src))


def _page_labels(doc: pymupdf.Document) -> list[str] | None:
    """Label text of every page, or None when the document has no custom labels."""
    try:
        if not doc.get_page_labels():
            return None
        return [doc[i].get_label() for i in range(doc.page_count)]
    except Exception:
        return None


def _apply_labels(dst: pymupdf.Document, labels: list[str] | None) -> None:
    """Write per-page label text, merging runs like 'A-1','A-2' into one rule."""
    if not labels or len(labels) != dst.page_count:
        return
    if all(l == str(i + 1) for i, l in enumerate(labels)):
        return
    rules: list[dict] = []
    prev_prefix, prev_num = None, None
    for i, lab in enumerate(labels):
        m = re.match(r"^(.*?)(\d+)$", lab)
        if m and (lab == m.group(1) + str(int(m.group(2)))):
            prefix, num = m.group(1), int(m.group(2))
            if prev_prefix == prefix and prev_num is not None and num == prev_num + 1:
                prev_num = num
                continue
            rules.append({"startpage": i, "prefix": prefix, "style": "D", "firstpagenum": num})
            prev_prefix, prev_num = prefix, num
        else:                                   # roman numerals, letters, empty ...
            rules.append({"startpage": i, "prefix": lab, "style": "", "firstpagenum": 1})
            prev_prefix, prev_num = None, None
    try:
        dst.set_page_labels(rules)
    except Exception:
        pass


def _finish_copy(src: pymupdf.Document, dst: pymupdf.Document) -> None:
    """Carry metadata and bookmarks over to a rebuilt document."""
    try:
        dst.set_metadata(src.metadata or {})
    except Exception:
        pass
    try:
        toc = src.get_toc()
        if toc and dst.page_count:
            dst.set_toc([t for t in toc if t[2] <= dst.page_count])
    except Exception:
        pass
    _copy_attachments(src, dst)
    _copy_page_labels(src, dst)


def _runs(indices: Sequence[int]) -> list[tuple[int, int]]:
    """Group indices into (from, to) runs of consecutive ascending pages."""
    runs: list[tuple[int, int]] = []
    for i in indices:
        if runs and runs[-1][1] + 1 == i:
            runs[-1] = (runs[-1][0], i)
        else:
            runs.append((i, i))
    return runs


def _subdoc(doc: pymupdf.Document, indices: Sequence[int]) -> pymupdf.Document:
    new = pymupdf.open()
    for a, b in _runs(indices):
        new.insert_pdf(doc, from_page=a, to_page=b)
    return new


def _color(c) -> tuple[float, float, float]:
    """Accept '#rrggbb' or an (r, g, b) tuple in 0-255 (or 0-1) -> floats."""
    if isinstance(c, str):
        c = c.lstrip("#")
        if len(c) != 6:
            raise PDFError(f"Bad colour '{c}'. Use #rrggbb.")
        return tuple(int(c[i:i + 2], 16) / 255 for i in (0, 2, 4))  # type: ignore
    r, g, b = c
    if max(r, g, b) > 1:
        return (r / 255, g / 255, b / 255)
    return (float(r), float(g), float(b))


def _upright_source(doc: pymupdf.Document) -> pymupdf.Document:
    """Prepare ``doc`` as the source for show_pdf_page(), which (a) ignores a
    page's /Rotate and (b) draws only page content, silently dropping
    annotations (highlights, comments) and form-field values. A throw-away
    copy is made with rotation baked in and annotations / fields burned into
    the page. Returns ``doc`` itself when nothing needs that (no copy cost)."""
    rotated = any(p.rotation for p in doc)
    marked = any(p.first_annot or p.first_widget for p in doc)
    if not (rotated or marked):
        return doc
    work = pymupdf.open()
    work.insert_pdf(doc)
    if marked:
        try:
            work.bake(annots=True, widgets=True)
        except Exception:
            pass
    for page in work:
        if page.rotation:
            page.remove_rotation()
            page.clean_contents()
    return work


def _carry_links(src_page: pymupdf.Page, dst_page: pymupdf.Page,
                 clip: pymupdf.Rect, target: pymupdf.Rect, keep: bool,
                 goto_ok: bool = False) -> None:
    """Re-create the clickable links of ``src_page`` on ``dst_page`` after the
    page has been drawn into ``target`` (show_pdf_page copies no links).
    Web/file links are always carried over; in-document links only when pages
    keep their numbers (``goto_ok``). Rotated source pages are skipped: link
    coordinates are not reliable there."""
    if src_page.rotation or clip.is_empty:
        return
    try:
        links = src_page.get_links()
    except Exception:
        return
    sx, sy = target.width / clip.width, target.height / clip.height
    ox, oy = target.x0, target.y0
    if keep:
        sx = sy = min(sx, sy)
        ox += (target.width - clip.width * sx) / 2
        oy += (target.height - clip.height * sy) / 2
    for lk in links:
        kind = lk.get("kind")
        if kind == pymupdf.LINK_GOTO and not goto_ok:
            continue
        if kind not in (pymupdf.LINK_URI, pymupdf.LINK_GOTO, pymupdf.LINK_LAUNCH,
                        pymupdf.LINK_GOTOR):
            continue
        r = pymupdf.Rect(lk["from"]) & clip
        if r.is_empty:
            continue
        new = {k: lk[k] for k in ("kind", "uri", "page", "to", "zoom", "file", "name")
               if k in lk}
        new["from"] = pymupdf.Rect((r.x0 - clip.x0) * sx + ox, (r.y0 - clip.y0) * sy + oy,
                                   (r.x1 - clip.x0) * sx + ox, (r.y1 - clip.y0) * sy + oy)
        try:
            dst_page.insert_link(new)
        except Exception:
            pass


# --------------------------------------------------------------------------
# Page selection parser
# --------------------------------------------------------------------------
def parse_pages(spec: str | None, count: int, *, unique: bool = True) -> list[int]:
    """Turn '1-3, 7, 10-last' into zero-based indices.

    Understands: all, odd, even, N, N-M, N-, -M, last/end, and reversed
    ranges such as 5-1. ``unique=False`` keeps repeats (for custom ordering).
    """
    if count < 1:
        raise PDFError("The PDF has no pages.")
    s = (spec or "").strip().lower()
    if s in ("", "all", "*"):
        return list(range(count))

    def num(token: str) -> int:
        if token in ("last", "end", "l"):
            return count
        if not token.isdigit():
            raise PDFError(f"'{token}' is not a valid page number.")
        n = int(token)
        if n < 1 or n > count:
            raise PDFError(
                f"Page {n} is out of range (the document has {count} page"
                f"{'s' if count != 1 else ''})."
            )
        return n

    out: list[int] = []
    for tok in re.split(r"[,\s;]+", s):
        if not tok:
            continue
        if tok == "odd":
            out += range(0, count, 2)
        elif tok == "even":
            out += range(1, count, 2)
        elif tok == "all":
            out += range(count)
        elif "-" in tok:
            if tok.count("-") != 1:
                raise PDFError(f"'{tok}' is not a valid page range.")
            lo, hi = tok.split("-")
            a = num(lo) if lo else 1
            b = num(hi) if hi else count
            step = 1 if a <= b else -1
            out += range(a - 1, b - 1 + step, step)
        else:
            out.append(num(tok) - 1)
    if not out:
        raise PDFError("No pages selected.")
    if unique:
        seen: set[int] = set()
        out = [p for p in out if not (p in seen or seen.add(p))]
    return out


# --------------------------------------------------------------------------
# Information
# --------------------------------------------------------------------------
def pdf_info(src) -> dict:
    with open_pdf(src) as doc:
        sizes: dict[tuple[int, int], int] = {}
        links = annots = 0
        for page in doc:
            key = (round(page.rect.width), round(page.rect.height))
            sizes[key] = sizes.get(key, 0) + 1
            links += len(page.get_links())
            annots += len(list(page.annots() or []))
        try:
            is_form = bool(doc.is_form_pdf)
        except Exception:
            is_form = False
        return {
            "file": os.path.basename(str(src)),
            "pages": doc.page_count,
            "bytes": os.path.getsize(src),
            "format": (doc.metadata or {}).get("format", ""),
            "encrypted": bool(doc.is_encrypted),
            "metadata": dict(doc.metadata or {}),
            "page_sizes": sizes,
            "bookmarks": len(doc.get_toc()),
            "links": links,
            "annotations": annots,
            "has_form": is_form,
        }


def human_size(n: float) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024
    return f"{n} B"


# --------------------------------------------------------------------------
# Merge / split / organise
# --------------------------------------------------------------------------
def merge_pdfs(paths: Sequence, out, bookmarks: bool = False,
               progress: Progress = None) -> str:
    if not paths:
        raise PDFError("Add at least one PDF to merge.")
    for p in paths:
        _check_out(p, out)
    result = pymupdf.open()
    toc: list[list] = []
    all_labels: list[list[str]] = []
    any_labels = False
    for i, p in enumerate(paths):
        with open_pdf(p) as d:
            if d.page_count == 0:
                continue
            start = result.page_count
            lab = _page_labels(d)
            any_labels = any_labels or bool(lab)
            all_labels.append(lab or [str(k + 1) for k in range(d.page_count)])
            result.insert_pdf(d)
            _copy_attachments(d, result)
            if bookmarks:
                toc.append([1, Path(p).stem, start + 1])
                for lvl, title, pg in d.get_toc(simple=True):
                    toc.append([lvl + 1, title, start + max(pg, 1)])
        _tick(progress, i + 1, len(paths))
    if result.page_count == 0:
        raise PDFError("None of the selected PDFs contain any pages.")
    if bookmarks and toc:
        try:
            result.set_toc(toc)
        except Exception:  # odd bookmark levels in a source file
            result.set_toc([t for t in toc if t[0] == 1])
    if any_labels:
        _apply_labels(result, [l for group in all_labels for l in group])
    return _save(result, out)


def split_pdf(src, out_dir, mode: str = "each", n: int = 1, ranges: str = "",
              parts: int = 2, progress: Progress = None) -> list[str]:
    """Split ``src`` into several files inside ``out_dir``.

    mode: 'each' (one file per page), 'every' (every ``n`` pages),
    'parts' (``parts`` equal parts), 'ranges' ("1-3,4-7,9": one file per
    comma-separated item), 'bookmarks' (one file per top-level bookmark).
    """
    out_dir = Path(out_dir)
    stem = Path(src).stem
    with open_pdf(src) as doc:
        count = doc.page_count
        if count == 0:
            raise PDFError("The PDF has no pages.")
        groups: list[tuple[list[int], str | None]] = []  # (indices, title)
        if mode == "each":
            groups = [([i], None) for i in range(count)]
        elif mode == "every":
            if n < 1:
                raise PDFError("'Every N pages' needs N of at least 1.")
            groups = [(list(range(i, min(i + n, count))), None)
                      for i in range(0, count, n)]
        elif mode == "parts":
            if parts < 1:
                raise PDFError("Number of parts must be at least 1.")
            parts = min(parts, count)
            base, extra = divmod(count, parts)
            idx = 0
            for k in range(parts):
                size = base + (1 if k < extra else 0)
                groups.append((list(range(idx, idx + size)), None))
                idx += size
        elif mode == "ranges":
            tokens = [t.strip() for t in re.split(r"[,;]+", ranges) if t.strip()]
            if not tokens:
                raise PDFError("Enter at least one page range, e.g. 1-3, 4-7, 9")
            groups = [(parse_pages(t, count), None) for t in tokens]
        elif mode == "bookmarks":
            top = [(pg - 1, title) for lvl, title, pg in doc.get_toc(simple=True)
                   if lvl == 1 and 1 <= pg <= count]
            if not top:
                raise PDFError("This PDF has no top-level bookmarks to split by.")
            top.sort(key=lambda t: t[0])
            dedup: list[tuple[int, str]] = []
            for pg, title in top:
                if not dedup or dedup[-1][0] != pg:
                    dedup.append((pg, title))
            if dedup[0][0] > 0:
                dedup.insert(0, (0, "Front matter"))
            for k, (pg, title) in enumerate(dedup):
                end = dedup[k + 1][0] if k + 1 < len(dedup) else count
                groups.append((list(range(pg, end)), title))
        else:
            raise PDFError(f"Unknown split mode '{mode}'.")

        out_dir.mkdir(parents=True, exist_ok=True)
        part_labels = _page_labels(doc)
        width = max(2, len(str(len(groups))))
        written: list[str] = []
        for k, (idxs, title) in enumerate(groups, 1):
            if title is not None:
                name = f"{stem}_{k:0{width}d}_{_safe_name(title)}.pdf"
            elif len(idxs) == 1:
                name = f"{stem}_page_{idxs[0] + 1}.pdf"
            elif idxs == list(range(idxs[0], idxs[-1] + 1)):
                name = f"{stem}_pages_{idxs[0] + 1}-{idxs[-1] + 1}.pdf"
            else:
                name = f"{stem}_part_{k:0{width}d}.pdf"
            target = _free_path(out_dir / name)
            sub = _subdoc(doc, idxs)
            try:
                _finish_copy_meta_only(doc, sub)
                _apply_labels(sub, [part_labels[i] for i in idxs] if part_labels else None)
                _save(sub, target)
            finally:
                sub.close()
            written.append(str(target))
            _tick(progress, k, len(groups))
        return written


def _finish_copy_meta_only(src: pymupdf.Document, dst: pymupdf.Document) -> None:
    try:
        dst.set_metadata(src.metadata or {})
    except Exception:
        pass


def select_pages(src, out, indices: Sequence[int], progress: Progress = None) -> str:
    """Write a new PDF made of the given pages, in the given order.
    Covers extract, delete, reorder, reverse and duplicate."""
    _check_out(src, out)
    if not indices:
        raise PDFError("The result would have no pages.")
    with open_pdf(src) as doc:
        indices = list(indices)
        attachments = _read_attachments(doc)
        labels = _page_labels(doc)
        new_labels = [labels[i] for i in indices] if labels else None
        if len(set(indices)) == len(indices):
            doc.select(indices)
            _write_attachments(attachments, doc)
            _apply_labels(doc, new_labels)
            return _save(doc, out)
        new = _subdoc_each(doc, indices, progress)
        _finish_copy_meta_only(doc, new)
        _write_attachments(attachments, new)
        _apply_labels(new, new_labels)
        return _save(new, out)


def _subdoc_each(doc, indices, progress=None) -> pymupdf.Document:
    """Copy pages one by one so repeated pages are independent copies."""
    new = pymupdf.open()
    for k, i in enumerate(indices, 1):
        new.insert_pdf(doc, from_page=i, to_page=i)
        _tick(progress, k, len(indices))
    return new


def extract_pages(src, out, pages: str, progress: Progress = None) -> str:
    with open_pdf(src) as d:
        idx = parse_pages(pages, d.page_count)
    return select_pages(src, out, idx, progress)


def delete_pages(src, out, pages: str, progress: Progress = None) -> str:
    with open_pdf(src) as d:
        drop = set(parse_pages(pages, d.page_count))
        keep = [i for i in range(d.page_count) if i not in drop]
    if not keep:
        raise PDFError("You selected every page for deletion - nothing would be left.")
    return select_pages(src, out, keep, progress)


def reorder_pages(src, out, order: str, progress: Progress = None) -> str:
    """``order`` such as '3,1,2,5-8' or 'last-1' (descending ranges allowed).
    Pages not listed are dropped; repeats are allowed."""
    with open_pdf(src) as d:
        idx = parse_pages(order, d.page_count, unique=False)
    return select_pages(src, out, idx, progress)


def reverse_pages(src, out, progress: Progress = None) -> str:
    with open_pdf(src) as d:
        idx = list(range(d.page_count - 1, -1, -1))
    return select_pages(src, out, idx, progress)


def duplicate_pages(src, out, pages: str, copies: int = 1,
                    progress: Progress = None) -> str:
    """Repeat the selected pages ``copies`` extra times right after themselves."""
    if copies < 1:
        raise PDFError("Number of copies must be at least 1.")
    with open_pdf(src) as d:
        count = d.page_count
        sel = set(parse_pages(pages, count))
    order: list[int] = []
    for i in range(count):
        order.append(i)
        if i in sel:
            order += [i] * copies
    return select_pages(src, out, order, progress)


def insert_blank_pages(src, out, after: str = "1", count: int = 1,
                       progress: Progress = None) -> str:
    """Insert ``count`` blank pages after each listed page ('0' = at the
    very start). Blank pages copy the size of the neighbouring page."""
    _check_out(src, out)
    if count < 1:
        raise PDFError("Number of blank pages must be at least 1.")
    with open_pdf(src) as doc:
        n = doc.page_count
        positions: set[int] = set()
        for tok in re.split(r"[,\s;]+", after.strip().lower()):
            if not tok:
                continue
            if tok == "0":
                positions.add(0)
            elif tok in ("all", "*"):
                positions.update(range(1, n + 1))
            else:
                positions.update(i + 1 for i in parse_pages(tok, n))
        if not positions:
            raise PDFError("Say after which page(s) to insert blank pages.")
        labels = _page_labels(doc)
        if labels:
            merged: list[str] = []
            for pos in range(n + 1):
                if pos > 0:
                    merged.append(labels[pos - 1])
                if pos in positions:
                    merged.extend([""] * count)
            labels = merged
        for k, pos in enumerate(sorted(positions, reverse=True), 1):
            ref = doc[max(pos - 1, 0)].rect
            for _ in range(count):
                doc.new_page(pno=pos, width=ref.width, height=ref.height)
            _tick(progress, k, len(positions))
        _apply_labels(doc, labels)
        return _save(doc, out)


def rotate_pages(src, out, pages: str = "all", angle: int = 90,
                 progress: Progress = None) -> str:
    """Rotate selected pages clockwise by ``angle`` (multiple of 90; negative
    rotates counter-clockwise)."""
    _check_out(src, out)
    if angle % 90:
        raise PDFError("Rotation must be a multiple of 90 degrees.")
    with open_pdf(src) as doc:
        idx = parse_pages(pages, doc.page_count)
        for k, i in enumerate(idx, 1):
            page = doc[i]
            page.set_rotation((page.rotation + angle) % 360)
            _tick(progress, k, len(idx))
        return _save(doc, out)


# --------------------------------------------------------------------------
# Crop / cut
# --------------------------------------------------------------------------
def content_bbox(page: pymupdf.Page, dpi: int = 40, threshold: int = 245
                 ) -> pymupdf.Rect | None:
    """Bounding box (in page.rect coordinates) of everything that is not
    white. None for a blank page. Works on a small grayscale render using
    plain byte operations (no image library)."""
    pix = page.get_pixmap(dpi=dpi, colorspace=pymupdf.csGRAY, alpha=False)
    w, h, stride, data = pix.width, pix.height, pix.stride, pix.samples
    rows = [y for y in range(h) if min(data[y * stride:y * stride + w]) < threshold]
    if not rows:
        return None
    cols = [x for x in range(w) if min(data[x::stride][:h]) < threshold]
    if not cols:
        return None
    sx = page.rect.width / w
    sy = page.rect.height / h
    return pymupdf.Rect(cols[0] * sx, rows[0] * sy, (cols[-1] + 1) * sx, (rows[-1] + 1) * sy)


def crop_pages(src, out, pages: str = "all",
               margins: tuple[float, float, float, float] = (0, 0, 0, 0),
               unit: str = "mm", auto: bool = False, padding: float = 5.0,
               progress: Progress = None) -> str:
    """Crop (remove) margins. ``margins`` = (left, top, right, bottom) in
    ``unit`` ('pt', 'mm', 'cm', 'in' or '%' of page size). With ``auto`` the
    white margins of every page are trimmed instead, keeping ``padding`` pt.

    Like Acrobat, this sets the visible page area; the cropped-away content
    stays inside the file. Use Convert > Rasterize to remove it for good."""
    _check_out(src, out)
    if min(margins) < 0:
        raise PDFError("Margins cannot be negative.")
    with open_pdf(src) as doc:
        idx = parse_pages(pages, doc.page_count)
        for k, i in enumerate(idx, 1):
            page = doc[i]
            vis = page.rect
            if auto:
                bb = content_bbox(page)
                if bb is None:
                    _tick(progress, k, len(idx))
                    continue
                new = pymupdf.Rect(bb.x0 - padding, bb.y0 - padding,
                                   bb.x1 + padding, bb.y1 + padding) & vis
            else:
                if unit == "%":
                    l = vis.width * margins[0] / 100
                    t = vis.height * margins[1] / 100
                    r = vis.width * margins[2] / 100
                    b = vis.height * margins[3] / 100
                else:
                    l, t, r, b = (to_points(m, unit) for m in margins)
                new = pymupdf.Rect(vis.x0 + l, vis.y0 + t, vis.x1 - r, vis.y1 - b)
            if new.is_empty or new.width < 10 or new.height < 10:
                raise PDFError(
                    f"Page {i + 1}: the margins leave nothing visible "
                    f"(page is {vis.width:.0f} x {vis.height:.0f} pt)."
                )
            # page.rect always starts at (0, 0) but set_cropbox() wants
            # unrotated coordinates relative to the MediaBox, so un-rotate
            # and add the offset of any existing crop box.
            unrot = new * page.derotation_matrix
            off = page.cropbox_position
            page.set_cropbox(pymupdf.Rect(unrot.x0 + off.x, unrot.y0 + off.y,
                                          unrot.x1 + off.x, unrot.y1 + off.y))
            _tick(progress, k, len(idx))
        return _save(doc, out)


def cut_pages(src, out, pages: str = "all", cols: int = 2, rows: int = 1,
              right_to_left: bool = False, progress: Progress = None) -> str:
    """Cut each selected page into a ``cols`` x ``rows`` grid of new pages
    (e.g. split a scanned double-page spread into two pages). Unselected
    pages are copied unchanged."""
    _check_out(src, out)
    if cols < 1 or rows < 1 or cols * rows < 2:
        raise PDFError("Choose at least 2 pieces (columns x rows).")
    with open_pdf(src) as doc:
        sel = set(parse_pages(pages, doc.page_count))
        new = pymupdf.open()
        n = doc.page_count
        work = _upright_source(doc)
        labels = _page_labels(doc)
        new_labels: list[str] = []
        for i in range(n):
            page = work[i]
            if labels:
                new_labels.extend([labels[i]] * (cols * rows if i in sel else 1))
            if i not in sel:
                new.insert_pdf(doc, from_page=i, to_page=i)
            else:
                r = page.rect
                cw, ch = r.width / cols, r.height / rows
                for row in range(rows):
                    col_order = range(cols - 1, -1, -1) if right_to_left else range(cols)
                    for col in col_order:
                        clip = pymupdf.Rect(r.x0 + col * cw, r.y0 + row * ch,
                                            r.x0 + (col + 1) * cw,
                                            r.y0 + (row + 1) * ch)
                        np_ = new.new_page(width=cw, height=ch)
                        np_.show_pdf_page(np_.rect, work, i, clip=clip)
                        _carry_links(page, np_, clip, np_.rect, keep=False)
            _tick(progress, i + 1, n)
        _finish_copy_meta_only(doc, new)
        _copy_attachments(doc, new)
        _apply_labels(new, new_labels or None)
        return _save(new, out)


# --------------------------------------------------------------------------
# Resize / scale / n-up
# --------------------------------------------------------------------------
def _place(page: pymupdf.Page, src: pymupdf.Document, i: int,
           mode: str, margin: float) -> None:
    """Draw source page ``i`` onto ``page`` (mode: fit | fill | stretch)."""
    target = pymupdf.Rect(page.rect.x0 + margin, page.rect.y0 + margin,
                          page.rect.x1 - margin, page.rect.y1 - margin)
    sp = src[i].rect
    clip = sp
    if mode == "stretch":
        page.show_pdf_page(target, src, i, keep_proportion=False)
    elif mode == "fill":
        s = max(target.width / sp.width, target.height / sp.height)
        cw, ch = target.width / s, target.height / s
        cx, cy = sp.x0 + sp.width / 2, sp.y0 + sp.height / 2
        clip = pymupdf.Rect(cx - cw / 2, cy - ch / 2, cx + cw / 2, cy + ch / 2)
        page.show_pdf_page(target, src, i, clip=clip, keep_proportion=False)
    else:
        page.show_pdf_page(target, src, i, keep_proportion=True)
    _carry_links(src[i], page, clip, target, keep=(mode == "fit"), goto_ok=True)


def resize_pages(src, out, pages: str = "all", size: str | tuple = "A4",
                 unit: str = "mm", mode: str = "fit", margin: float = 0.0,
                 auto_orient: bool = True, progress: Progress = None) -> str:
    """Change the page size. ``size`` is a name from PAGE_SIZES or a
    (width, height) tuple in ``unit``. mode: 'fit' (keep proportions, whole
    page visible), 'fill' (cover the page, crop overflow), 'stretch'.
    ``margin`` is in ``unit``. With ``auto_orient`` a landscape page gets a
    landscape target size."""
    _check_out(src, out)
    if isinstance(size, str):
        if size not in PAGE_SIZES:
            raise PDFError(f"Unknown page size '{size}'.")
        tw, th = PAGE_SIZES[size]
    else:
        tw, th = to_points(size[0], unit), to_points(size[1], unit)
    if tw < 20 or th < 20:
        raise PDFError("The page size is too small.")
    m = to_points(margin, unit)
    if m * 2 >= min(tw, th):
        raise PDFError("The margin is larger than the page.")

    def target(page):
        w, h = tw, th
        pw_, ph_ = page.rect.width, page.rect.height
        if (auto_orient and abs(pw_ - ph_) > 1 and w != h
                and (pw_ > ph_) != (w > h)):
            w, h = h, w
        return w, h, mode, m

    return _rebuild(src, out, pages, target, progress)


def scale_pages(src, out, pages: str = "all", percent: float = 100.0,
                progress: Progress = None) -> str:
    """Scale the page (and its content) to ``percent`` % of its size."""
    _check_out(src, out)
    if not 5 <= percent <= 1000:
        raise PDFError("Scale must be between 5% and 1000%.")
    f = percent / 100.0
    return _rebuild(src, out, pages,
                    lambda p: (p.rect.width * f, p.rect.height * f, "stretch", 0.0),
                    progress)


def _rebuild(src, out, pages, target_fn, progress) -> str:
    with open_pdf(src) as doc:
        sel = set(parse_pages(pages, doc.page_count))
        new = pymupdf.open()
        n = doc.page_count
        work = _upright_source(doc)
        for i in range(n):
            if i in sel:
                w, h, mode, margin = target_fn(work[i])
                np_ = new.new_page(width=w, height=h)
                _place(np_, work, i, mode, margin)
            else:
                new.insert_pdf(doc, from_page=i, to_page=i)
            _tick(progress, i + 1, n)
        _finish_copy(doc, new)
        return _save(new, out)


def n_up(src, out, cols: int = 2, rows: int = 1, size: str = "A4",
         landscape: bool | None = None, margin_mm: float = 8.0,
         gap_mm: float = 4.0, border: bool = False, by_column: bool = False,
         progress: Progress = None) -> str:
    """Put several pages on one sheet (2-up, 4-up ...)."""
    _check_out(src, out)
    if cols < 1 or rows < 1:
        raise PDFError("Columns and rows must be at least 1.")
    w, h = PAGE_SIZES[size]
    if landscape is None:
        landscape = cols > rows
    if landscape != (w > h):
        w, h = h, w
    m, g = margin_mm * MM, gap_mm * MM
    cw = (w - 2 * m - (cols - 1) * g) / cols
    ch = (h - 2 * m - (rows - 1) * g) / rows
    if cw < 20 or ch < 20:
        raise PDFError("Too many pages per sheet for this paper size and margins.")
    per = cols * rows
    with open_pdf(src) as doc:
        new = pymupdf.open()
        n = doc.page_count
        work = _upright_source(doc)
        for start in range(0, n, per):
            sheet = new.new_page(width=w, height=h)
            for k in range(min(per, n - start)):
                r, c = (k % rows, k // rows) if by_column else (k // cols, k % cols)
                cell = pymupdf.Rect(m + c * (cw + g), m + r * (ch + g),
                                    m + c * (cw + g) + cw, m + r * (ch + g) + ch)
                sheet.show_pdf_page(cell, work, start + k, keep_proportion=True)
                _carry_links(work[start + k], sheet, work[start + k].rect, cell, keep=True)
                if border:
                    sheet.draw_rect(cell, color=(0.55, 0.55, 0.55), width=0.5)
            _tick(progress, min(start + per, n), n)
        _finish_copy_meta_only(doc, new)
        _copy_attachments(doc, new)
        return _save(new, out)


# --------------------------------------------------------------------------
# Compress / rasterize
# --------------------------------------------------------------------------
COMPRESS_LEVELS = {
    # name: (dpi_threshold, dpi_target, jpeg_quality) - None = lossless only
    "light": None,
    "medium": (170, 130, 70),
    "high": (130, 96, 55),
    "extreme": (90, 72, 40),
}


def compress_pdf(src, out, level: str = "medium", dpi: int | None = None,
                 quality: int | None = None, progress: Progress = None) -> dict:
    """Shrink a PDF. 'light' only optimises structure (lossless); the other
    levels also downsample and recompress images. Pass ``dpi``/``quality``
    to override. Returns {'before', 'after', 'kept_original'}; if the result
    would be bigger the original bytes are written instead."""
    _check_out(src, out)
    if level not in COMPRESS_LEVELS and not (dpi or quality):
        raise PDFError(f"Unknown compression level '{level}'.")
    before = os.path.getsize(src)
    try:
        with pymupdf.open(str(src)) as probe:
            src_encrypted = bool(probe.is_encrypted or probe.needs_pass)
    except Exception:
        src_encrypted = False
    with open_pdf(src) as doc:
        preset = COMPRESS_LEVELS.get(level)
        if dpi or quality:
            thr, tgt, q = preset or (170, 130, 70)
            tgt = dpi or tgt
            thr = max(thr, tgt + 1) if dpi else thr
            q = quality or q
            preset = (thr, tgt, q)
        _tick(progress, 0, 3)
        if preset:
            thr, tgt, q = preset
            doc.rewrite_images(dpi_threshold=thr, dpi_target=tgt, quality=q)
        _tick(progress, 1, 3)
        try:
            doc.subset_fonts()
        except Exception:
            pass  # fontTools not installed or font cannot be subset
        _tick(progress, 2, 3)
        tmp = str(out) + ".try"
        Path(tmp).parent.mkdir(parents=True, exist_ok=True)
        try:
            try:
                doc.save(tmp, garbage=4, deflate=True, deflate_images=True,
                         deflate_fonts=True, clean=True, use_objstms=1,
                         encryption=pymupdf.PDF_ENCRYPT_NONE)
            except TypeError:
                doc.save(tmp, garbage=4, deflate=True, clean=True,
                         encryption=pymupdf.PDF_ENCRYPT_NONE)
            after = os.path.getsize(tmp)
            kept = False
            if after >= before and not src_encrypted:
                shutil.copyfile(src, out)
                os.remove(tmp)
                after, kept = before, True
            else:
                os.replace(tmp, out)
        finally:
            if os.path.exists(tmp):
                os.remove(tmp)
    _tick(progress, 3, 3)
    return {"before": before, "after": after, "kept_original": kept}


def rasterize_pdf(src, out, dpi: int = 150, gray: bool = False,
                  quality: int = 85, pages: str = "all",
                  progress: Progress = None) -> str:
    """Re-draw pages as images inside a new PDF. Removes hidden / cropped-away
    content and text, and can convert to grayscale. Text is no longer
    selectable afterwards."""
    _check_out(src, out)
    with open_pdf(src) as doc:
        sel = set(parse_pages(pages, doc.page_count))
        new = pymupdf.open()
        n = doc.page_count
        for i in range(n):
            if i not in sel:
                new.insert_pdf(doc, from_page=i, to_page=i)
            else:
                page = doc[i]
                pix = page.get_pixmap(
                    dpi=dpi, alpha=False,
                    colorspace=pymupdf.csGRAY if gray else pymupdf.csRGB)
                np_ = new.new_page(width=page.rect.width, height=page.rect.height)
                np_.insert_image(np_.rect, stream=pix.tobytes("jpg", jpg_quality=int(quality)))
            _tick(progress, i + 1, n)
        _finish_copy_meta_only(doc, new)
        _copy_attachments(doc, new)
        _copy_page_labels(doc, new)
        return _save(new, out)


# --------------------------------------------------------------------------
# Convert
# --------------------------------------------------------------------------
IMAGE_FORMATS = ("png", "jpg", "webp", "tiff", "bmp")


def pdf_to_images(src, out_dir, fmt: str = "png", dpi: int = 150,
                  pages: str = "all", quality: int = 90,
                  progress: Progress = None) -> list[str]:
    fmt = fmt.lower().lstrip(".")
    if fmt == "jpeg":
        fmt = "jpg"
    if fmt == "tif":
        fmt = "tiff"
    if fmt not in IMAGE_FORMATS:
        raise PDFError(f"Unsupported image format '{fmt}'.")
    if not 10 <= dpi <= 1200:
        raise PDFError("DPI must be between 10 and 1200.")
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    stem = Path(src).stem
    with open_pdf(src) as doc:
        idx = parse_pages(pages, doc.page_count)
        width = max(3, len(str(doc.page_count)))
        written = []
        for k, i in enumerate(idx, 1):
            pix = doc[i].get_pixmap(dpi=dpi, alpha=False)
            try:
                data = imaging.encode_pixmap(pix, fmt, quality)
            except imaging.ImageError as exc:
                raise PDFError(str(exc)) from exc
            target = _free_path(out_dir / f"{stem}_page_{i + 1:0{width}d}.{fmt}")
            target.write_bytes(data)
            written.append(str(target))
            _tick(progress, k, len(idx))
        return written


def images_to_pdf(paths: Sequence, out, size: str = "image", dpi: int = 150,
                  margin_mm: float = 0.0, progress: Progress = None) -> str:
    """Build a PDF with one image per page. ``size`` = 'image' (page matches the
    image at ``dpi``) or a name from PAGE_SIZES (orientation follows the image).
    Reads JPEG, PNG, WebP, TIFF, BMP, GIF ...; EXIF rotation is applied;
    transparency becomes white; plain JPEG/PNG files are embedded unchanged."""
    if not paths:
        raise PDFError("Add at least one image.")
    if size != "image" and size not in PAGE_SIZES:
        raise PDFError(f"Unknown page size '{size}'.")
    doc = pymupdf.open()
    m = margin_mm * MM
    for k, p in enumerate(paths, 1):
        name = os.path.basename(str(p))
        try:
            img = imaging.load_for_pdf(p)
        except imaging.ImageError as exc:
            raise PDFError(f"Cannot read image '{name}': {exc}") from exc
        iw, ih = img.width, img.height
        if size == "image":
            pw, ph = iw * 72.0 / dpi + 2 * m, ih * 72.0 / dpi + 2 * m
        else:
            pw, ph = PAGE_SIZES[size]
            if (iw > ih) != (pw > ph):
                pw, ph = ph, pw
        page = doc.new_page(width=pw, height=ph)
        box = pymupdf.Rect(m, m, pw - m, ph - m)
        try:
            page.insert_image(box, stream=img.data, keep_proportion=True)
        except Exception:
            # exotic colour mode that MuPDF refuses (e.g. CMYK JPEG): convert via Qt
            try:
                img = imaging.load_converted(p)
                page.insert_image(box, stream=img.data, keep_proportion=True)
            except Exception as exc:
                raise PDFError(f"Cannot use image '{name}': {exc}") from exc
        _tick(progress, k, len(paths))
    return _save(doc, out)


def pdf_to_text(src, out, pages: str = "all", progress: Progress = None) -> dict:
    """Extract text to a UTF-8 file. Returns {'path', 'empty_pages'}."""
    _check_out(src, out)
    with open_pdf(src) as doc:
        idx = parse_pages(pages, doc.page_count)
        chunks, empty = [], 0
        for k, i in enumerate(idx, 1):
            text = doc[i].get_text("text", sort=True).strip()
            if not text:
                empty += 1
            chunks.append(f"----- Page {i + 1} -----\n{text}\n")
            _tick(progress, k, len(idx))
    Path(out).parent.mkdir(parents=True, exist_ok=True)
    Path(out).write_text("\n".join(chunks), encoding="utf-8")
    return {"path": str(out), "empty_pages": empty, "pages": len(idx)}


def extract_images(src, out_dir, pages: str = "all", min_size: int = 32,
                   progress: Progress = None) -> list[str]:
    """Save the pictures embedded in the PDF (each unique image once)."""
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    stem = Path(src).stem
    seen: set[int] = set()
    written: list[str] = []
    with open_pdf(src) as doc:
        idx = parse_pages(pages, doc.page_count)
        for k, i in enumerate(idx, 1):
            for n, info in enumerate(doc.get_page_images(i, full=True), 1):
                xref, smask = info[0], info[1]
                if xref in seen:
                    continue
                seen.add(xref)
                try:
                    raw = doc.extract_image(xref)
                    if not raw or min(raw["width"], raw["height"]) < min_size:
                        continue
                    if smask == 0 and raw["ext"] in ("jpeg", "jpg", "png"):
                        ext, data = ("jpg" if raw["ext"] == "jpeg" else raw["ext"]), raw["image"]
                    else:
                        pix = pymupdf.Pixmap(doc, xref)
                        if smask:
                            pix = pymupdf.Pixmap(pix, pymupdf.Pixmap(doc, smask))
                        if pix.colorspace and pix.colorspace.n > 3:
                            pix = pymupdf.Pixmap(pymupdf.csRGB, pix)
                        ext, data = "png", pix.tobytes("png")
                    target = _free_path(out_dir / f"{stem}_p{i + 1}_img{n}.{ext}")
                    target.write_bytes(data)
                    written.append(str(target))
                except Exception:
                    continue  # skip unreadable image streams
            _tick(progress, k, len(idx))
    return written


# --------------------------------------------------------------------------
# Watermark, header/footer, page numbers
# --------------------------------------------------------------------------
def _load_font(fontfile: str | None) -> pymupdf.Font:
    if fontfile:
        try:
            return pymupdf.Font(fontfile=fontfile)
        except Exception as exc:
            raise PDFError(f"Cannot load font file: {exc}")
    return pymupdf.Font("helv")


def _check_glyphs(font: pymupdf.Font, text: str) -> None:
    bad = sorted({ch for ch in text if not ch.isspace() and not font.has_glyph(ord(ch))})
    if bad:
        raise PDFError(
            "The default font cannot draw these characters: "
            + " ".join(bad[:8])
            + "\nChoose a .ttf/.otf font that contains them (the 'Font' field)."
        )


def _upright(page: pymupdf.Page) -> None:
    """Bake /Rotate into the content so new text/images can be placed using
    the visual page coordinates. remove_rotation() leaves an unbalanced
    'cm' at the head of the content stream, which would transform anything
    drawn afterwards, so the contents are cleaned (q/Q wrapped) as well."""
    if page.rotation:
        page.remove_rotation()
        page.clean_contents()


RASTER_TEXT_SCALE = 4.0     # pixels per PDF point for shaped text (288 dpi)


def _needs_raster_text(text: str, fontfile: str | None) -> bool:
    """True when ``text`` cannot be drawn correctly letter by letter: scripts that
    need glyph shaping (Hindi, Bengali, Tamil, Arabic ...), or characters the
    built-in Latin font does not have (when no font file was chosen)."""
    if imaging.needs_shaping(text):
        return True
    if not fontfile:
        font = pymupdf.Font("helv")
        return any(not ch.isspace() and not font.has_glyph(ord(ch)) for ch in text)
    return False


def _shaped_text_image(text, fontsize, color, fontfile, opacity=1.0, angle=0.0):
    try:
        img = imaging.render_text(text, fontsize, color, fontfile, opacity, angle, RASTER_TEXT_SCALE)
    except imaging.ImageError as exc:
        raise PDFError(str(exc)) from exc
    return img, img.width / RASTER_TEXT_SCALE, img.height / RASTER_TEXT_SCALE


def add_text_watermark(src, out, text: str, pages: str = "all",
                       fontsize: float = 60, color="#c00000",
                       opacity: float = 0.25, angle: float = 45,
                       tile: bool = False, fontfile: str | None = None,
                       progress: Progress = None) -> str:
    """Draw ``text`` across pages. ``angle`` is counter-clockwise degrees.

    Latin text becomes real (selectable) PDF text. Scripts that need shaping
    (Devanagari, Bengali, Tamil, Arabic ...) are rendered correctly by Qt into
    a picture instead; they use an installed system font, or ``fontfile``."""
    _check_out(src, out)
    if not text.strip():
        raise PDFError("Enter the watermark text.")
    col = _color(color)
    if _needs_raster_text(text, fontfile):
        img, w, h = _shaped_text_image(text, fontsize, color, fontfile, opacity, angle)
        with open_pdf(src) as doc:
            idx = parse_pages(pages, doc.page_count)
            for k, i in enumerate(idx, 1):
                page = doc[i]
                _upright(page)
                r = page.rect
                if tile:
                    gx, gy = w * 1.3, h * 1.5
                    y, row = r.y0 - h / 2, 0
                    while y < r.y1:
                        x = r.x0 - w / 2 + (gx / 2 if row % 2 else 0)
                        while x < r.x1:
                            page.insert_image(pymupdf.Rect(x, y, x + w, y + h), stream=img.data, overlay=True)
                            x += gx
                        y += gy
                        row += 1
                else:
                    cx, cy = r.x0 + r.width / 2, r.y0 + r.height / 2
                    page.insert_image(pymupdf.Rect(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2),
                                      stream=img.data, overlay=True)
                _tick(progress, k, len(idx))
            return _save(doc, out)
    font = _load_font(fontfile)
    _check_glyphs(font, text)
    tw_len = font.text_length(text, fontsize=fontsize)
    with open_pdf(src) as doc:
        idx = parse_pages(pages, doc.page_count)
        for k, i in enumerate(idx, 1):
            page = doc[i]
            _upright(page)
            r = page.rect
            center = pymupdf.Point(r.x0 + r.width / 2, r.y0 + r.height / 2)
            tw = pymupdf.TextWriter(r, opacity=opacity, color=col)
            if tile:
                stepx, stepy = tw_len * 1.6, fontsize * 4.0
                diag = (r.width ** 2 + r.height ** 2) ** 0.5
                y = center.y - diag / 2
                row = 0
                while y < center.y + diag / 2:
                    x = center.x - diag / 2 + (stepx / 2 if row % 2 else 0)
                    while x < center.x + diag / 2:
                        tw.append((x, y), text, font=font, fontsize=fontsize)
                        x += stepx
                    y += stepy
                    row += 1
            else:
                tw.append((center.x - tw_len / 2, center.y + fontsize * 0.3),
                          text, font=font, fontsize=fontsize)
            tw.write_text(page, morph=(center, pymupdf.Matrix(-angle)), overlay=True)
            _tick(progress, k, len(idx))
        return _save(doc, out)


def _anchor(rect: pymupdf.Rect, w: float, h: float, position: str,
            margin: float) -> pymupdf.Point:
    """Top-left corner for a w x h box at ``position`` inside ``rect``."""
    v, _, hz = position.partition("-")
    x = {"left": rect.x0 + margin, "center": rect.x0 + (rect.width - w) / 2,
         "right": rect.x1 - margin - w}.get(hz or v, rect.x0 + (rect.width - w) / 2)
    y = {"top": rect.y0 + margin, "middle": rect.y0 + (rect.height - h) / 2,
         "bottom": rect.y1 - margin - h}.get(v, rect.y0 + (rect.height - h) / 2)
    return pymupdf.Point(x, y)


def add_image_watermark(src, out, image, pages: str = "all", scale: float = 0.4,
                        opacity: float = 0.3, angle: float = 0.0,
                        position: str = "middle-center", margin: float = 20.0,
                        tile: bool = False, progress: Progress = None) -> str:
    """Stamp a picture (logo, signature ...). ``scale`` = image width as a
    fraction of page width. PNG with transparency works best."""
    _check_out(src, out)
    if not 0.02 <= scale <= 2:
        raise PDFError("Scale must be between 2% and 200% of the page width.")
    try:
        img = imaging.prepare_watermark(image, opacity, angle)
    except imaging.ImageError as exc:
        raise PDFError(f"Cannot read the watermark image: {exc}") from exc
    data = img.data
    ratio = img.height / img.width
    with open_pdf(src) as doc:
        idx = parse_pages(pages, doc.page_count)
        for k, i in enumerate(idx, 1):
            page = doc[i]
            _upright(page)
            r = page.rect
            w = r.width * scale
            h = w * ratio
            if tile:
                gx, gy = w * 1.5, h * 1.8
                y = r.y0
                while y < r.y1:
                    x = r.x0
                    while x < r.x1:
                        page.insert_image(pymupdf.Rect(x, y, x + w, y + h),
                                          stream=data, overlay=True)
                        x += gx
                    y += gy
            else:
                p = _anchor(r, w, h, position, margin)
                page.insert_image(pymupdf.Rect(p.x, p.y, p.x + w, p.y + h),
                                  stream=data, overlay=True)
            _tick(progress, k, len(idx))
        return _save(doc, out)


POSITIONS = ["top-left", "top-center", "top-right",
             "bottom-left", "bottom-center", "bottom-right"]


def add_stamp(src, out, template: str = "Page {n} of {total}", pages: str = "all",
              position: str = "bottom-center", fontsize: float = 10,
              color="#000000", margin: float = 28.0, start: int = 1,
              skip_first: bool = False, fontfile: str | None = None,
              progress: Progress = None) -> str:
    """Header / footer / page numbers.

    Placeholders: {n} page number (= ``start`` + page index), {total} number
    of pages in the document, {file} file name, {date} today (YYYY-MM-DD).
    Scripts that need shaping (Hindi, Bengali, Arabic ...) are drawn by Qt as a
    picture, everything else as real PDF text.
    """
    _check_out(src, out)
    if position not in POSITIONS:
        raise PDFError(f"Unknown position '{position}'.")
    if not template.strip():
        raise PDFError("Enter the text to stamp (for page numbers use {n}).")
    col = _color(color)
    today = _dt.date.today().isoformat()
    with open_pdf(src) as doc:
        total = doc.page_count
        idx = parse_pages(pages, total)
        if skip_first and 0 in idx:
            idx.remove(0)
        texts = {i: (template.replace("{n}", str(start + i))
                     .replace("{total}", str(start + total - 1))
                     .replace("{file}", Path(str(src)).name)
                     .replace("{date}", today)) for i in idx}
        raster = any(_needs_raster_text(t, fontfile) for t in texts.values())
        font = None
        if not raster:
            font = _load_font(fontfile)
            _check_glyphs(font, " ".join(texts.values()))
        cache: dict[str, tuple] = {}
        for k, i in enumerate(idx, 1):
            page = doc[i]
            _upright(page)
            text = texts[i]
            if raster:
                if text not in cache:
                    cache[text] = _shaped_text_image(text, fontsize, color, fontfile)
                img, w, h = cache[text]
                p = _anchor(page.rect, w, h, position, margin)
                page.insert_image(pymupdf.Rect(p.x, p.y, p.x + w, p.y + h), stream=img.data, overlay=True)
            else:
                w = font.text_length(text, fontsize=fontsize)
                p = _anchor(page.rect, w, fontsize, position, margin)
                tw = pymupdf.TextWriter(page.rect, color=col)
                tw.append((p.x, p.y + fontsize * 0.85), text, font=font, fontsize=fontsize)
                tw.write_text(page, overlay=True)
            _tick(progress, k, len(idx))
        return _save(doc, out)


# --------------------------------------------------------------------------
# Security, metadata, forms
# --------------------------------------------------------------------------
def encrypt_pdf(src, out, user_pw: str, owner_pw: str | None = None,
                allow_print: bool = True, allow_copy: bool = True,
                allow_modify: bool = False, allow_annotate: bool = False,
                progress: Progress = None) -> str:
    """AES-256 protection. ``user_pw`` is needed to open the file (may be
    empty to only restrict permissions, then ``owner_pw`` is required)."""
    _check_out(src, out)
    if not user_pw and not owner_pw:
        raise PDFError("Enter a password.")
    # With identical user/owner passwords every viewer is the "owner" and the
    # restrictions would mean nothing, so use a random owner password.
    if not owner_pw or owner_pw == user_pw:
        owner_pw = secrets.token_urlsafe(18)
    perms = int(pymupdf.PDF_PERM_ACCESSIBILITY)
    if allow_print:
        perms |= pymupdf.PDF_PERM_PRINT | pymupdf.PDF_PERM_PRINT_HQ
    if allow_copy:
        perms |= pymupdf.PDF_PERM_COPY
    if allow_modify:
        perms |= pymupdf.PDF_PERM_MODIFY | pymupdf.PDF_PERM_ASSEMBLE | pymupdf.PDF_PERM_FORM
    if allow_annotate:
        perms |= pymupdf.PDF_PERM_ANNOTATE | pymupdf.PDF_PERM_FORM
    with open_pdf(src) as doc:
        return _save(doc, out, encryption=pymupdf.PDF_ENCRYPT_AES_256,
                     owner_pw=owner_pw, user_pw=user_pw or "", permissions=perms)


def decrypt_pdf(src, out, password: str = "", progress: Progress = None) -> str:
    """Remove password protection (you must know the password)."""
    _check_out(src, out)
    try:
        with pymupdf.open(str(src)) as probe:
            was_encrypted = bool(probe.is_encrypted or probe.needs_pass)
    except Exception as exc:
        raise PDFError(f"Cannot open '{os.path.basename(str(src))}': {exc}") from exc
    if not was_encrypted:
        raise PDFError("This PDF is not password protected.")
    with open_pdf(src, password or None) as doc:
        return _save(doc, out)


def set_metadata(src, out, title: str | None = None, author: str | None = None,
                 subject: str | None = None, keywords: str | None = None,
                 clear_all: bool = False, progress: Progress = None) -> str:
    _check_out(src, out)
    with open_pdf(src) as doc:
        if clear_all:
            doc.set_metadata({})
            try:
                doc.del_xml_metadata()
            except Exception:
                pass
        else:
            meta = dict(doc.metadata or {})
            for key, val in (("title", title), ("author", author),
                             ("subject", subject), ("keywords", keywords)):
                if val is not None:
                    meta[key] = val
            doc.set_metadata(meta)
        return _save(doc, out)


def flatten_pdf(src, out, progress: Progress = None) -> str:
    """Burn form fields and annotations into the page (no longer editable)."""
    _check_out(src, out)
    with open_pdf(src) as doc:
        doc.bake(annots=True, widgets=True)
        return _save(doc, out)
