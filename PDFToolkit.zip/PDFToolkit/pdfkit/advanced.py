"""Advanced tools: OCR, replace text, redaction, digital signatures, bookmarks,
page labels and blank-page removal.

Like ``ops`` this module has no GUI code. It reuses ``ops`` helpers and errors.
"""
from __future__ import annotations

import os
import re
import sys
from pathlib import Path
from typing import Sequence

import pymupdf

from . import imaging, ops
from .ops import (PDFError, Progress, _apply_labels, _check_out, _color, _copy_attachments, _finish_copy,
                  _needs_raster_text, _page_labels, _save, _shaped_text_image, _tick, _upright, open_pdf,
                  parse_pages)


# ==========================================================================
# OCR (needs the free Tesseract language data, see docs)
# ==========================================================================
def _tessdata_candidates() -> list[str]:
    here = Path(__file__).resolve().parent.parent
    c = [os.environ.get("TESSDATA_PREFIX", ""), str(here / "tessdata"),
         str(Path(getattr(sys, "_MEIPASS", "")) / "tessdata") if getattr(sys, "_MEIPASS", None) else "",
         str(Path(sys.executable).parent / "tessdata"), str(Path.home() / "PDFToolkit" / "tessdata")]
    try:
        c.append(pymupdf.get_tessdata() or "")
    except Exception:
        pass
    if sys.platform.startswith("win"):
        for base in (os.environ.get("ProgramFiles", r"C:\Program Files"),
                     os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")):
            c.append(os.path.join(base, "Tesseract-OCR", "tessdata"))
    else:
        c += ["/usr/share/tesseract-ocr/5/tessdata", "/usr/share/tesseract-ocr/4.00/tessdata",
              "/usr/share/tessdata", "/usr/local/share/tessdata", "/opt/homebrew/share/tessdata",
              "/usr/share/tesseract-ocr/tessdata"]
    return [x for x in c if x]


def tessdata_dir() -> str | None:
    """Folder that holds ``*.traineddata`` files, or None."""
    for d in _tessdata_candidates():
        try:
            if os.path.isdir(d) and any(f.endswith(".traineddata") for f in os.listdir(d)):
                return d
        except OSError:
            continue
    return None


def ocr_languages() -> list[str]:
    d = tessdata_dir()
    if not d:
        return []
    return sorted(f[:-12] for f in os.listdir(d) if f.endswith(".traineddata") and f != "osd.traineddata")


OCR_HELP = (
    "OCR needs the free Tesseract language files. Download '<code>.traineddata' files (for example 'ben') from "
    "https://github.com/tesseract-ocr/tessdata_fast and put them into the 'tessdata' folder next to main.py. "
    "English and Hindi are included. See the documentation, section 'OCR'.")


def _page_has_text(page: pymupdf.Page) -> bool:
    return len(page.get_text("text").strip()) >= 5


def ocr_pdf(src, out, lang: str = "eng", dpi: int = 300, pages: str = "all", skip_text: bool = True,
            progress: Progress = None, stats: dict | None = None) -> str:
    """Make scanned pages searchable. Each recognised page becomes its picture
    plus an invisible text layer (select / copy / search work). Pages that
    already contain text are copied unchanged when ``skip_text`` is set."""
    _check_out(src, out)
    tess = tessdata_dir()
    if not tess:
        raise PDFError("No OCR language data found.\n\n" + OCR_HELP)
    have = set(ocr_languages())
    langs = [l for l in re.split(r"[+,\s]+", lang.strip()) if l]
    if not langs:
        raise PDFError("Choose at least one OCR language.")
    missing = [l for l in langs if l not in have]
    if missing:
        raise PDFError(f"OCR language data missing: {', '.join(missing)}.\n\n" + OCR_HELP)
    if not 72 <= dpi <= 600:
        raise PDFError("OCR resolution must be between 72 and 600 DPI.")
    with open_pdf(src) as doc:
        n = doc.page_count
        sel = set(parse_pages(pages, n))
        new = pymupdf.open()
        done = skipped = 0
        for i in range(n):
            page = doc[i]
            if i in sel and not (skip_text and _page_has_text(page)):
                pix = page.get_pixmap(dpi=dpi, alpha=False)
                try:
                    data = pix.pdfocr_tobytes(language="+".join(langs), tessdata=tess)
                except Exception as exc:
                    raise PDFError(f"OCR failed on page {i + 1}: {exc}") from exc
                with pymupdf.open("pdf", data) as part:
                    new.insert_pdf(part)
                done += 1
            else:
                new.insert_pdf(doc, from_page=i, to_page=i)
                skipped += 1
            _tick(progress, i + 1, n)
        if not done:
            raise PDFError("Nothing to recognise: every selected page already has text "
                           "(untick 'Skip pages that already have text' to force OCR).")
        _finish_copy(doc, new)
        if stats is not None:
            stats.update(recognised=done, skipped=skipped)
        return _save(new, out)


# ==========================================================================
# Replace text / redact
# ==========================================================================
_FONTS = {  # (serif, mono) -> base-14 names for regular, bold, italic, bold+italic
    (False, False): ("helv", "hebo", "heit", "hebi"),
    (True, False): ("tiro", "tibo", "tiit", "tibi"),
    (False, True): ("cour", "cobo", "coit", "cobi"),
}


def _hits(page: pymupdf.Page, term: str, match_case: bool, regex: bool) -> list[pymupdf.Rect]:
    """Rectangles of every occurrence of ``term`` on the page."""
    if regex:
        try:
            pat = re.compile(term, 0 if match_case else re.IGNORECASE)
        except re.error as exc:
            raise PDFError(f"Bad pattern '{term}': {exc}") from exc
        strings = {m.group(0) for m in pat.finditer(page.get_text("text")) if m.group(0).strip()}
    else:
        strings = {term}
    out: list[pymupdf.Rect] = []
    for s in sorted(strings, key=len, reverse=True):
        for r in page.search_for(s):
            if match_case and not regex and s not in page.get_textbox(r + (-2, -2, 2, 2)):
                continue
            if not any(r in o for o in out):
                out.append(r)
    return out


def _page_spans(page: pymupdf.Page) -> list[dict]:
    """Text spans of the page (read once per page: much faster than one query per hit)."""
    out = []
    for block in page.get_text("dict")["blocks"]:
        for line in block.get("lines", []):
            for span in line["spans"]:
                if span["text"].strip():
                    out.append(span)
    return out


def _style_at(page: pymupdf.Page, rect: pymupdf.Rect, spans: list[dict] | None = None):
    """(fontsize, flags, colour, baseline origin (x, y), reading direction) of the text under ``rect``."""
    best, best_area = None, 0.0
    for span in (spans if spans is not None else _page_spans(page)):
        inter = pymupdf.Rect(span["bbox"]) & rect
        area = 0 if inter.is_empty else inter.width * inter.height
        if area > best_area:
            best, best_area = span, area
    if not best:
        return rect.height * 0.85, 0, (0, 0, 0), (rect.x0, rect.y1 - rect.height * 0.2), (1.0, 0.0)
    c = best["color"]
    return (best["size"], best["flags"], ((c >> 16 & 255) / 255, (c >> 8 & 255) / 255, (c & 255) / 255),
            tuple(best["origin"]), tuple(best.get("dir", (1.0, 0.0))))


def _redaction_flags() -> dict:
    return dict(
        images=getattr(pymupdf, "PDF_REDACT_IMAGE_PIXELS", 2),
        graphics=getattr(pymupdf, "PDF_REDACT_LINE_ART_REMOVE_IF_COVERED", 1),
    )


def replace_text(src, out, find: str, replacement: str, pages: str = "all", match_case: bool = False,
                 shrink: bool = True, fontfile: str | None = None, progress: Progress = None,
                 stats: dict | None = None) -> str:
    """Replace every occurrence of ``find`` by ``replacement``.

    The old text is removed from the page (not just covered). The new text is
    drawn with the closest standard font (Helvetica / Times / Courier, bold and
    italic kept) in the original size and colour; non-Latin text uses Qt shaping
    and is placed as a picture. Only text, not the surrounding layout, is edited."""
    _check_out(src, out)
    if not find:
        raise PDFError("Enter the text to find.")
    with open_pdf(src) as doc:
        idx = parse_pages(pages, doc.page_count)
        total = 0
        for k, i in enumerate(idx, 1):
            page = doc[i]          # rotated pages are handled by following the text direction
            hits = _hits(page, find, match_case, False)
            if hits:
                plan = []
                words = [w[:4] for w in page.get_text("words")]
                spans = _page_spans(page)
                for r in hits:
                    st = _style_at(page, r, spans)
                    room = _room(page, r, _rotation_of(st[4]), words) if shrink else None
                    plan.append((r,) + st + (room,))
                    page.add_redact_annot(r + (0.3, 0.3, -0.3, -0.3), fill=False)
                page.apply_redactions(**_redaction_flags())
                for r, size, flags, col, base, direction, room in plan:
                    _draw_replacement(page, r, replacement, size, flags, col, base, direction, room, fontfile)
                total += len(hits)
            _tick(progress, k, len(idx))
        if not total:
            raise PDFError(f"The text '{find}' was not found"
                           + (" (check upper/lower case)." if match_case else ".")
                           + "\nScanned pages have no text to find - run OCR first.")
        if stats is not None:
            stats["replaced"] = total
        return _save(doc, out)


def _rotation_of(direction) -> int:
    import math
    return int(round(math.degrees(math.atan2(-direction[1], direction[0])) / 90.0)) * 90 % 360


def _room(page, rect, rot, words) -> float:
    """Length available for the new text along the reading direction: from the start of the
    match to the next word on the same line (or to the page margin when nothing follows)."""
    vertical = rot in (90, 270)
    gap = 2.0
    best = None
    for x0, y0, x1, y1 in words:
        if vertical:
            across = min(x1, rect.x1) - max(x0, rect.x0)
            ok = across > 0.5 * min(x1 - x0, rect.width)
            if rot == 90 and ok and y1 <= rect.y0 + 0.5:
                d = rect.y1 - y1
            elif rot == 270 and ok and y0 >= rect.y1 - 0.5:
                d = y0 - rect.y0
            else:
                continue
        else:
            across = min(y1, rect.y1) - max(y0, rect.y0)
            ok = across > 0.5 * min(y1 - y0, rect.height)
            if rot == 0 and ok and x0 >= rect.x1 - 0.5:
                d = x0 - rect.x0
            elif rot == 180 and ok and x1 <= rect.x0 + 0.5:
                d = rect.x1 - x1
            else:
                continue
        best = d if best is None else min(best, d)
    if best is not None:
        return max(best - gap, rect.height if vertical else rect.width)   # never less than the old text
    ub = page.rect * page.derotation_matrix      # visible area in the same (unrotated) space as the match
    ub.normalize()
    margin = 18.0
    if rot == 0:
        return max(ub.x1 - margin - rect.x0, rect.width)
    if rot == 180:
        return max(rect.x1 - (ub.x0 + margin), rect.width)
    if rot == 90:
        return max(rect.y1 - (ub.y0 + margin), rect.height)
    return max(ub.y1 - margin - rect.y0, rect.height)


def _draw_replacement(page, rect, text, size, flags, col, base, direction, room, fontfile):
    """``room`` = length available along the text (None: never shrink)."""
    if not text:
        return
    rot = _rotation_of(direction)
    if _needs_raster_text(text, fontfile):
        img, w, h = _shaped_text_image(text, size, "#%02x%02x%02x" % tuple(round(c * 255) for c in col), fontfile)
        if room and w > room:
            f = room / w
            w, h = w * f, h * f
        if rot == 0:
            top = rect.y0 + (rect.height - h) / 2
            box = pymupdf.Rect(rect.x0, top, rect.x0 + w, top + h)
        elif rot == 180:
            top = rect.y0 + (rect.height - h) / 2
            box = pymupdf.Rect(rect.x1 - w, top, rect.x1, top + h)
        else:
            left = rect.x0 + (rect.width - h) / 2
            y0 = rect.y1 - w if rot == 90 else rect.y0
            box = pymupdf.Rect(left, y0, left + h, y0 + w)
        orig = page.rotation
        try:
            page.set_rotation(0)         # insert_image mis-places on rotated pages that have a crop box
            page.insert_image(box, stream=img.data, overlay=True, rotate=rot, keep_proportion=False)
        finally:
            page.set_rotation(orig)
        return
    serif, mono = bool(flags & 4), bool(flags & 8)
    names = _FONTS[(serif and not mono, mono)]
    name = names[(1 if flags & 16 else 0) + (2 if flags & 2 else 0)]
    if fontfile:
        font = ops._load_font(fontfile)
        kw = dict(fontfile=fontfile, fontname="F_user")
    else:
        font = pymupdf.Font(name)
        kw = dict(fontname=name)
        ops._check_glyphs(font, text)
    length = font.text_length(text, fontsize=size)
    if room and length > room:
        size = size * room / length
    # start of the text: along the reading direction at the match edge, on the baseline across it
    if rot == 0:
        pt = (rect.x0, base[1])
    elif rot == 180:
        pt = (rect.x1, base[1])
    elif rot == 90:
        pt = (base[0], rect.y1)
    else:
        pt = (base[0], rect.y0)
    page.insert_text(pt, text, fontsize=size, color=col, rotate=rot, **kw)


PATTERNS = {
    "email": r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}",
    "phone": r"(?<!\d)(?:\+?\d{1,3}[\s-]?)?(?:\d[\s-]?){9,11}\d(?!\d)",
    "aadhaar": r"(?<!\d)\d{4}\s\d{4}\s\d{4}(?!\d)",
    "pan": r"\b[A-Z]{5}\d{4}[A-Z]\b",
    "card": r"(?<!\d)(?:\d{4}[\s-]?){3}\d{4}(?!\d)",
}


def redact_text(src, out, terms: Sequence[str] = (), patterns: Sequence[str] = (), pages: str = "all",
                match_case: bool = False, fill: str = "#000000", progress: Progress = None,
                stats: dict | None = None) -> str:
    """Permanently remove text (and the picture pixels under it) and paint a box.

    ``terms`` are exact texts; ``patterns`` are keys of ``PATTERNS`` (email, phone,
    aadhaar, pan, card) or any regular expression prefixed with ``re:``."""
    _check_out(src, out)
    terms = [t for t in (t.strip() for t in terms) if t]
    jobs: list[tuple[str, bool]] = [(t, False) for t in terms]
    for p in patterns:
        if p.startswith("re:"):
            jobs.append((p[3:], True))
        elif p in PATTERNS:
            jobs.append((PATTERNS[p], True))
        else:
            raise PDFError(f"Unknown pattern '{p}'.")
    if not jobs:
        raise PDFError("Enter at least one text to remove, or choose a pattern.")
    colour = _color(fill)
    with open_pdf(src) as doc:
        idx = parse_pages(pages, doc.page_count)
        total = 0
        for k, i in enumerate(idx, 1):
            page = doc[i]
            if page.rotation:
                _upright(page)
            count = 0
            for term, rx in jobs:
                for r in _hits(page, term, match_case, rx):
                    page.add_redact_annot(r, fill=colour)
                    count += 1
            if count:
                page.apply_redactions(**_redaction_flags())
                total += count
            _tick(progress, k, len(idx))
        if not total:
            raise PDFError("Nothing matched, so nothing was redacted.\n"
                           "Scanned pages have no text to find - run OCR first.")
        if stats is not None:
            stats["redacted"] = total
        return _save(doc, out)


# ==========================================================================
# Digital signatures (pyHanko)
# ==========================================================================
def _need_hanko():
    try:
        import pyhanko  # noqa: F401
    except ImportError as exc:
        raise PDFError("Digital signatures need the 'pyhanko' package.\n"
                       "Run:  pip install pyhanko   (or start the program with the launcher once more).") from exc
    # pyHanko stamps the local time zone; an unusable TZ setting must not stop signing.
    try:
        import tzlocal
        tzlocal.get_localzone()
    except Exception:
        os.environ["TZ"] = "UTC"
        try:
            import tzlocal
            tzlocal.reload_localzone()
        except Exception:
            pass


def create_certificate(path, name: str, password: str, org: str = "", email: str = "", days: int = 1095) -> str:
    """Create a self-signed signing certificate (.p12 / .pfx) protected by ``password``."""
    import datetime as dt
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.serialization import pkcs12
    from cryptography.hazmat.primitives.asymmetric import rsa
    from cryptography.x509.oid import NameOID
    if not name.strip():
        raise PDFError("Enter the name to put in the certificate.")
    if len(password) < 4:
        raise PDFError("Choose a password with at least 4 characters for the certificate file.")
    attrs = [x509.NameAttribute(NameOID.COMMON_NAME, name.strip())]
    if org.strip():
        attrs.append(x509.NameAttribute(NameOID.ORGANIZATION_NAME, org.strip()))
    if email.strip():
        attrs.append(x509.NameAttribute(NameOID.EMAIL_ADDRESS, email.strip()))
    subject = x509.Name(attrs)
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    now = dt.datetime.now(dt.timezone.utc)
    cert = (x509.CertificateBuilder().subject_name(subject).issuer_name(subject).public_key(key.public_key())
            .serial_number(x509.random_serial_number()).not_valid_before(now - dt.timedelta(minutes=5))
            .not_valid_after(now + dt.timedelta(days=int(days)))
            .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
            .add_extension(x509.KeyUsage(digital_signature=True, content_commitment=True, key_encipherment=False,
                                         data_encipherment=False, key_agreement=False, key_cert_sign=False,
                                         crl_sign=False, encipher_only=False, decipher_only=False), critical=True)
            .sign(key, hashes.SHA256()))
    data = pkcs12.serialize_key_and_certificates(
        name.strip().encode(), key, cert, None, serialization.BestAvailableEncryption(password.encode()))
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_bytes(data)
    return str(path)


def sign_pdf(src, out, p12, password: str, reason: str = "", location: str = "", contact: str = "",
             visible: bool = True, page: int = 1, position: str = "bottom-right",
             width: float = 200, height: float = 60, progress: Progress = None,
             stats: dict | None = None) -> str:
    """Add a cryptographic signature (PAdES / PDF 1.7) with a .p12/.pfx certificate.

    The file is signed as an *incremental update*, so it must not be modified
    afterwards (any later edit makes the signature invalid)."""
    _need_hanko()
    _check_out(src, out)
    if not p12 or not os.path.isfile(str(p12)):
        raise PDFError("Choose the certificate file (.p12 / .pfx).")
    with open_pdf(src) as d:     # also validates the file; refuses protected files
        if d.is_encrypted or d.needs_pass:
            raise PDFError("Remove the password first (Remove password tool) - sign the document, "
                           "then do not change it again.")
        count = d.page_count
        if visible:
            if not 1 <= page <= count:
                raise PDFError(f"Page {page} does not exist (the document has {count} pages).")
            pg = d[page - 1]
            if pg.rotation:      # the stamp text would come out sideways: sign invisibly instead
                visible = False
                if stats is not None:
                    stats["invisible_because_rotated"] = True
        if visible:
            view = pg.rect
            w, h = min(width, view.width - 20), min(height, view.height - 20)
            xs = {"left": 20, "center": (view.width - w) / 2, "right": view.width - w - 20}
            ys = {"top": 20, "middle": (view.height - h) / 2, "bottom": view.height - h - 20}
            vert, _, horiz = position.partition("-")
            horiz = horiz or "center"
            x0, y0 = view.x0 + xs[horiz], view.y0 + ys[vert if vert in ys else "bottom"]
            r = pymupdf.Rect(x0, y0, x0 + w, y0 + h) * pg.derotation_matrix   # to unrotated page space
            r.normalize()
            mb = pg.mediabox
            cb = pg.cropbox
            # PyMuPDF space is y-down from the crop box; PDF space is y-up from the media box
            box = (r.x0 + cb.x0 - mb.x0, mb.height - (r.y1 + cb.y0 - mb.y0) + 0,
                   r.x1 + cb.x0 - mb.x0, mb.height - (r.y0 + cb.y0 - mb.y0) + 0)
    from pyhanko.pdf_utils.incremental_writer import IncrementalPdfFileWriter
    from pyhanko.sign import fields, signers
    from pyhanko.stamp import TextStampStyle
    try:
        signer = signers.SimpleSigner.load_pkcs12(pfx_file=str(p12), passphrase=password.encode() if password else None)
    except Exception as exc:
        raise PDFError("The certificate could not be opened - wrong password or not a .p12/.pfx file.") from exc
    if signer is None:
        raise PDFError("The certificate file has no private key.")
    field = "Signature1"
    try:
        with open(str(src), "rb") as fh:
            w = IncrementalPdfFileWriter(fh, strict=False)
            existing = {f for f, _, _ in fields.enumerate_sig_fields(w)}
            k = 1
            while field in existing:
                k += 1
                field = f"Signature{k}"
            if visible:
                fields.append_signature_field(w, fields.SigFieldSpec(field, on_page=page - 1, box=tuple(box)))
            meta = signers.PdfSignatureMetadata(field_name=field, reason=reason or None,
                                                location=location or None, contact_info=contact or None)
            style = TextStampStyle(stamp_text="Digitally signed by %(signer)s\nDate: %(ts)s"
                                   + (f"\nReason: {reason}" if reason else "")
                                   + (f"\nLocation: {location}" if location else ""),
                                   border_width=1)
            sig = signers.PdfSigner(meta, signer=signer, stamp_style=style if visible else None)
            Path(out).parent.mkdir(parents=True, exist_ok=True)
            tmp = str(out) + ".part"
            with open(tmp, "wb") as fo:
                sig.sign_pdf(w, output=fo)
        os.replace(tmp, str(out))
    except PDFError:
        raise
    except Exception as exc:
        try:
            os.remove(str(out) + ".part")
        except OSError:
            pass
        raise PDFError(f"Signing failed: {exc}") from exc
    _tick(progress, 1, 1)
    return str(out)


def verify_signatures(src) -> list[dict]:
    """Information about every signature: signer, intact, covers whole file, trusted."""
    _need_hanko()
    from pyhanko.pdf_utils.reader import PdfFileReader
    from pyhanko.sign.validation import validate_pdf_signature
    import logging
    for name in ("pyhanko", "pyhanko_certvalidator"):   # self-signed certificates are normal here
        logging.getLogger(name).setLevel(logging.CRITICAL)
    res: list[dict] = []
    try:
        with open(str(src), "rb") as fh:
            r = PdfFileReader(fh, strict=False)
            if r.encrypted:
                raise PDFError("The file is password protected; remove the password first.")
            for s in r.embedded_signatures:
                try:
                    st = validate_pdf_signature(s)
                    cov = str(getattr(st.coverage, "name", st.coverage))
                    res.append(dict(field=s.field_name, signer=st.signing_cert.subject.human_friendly,
                                    intact=bool(st.intact), valid=bool(st.valid),
                                    whole_file=cov == "ENTIRE_FILE", trusted=bool(st.trusted),
                                    time=str(s.self_reported_timestamp or "")))
                except Exception as exc:
                    res.append(dict(field=s.field_name, signer="?", intact=False, valid=False,
                                    whole_file=False, trusted=False, time="", error=str(exc)))
    except PDFError:
        raise
    except Exception as exc:
        raise PDFError(f"Cannot read the file for verification: {exc}") from exc
    return res


def verify_report(src, out) -> str:
    """Write a plain-text verification report to ``out``."""
    sigs = verify_signatures(src)
    lines = [f"Signature report for {Path(src).name}", ""]
    if not sigs:
        lines.append("This PDF contains no digital signatures.")
    for k, s in enumerate(sigs, 1):
        status = ("VALID - the document is unchanged since signing" if s["valid"] and s["whole_file"]
                  else "CHANGED or damaged after signing" if not s["intact"]
                  else "Signature is intact, but the file was extended after signing")
        lines += [f"Signature {k} ({s['field']})", f"  Signer : {s['signer']}", f"  Status : {status}",
                  f"  Trusted: {'yes' if s['trusted'] else 'no (self-signed or unknown issuer - normal for personal certificates)'}"]
        if s.get("error"):
            lines.append(f"  Detail : {s['error']}")
        lines.append("")
    Path(out).parent.mkdir(parents=True, exist_ok=True)
    Path(out).write_text("\n".join(lines), encoding="utf-8")
    return str(out)


# ==========================================================================
# Bookmarks, page labels, blank pages
# ==========================================================================
def get_bookmarks_text(src) -> str:
    """Existing bookmarks as editable text: indent two spaces per level, 'Title | page'."""
    with open_pdf(src) as d:
        return "\n".join("  " * (lvl - 1) + f"{title} | {pg}" for lvl, title, pg in d.get_toc(simple=True))


def parse_bookmarks(text: str, page_count: int) -> list[list]:
    toc: list[list] = []
    for n, raw in enumerate(text.splitlines(), 1):
        if not raw.strip():
            continue
        body = raw.replace("\t", "  ")
        indent = len(body) - len(body.lstrip(" "))
        title, sep, page = body.strip().rpartition("|")
        if not sep or not title.strip():
            raise PDFError(f"Line {n}: write it as  Title | page   (for example: Chapter 1 | 5).")
        try:
            pg = int(page.strip())
        except ValueError:
            raise PDFError(f"Line {n}: '{page.strip()}' is not a page number.") from None
        if not 1 <= pg <= page_count:
            raise PDFError(f"Line {n}: page {pg} does not exist (the document has {page_count} pages).")
        lvl = indent // 2 + 1
        prev = toc[-1][0] if toc else 0
        toc.append([min(lvl, prev + 1), title.strip(), pg])
    return toc


def set_bookmarks(src, out, text: str, clear: bool = False, progress: Progress = None) -> str:
    """Replace the bookmark tree by ``text`` (see ``get_bookmarks_text``)."""
    _check_out(src, out)
    with open_pdf(src) as d:
        toc = [] if clear else parse_bookmarks(text, d.page_count)
        if not clear and not toc:
            raise PDFError("Write at least one bookmark, or tick 'Remove all bookmarks'.")
        d.set_toc(toc)
        return _save(d, out)


LABEL_STYLES = {"1, 2, 3": "D", "i, ii, iii": "r", "I, II, III": "R", "a, b, c": "a", "A, B, C": "A", "(no number)": ""}


def set_page_labels(src, out, start_page: int = 1, style: str = "D", prefix: str = "", first: int = 1,
                    clear: bool = False, progress: Progress = None) -> str:
    """Add a labelling rule that starts at ``start_page`` (1-based) and runs to the
    next rule or the end; ``clear`` removes every label."""
    _check_out(src, out)
    with open_pdf(src) as d:
        if not clear and not 1 <= start_page <= d.page_count:
            raise PDFError(f"Page {start_page} does not exist (the document has {d.page_count} pages).")
        if first < 0:
            raise PDFError("The first number cannot be negative.")
        rules = [] if clear else [r for r in d.get_page_labels() if r["startpage"] != start_page - 1]
        if not clear:
            if not rules and start_page > 1:
                rules.append({"startpage": 0, "prefix": "", "style": "D", "firstpagenum": 1})
            rules.append({"startpage": start_page - 1, "prefix": prefix, "style": style, "firstpagenum": max(first, 1)})
            rules.sort(key=lambda r: r["startpage"])
        if clear:
            d.xref_set_key(d.pdf_catalog(), "PageLabels", "null")
        else:
            d.set_page_labels(rules)
        return _save(d, out)


def find_blank_pages(doc: pymupdf.Document, sensitivity: float = 0.3, progress: Progress = None) -> list[int]:
    """Indices of pages without visible content. ``sensitivity`` is the percentage of
    dark pixels (page edges ignored) below which a page counts as blank."""
    table = bytes(1 if b < 200 else 0 for b in range(256))
    blank = []
    n = doc.page_count
    for i in range(n):
        pg = doc[i]
        r = pg.rect
        clip = pymupdf.Rect(r.x0 + r.width * 0.03, r.y0 + r.height * 0.03, r.x1 - r.width * 0.03, r.y1 - r.height * 0.03)
        pix = pg.get_pixmap(dpi=50, colorspace=pymupdf.csGRAY, clip=clip, alpha=False)
        dark = pix.samples.translate(table).count(1)
        if dark * 100.0 / max(len(pix.samples), 1) <= sensitivity:
            blank.append(i)
        _tick(progress, i + 1, n)
    return blank


def remove_blank_pages(src, out, sensitivity: float = 0.3, progress: Progress = None,
                       stats: dict | None = None) -> str:
    """Delete pages that look empty (typical for double-sided scans)."""
    _check_out(src, out)
    with open_pdf(src) as d:
        blank = find_blank_pages(d, sensitivity, progress)
        keep = [i for i in range(d.page_count) if i not in set(blank)]
    if not blank:
        raise PDFError("No blank pages were found. Raise the sensitivity if scan noise makes empty pages look dirty.")
    if not keep:
        raise PDFError("Every page looks blank - nothing would be left. Lower the sensitivity.")
    if stats is not None:
        stats["removed"] = [i + 1 for i in blank]
    return ops.select_pages(src, out, keep)


# ==========================================================================
# Fill forms, highlight text
# ==========================================================================
_TRUE = {"yes", "true", "1", "on", "x", "checked", "y"}


def get_form_text(src) -> str:
    """The form's fields as editable lines 'name = value' (check boxes: Yes / No)."""
    lines = []
    with open_pdf(src) as d:
        seen = set()
        for page in d:
            for w in page.widgets() or []:
                if w.field_name in seen or w.field_type_string in ("Button", "Signature"):
                    continue
                seen.add(w.field_name)
                v = w.field_value
                if w.field_type_string in ("CheckBox", "RadioButton"):
                    v = "Yes" if v and str(v).lower() not in ("off", "false", "0") else "No"
                lines.append(f"{w.field_name} = {v if v is not None else ''}")
    return "\n".join(lines)


def fill_form(src, out, text: str, flatten: bool = False, progress: Progress = None, stats: dict | None = None) -> str:
    """Set form field values from lines 'name = value'. ``flatten`` makes them permanent."""
    _check_out(src, out)
    wanted: dict[str, str] = {}
    for n, raw in enumerate(text.splitlines(), 1):
        if not raw.strip():
            continue
        name, sep, value = raw.partition("=")
        if not sep or not name.strip():
            raise PDFError(f"Line {n}: write it as  field name = value")
        wanted[name.strip()] = value.strip()
    if not wanted:
        raise PDFError("There are no form fields to fill. Open a PDF with form fields.")
    with open_pdf(src) as d:
        done: set[str] = set()
        n = d.page_count
        for i, page in enumerate(d):
            for w in page.widgets() or []:
                if w.field_name not in wanted or w.field_type_string in ("Button", "Signature"):
                    continue
                val = wanted[w.field_name]
                try:
                    if w.field_type_string in ("CheckBox", "RadioButton"):
                        w.field_value = w.on_state() if val.lower() in _TRUE else "Off"
                    else:
                        w.field_value = val
                    w.update()
                    done.add(w.field_name)
                except Exception as exc:
                    raise PDFError(f"Cannot set field '{w.field_name}': {exc}") from exc
            _tick(progress, i + 1, n)
        missing = [k for k in wanted if k not in done]
        if not done:
            raise PDFError("None of the field names exist in this PDF (check the spelling).")
        if flatten:
            d.bake(annots=True, widgets=True)
        if stats is not None:
            stats.update(filled=len(done), missing=missing)
        return _save(d, out)


HIGHLIGHT_KINDS = ("highlight", "underline", "strikeout", "squiggly")


def highlight_text(src, out, terms: Sequence[str], kind: str = "highlight", color: str = "#ffff00",
                   pages: str = "all", match_case: bool = False, progress: Progress = None,
                   stats: dict | None = None) -> str:
    """Mark every occurrence of the given texts with a highlight / underline / strike-out annotation."""
    _check_out(src, out)
    terms = [t.strip() for t in terms if t.strip()]
    if not terms:
        raise PDFError("Enter at least one text to mark.")
    if kind not in HIGHLIGHT_KINDS:
        raise PDFError(f"Unknown marking style '{kind}'.")
    colour = _color(color)
    with open_pdf(src) as d:
        idx = parse_pages(pages, d.page_count)
        total = 0
        for k, i in enumerate(idx, 1):
            page = d[i]
            for t in terms:
                for r in _hits(page, t, match_case, False):
                    a = getattr(page, f"add_{kind}_annot")(r)
                    a.set_colors(stroke=colour)
                    a.update()
                    total += 1
            _tick(progress, k, len(idx))
        if not total:
            raise PDFError("The text was not found (scanned pages: run OCR first).")
        if stats is not None:
            stats["marked"] = total
        return _save(d, out)
