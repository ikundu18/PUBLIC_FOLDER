"""Image helpers (no Pillow).

* PNG and JPEG encoding of rendered pages uses PyMuPDF directly.
* Everything else (reading arbitrary image formats, EXIF rotation,
  transparency, opacity, rotation, WebP/TIFF/BMP output) uses Qt's QImage,
  which is already required by the GUI. QImage works without a running
  QApplication, so this module is safe to use from scripts and worker threads.
"""
from __future__ import annotations

import math
import os
import sys
from dataclasses import dataclass
from pathlib import Path

import pymupdf
from PySide6.QtCore import QBuffer, QIODevice, QPointF, Qt
from PySide6.QtGui import (
    QColor, QFont, QFontDatabase, QFontMetricsF, QImage, QImageIOHandler,
    QImageReader, QImageWriter, QPainter, QTransform,
)
from PySide6.QtWidgets import QApplication


# Qt (6.8+) refuses to decode images larger than 256 MB by default, which
# would reject big scans (e.g. a 600 dpi A3 page). Raise the limit.
try:
    QImageReader.setAllocationLimit(2048)
except Exception:  # older Qt without the setting: nothing to do
    pass


class ImageError(Exception):
    """Raised for unreadable / unsupported images (the engine converts it
    to a user-facing PDFError)."""


@dataclass
class LoadedImage:
    data: bytes        # PNG or JPEG bytes ready for PyMuPDF's insert_image
    width: int         # pixels, after EXIF rotation
    height: int
    has_alpha: bool


def _encode(img: QImage, fmt: str, quality: int = -1) -> bytes:
    buf = QBuffer()
    buf.open(QIODevice.WriteOnly)
    writer = QImageWriter(buf, fmt.encode())
    if quality >= 0:
        writer.setQuality(int(quality))
    if not writer.write(img):
        raise ImageError(f"Cannot encode image as {fmt}: {writer.errorString()}")
    buf.close()
    return bytes(buf.data())


def supported_write_formats() -> set[str]:
    return {bytes(f).decode().lower() for f in QImageWriter.supportedImageFormats()}


def read_qimage(path) -> QImage:
    """Load any image Qt understands, honouring EXIF orientation."""
    reader = QImageReader(str(path))
    reader.setAutoTransform(True)
    img = reader.read()
    if img.isNull():
        raise ImageError(reader.errorString() or "unsupported or damaged image")
    return img


def load_for_pdf(path) -> LoadedImage:
    """Return bytes PyMuPDF can embed. Plain JPEG/PNG files are passed
    through untouched (no quality loss); anything that needs conversion
    (EXIF-rotated, WebP, TIFF, BMP, GIF ...) is decoded and re-encoded."""
    path = Path(path)
    if not path.is_file():
        raise ImageError("file not found")
    reader = QImageReader(str(path))
    fmt = bytes(reader.format()).decode().lower()
    if fmt in ("jpeg", "jpg", "png") and reader.transformation() == QImageIOHandler.TransformationNone:
        size = reader.size()
        if size.isValid():
            # Cheap check that the image is not in an exotic colour mode
            # PyMuPDF might refuse (e.g. CMYK jpeg) is left to insert_image;
            # on failure the caller falls back to load_converted().
            return LoadedImage(path.read_bytes(), size.width(), size.height(),
                               fmt == "png")
    return load_converted(path)


def load_converted(path) -> LoadedImage:
    """Decode with Qt and re-encode: JPEG (q92) for lossy photos without
    transparency, PNG otherwise."""
    src_fmt = bytes(QImageReader(str(path)).format()).decode().lower()
    img = read_qimage(path)
    alpha = img.hasAlphaChannel()
    if alpha:
        img = img.convertToFormat(QImage.Format_ARGB32)
        return LoadedImage(_encode(img, "PNG"), img.width(), img.height(), True)
    img = img.convertToFormat(QImage.Format_RGB32)
    if src_fmt in ("jpeg", "jpg", "webp"):
        return LoadedImage(_encode(img, "JPEG", 92), img.width(), img.height(), False)
    return LoadedImage(_encode(img, "PNG"), img.width(), img.height(), False)


def prepare_watermark(path, opacity: float = 1.0, angle: float = 0.0) -> LoadedImage:
    """PNG with the requested opacity (0..1) and counter-clockwise rotation
    (degrees, canvas grows to fit)."""
    src = read_qimage(path).convertToFormat(QImage.Format_ARGB32)
    out = QImage(src.size(), QImage.Format_ARGB32)
    out.fill(0)  # fully transparent
    p = QPainter(out)
    p.setOpacity(max(0.0, min(1.0, opacity)))
    p.drawImage(0, 0, src)
    p.end()
    if angle:
        out = out.transformed(QTransform().rotate(-angle), Qt.SmoothTransformation)
    return LoadedImage(_encode(out, "PNG"), out.width(), out.height(), True)


def encode_pixmap(pix: pymupdf.Pixmap, fmt: str, quality: int = 90) -> bytes:
    """Encode a PyMuPDF pixmap as png / jpg / webp / tiff / bmp."""
    fmt = fmt.lower()
    if fmt == "png":
        return pix.tobytes("png")
    if fmt in ("jpg", "jpeg"):
        return pix.tobytes("jpg", jpg_quality=int(quality))
    if fmt not in supported_write_formats():
        raise ImageError(f"This Qt build cannot write '{fmt}' files.")
    if pix.alpha:
        pix = pymupdf.Pixmap(pix, 0)           # drop alpha
    if pix.colorspace is None or pix.colorspace.n != 3:
        pix = pymupdf.Pixmap(pymupdf.csRGB, pix)
    qimg = QImage(pix.samples, pix.width, pix.height, pix.stride, QImage.Format_RGB888).copy()
    return _encode(qimg, fmt.upper(), quality if fmt in ("webp", "jpg", "jpeg") else -1)


# --------------------------------------------------------------------------
# Text rendered with proper glyph shaping (Hindi, Bengali, Tamil, Arabic ...)
# --------------------------------------------------------------------------
# PyMuPDF's text writer places glyphs one by one, which is wrong for scripts
# that reorder / join letters (a Devanagari "ि" must be drawn BEFORE its
# consonant). Qt's text engine (HarfBuzz) shapes correctly, so such text is
# rendered by Qt into a transparent picture instead.

_app = None          # keeps the QApplication alive when used from a script


def ensure_app() -> None:
    """Qt needs an application object before it can use fonts. The GUI already
    has one; scripts and tests get a headless one created on demand."""
    global _app
    if QApplication.instance() is None:
        if (sys.platform.startswith("linux") and not os.environ.get("DISPLAY")
                and not os.environ.get("WAYLAND_DISPLAY")):
            os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
        _app = QApplication(["pdfkit"])


# (first code point, last code point, QFontDatabase.WritingSystem name, needs shaping)
_SCRIPTS = [
    (0x0590, 0x05FF, "Hebrew", True), (0x0600, 0x06FF, "Arabic", True), (0x0750, 0x077F, "Arabic", True),
    (0x08A0, 0x08FF, "Arabic", True), (0xFB50, 0xFDFF, "Arabic", True), (0xFE70, 0xFEFF, "Arabic", True),
    (0x0900, 0x097F, "Devanagari", True), (0x0980, 0x09FF, "Bengali", True),
    (0x0A00, 0x0A7F, "Gurmukhi", True), (0x0A80, 0x0AFF, "Gujarati", True),
    (0x0B00, 0x0B7F, "Oriya", True), (0x0B80, 0x0BFF, "Tamil", True),
    (0x0C00, 0x0C7F, "Telugu", True), (0x0C80, 0x0CFF, "Kannada", True),
    (0x0D00, 0x0D7F, "Malayalam", True), (0x0D80, 0x0DFF, "Sinhala", True),
    (0x0E00, 0x0E7F, "Thai", True), (0x0E80, 0x0EFF, "Lao", True), (0x0F00, 0x0FFF, "Tibetan", True),
    (0x1000, 0x109F, "Myanmar", True), (0x1780, 0x17FF, "Khmer", True),
    (0x0370, 0x03FF, "Greek", False), (0x0400, 0x052F, "Cyrillic", False),
    (0x10A0, 0x10FF, "Georgian", False), (0x0530, 0x058F, "Armenian", False),
    (0x3040, 0x30FF, "Japanese", False), (0xAC00, 0xD7AF, "Korean", False),
    (0x4E00, 0x9FFF, "SimplifiedChinese", False),
]


def _script_of(ch: str):
    cp = ord(ch)
    for lo, hi, name, shaping in _SCRIPTS:
        if lo <= cp <= hi:
            return name, shaping
    return None


def needs_shaping(text: str) -> bool:
    """True if the text contains a script whose letters must be reordered or
    joined (Indic scripts, Arabic, Hebrew, Thai, Khmer, Myanmar ...)."""
    return any((sc := _script_of(c)) and sc[1] for c in text)


_PREFERRED = ("Noto Sans", "Nirmala UI", "Segoe UI", "Mangal", "Vrinda", "Latha", "Shruti", "Kohinoor",
              "Devanagari Sangam", "Bangla Sangam", "Tamil Sangam", "Telugu Sangam", "Kannada Sangam",
              "Malayalam Sangam", "Gujarati Sangam", "Gurmukhi Sangam", "Lohit", "FreeSans", "Tahoma",
              "Arial Unicode", "DejaVu Sans", "Arial")
_AVOID = ("mono", "unifont", "code", "typewriter", "courier", "sample")


def _font_rank(name: str) -> tuple:
    """Lower is better: well-known sans-serif UI fonts first; monospace /
    bitmap fonts last (they break joined scripts such as Devanagari)."""
    low = name.lower()
    pref = next((i for i, p in enumerate(_PREFERRED) if low.startswith(p.lower())), len(_PREFERRED))
    penalty = (5 if any(w in low for w in _AVOID) else 0) + (2 if "serif" in low and "sans" not in low else 0) \
        + (1 if any(w in low for w in ("condensed", "narrow", "light", "black", "display", "ui ")) and pref == len(_PREFERRED) else 0)
    return (penalty, pref, name)


def _resolve_font(text: str, fontfile: str | None) -> QFont:
    ensure_app()
    if fontfile:
        fid = QFontDatabase.addApplicationFont(str(fontfile))
        fams = QFontDatabase.applicationFontFamilies(fid) if fid >= 0 else []
        if not fams:
            raise ImageError("the chosen font file cannot be loaded")
        return QFont(fams[0])
    chosen: list[str] = []
    seen = set()
    for ch in text:
        sc = _script_of(ch)
        if not sc or sc[0] in seen:
            continue
        seen.add(sc[0])
        ws = getattr(QFontDatabase.WritingSystem, sc[0], None)
        families = QFontDatabase.families(ws) if ws is not None else []
        if not families:
            raise ImageError(
                f"No font installed on this computer can show {sc[0]} text.\n"
                "Choose a font file (.ttf / .otf) that contains it in the 'Font' field.")
        best = min(families, key=_font_rank)
        if best not in chosen:
            chosen.append(best)
    if not chosen:
        return QFont()          # Latin text: Qt's default UI font
    font = QFont(chosen[0])
    font.setFamilies(chosen)    # one family per script present; Qt falls back glyph by glyph
    return font


def render_text(text: str, fontsize: float, color="#000000", fontfile: str | None = None,
                opacity: float = 1.0, angle: float = 0.0, scale: float = 4.0) -> LoadedImage:
    """Draw one line of text with correct shaping into a transparent PNG.
    ``scale`` = pixels per PDF point (4 = 288 dpi, crisp when printed).
    Returns the picture; its size in PDF points is width/scale x height/scale."""
    text = " ".join(text.split())
    if not text:
        raise ImageError("no text to draw")
    font = _resolve_font(text, fontfile)
    font.setPixelSize(max(4, int(round(fontsize * scale))))
    font.setStyleStrategy(QFont.PreferAntialias)
    fm = QFontMetricsF(font)
    pad = fontsize * scale * 0.2
    w = math.ceil(fm.horizontalAdvance(text) + 2 * pad)
    h = math.ceil(fm.ascent() + fm.descent() + 2 * pad)
    img = QImage(w, h, QImage.Format_ARGB32)
    img.fill(0)
    p = QPainter(img)
    p.setRenderHints(QPainter.Antialiasing | QPainter.TextAntialiasing | QPainter.SmoothPixmapTransform)
    p.setFont(font)
    p.setPen(QColor(color))
    p.setOpacity(max(0.0, min(1.0, opacity)))
    p.drawText(QPointF(pad, pad + fm.ascent()), text)
    p.end()
    if angle:
        img = img.transformed(QTransform().rotate(-angle), Qt.SmoothTransformation)
    return LoadedImage(_encode(img, "PNG"), img.width(), img.height(), True)
