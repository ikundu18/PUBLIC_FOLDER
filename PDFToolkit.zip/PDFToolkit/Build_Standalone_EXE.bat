@echo off
setlocal
cd /d "%~dp0"
rem Builds dist\PDFToolkit\PDFToolkit.exe - a folder you can copy to any Windows PC (no Python needed there).
if not exist ".venv\Scripts\python.exe" (
  py -3 -m venv .venv || python -m venv .venv
  ".venv\Scripts\python.exe" -m pip install -r requirements.txt
)
".venv\Scripts\python.exe" -m pip install pyinstaller || goto :fail
".venv\Scripts\python.exe" -m PyInstaller --noconfirm --windowed --name PDFToolkit --collect-all pymupdf --collect-all pyhanko --collect-all pyhanko_certvalidator --collect-all tzdata --add-data "tessdata;tessdata" main.py || goto :fail
echo.
echo Done:  dist\PDFToolkit\PDFToolkit.exe
pause
exit /b 0
:fail
echo Build failed.
pause
exit /b 1
