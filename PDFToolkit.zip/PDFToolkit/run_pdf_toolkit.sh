#!/usr/bin/env bash
# Double-click (Linux) or run in Terminal (macOS):  ./run_pdf_toolkit.sh
cd "$(dirname "$0")" || exit 1
PY=$(command -v python3 || command -v python)
if [ -z "$PY" ]; then echo "Python 3.9+ not found. Install it from https://www.python.org/downloads/"; exit 1; fi
if [ ! -x ".venv/bin/python" ]; then
  echo "First run: installing required packages (needs internet, ~1 minute)..."
  "$PY" -m venv .venv && .venv/bin/python -m pip install --upgrade pip >/dev/null \
    && .venv/bin/python -m pip install -r requirements.txt || { echo "Setup failed."; rm -rf .venv; exit 1; }
fi
exec .venv/bin/python main.py "$@"
