#!/usr/bin/env bash
# Double-click (Linux) or run in Terminal (macOS):  ./run_pdf_toolkit.sh
cd "$(dirname "$0")" || exit 1
PY=$(command -v python3 || command -v python)
if [ -z "$PY" ]; then echo "Python not found. Install Python 3.12 from https://www.python.org/downloads/"; exit 1; fi
# prefer 3.12 / 3.13 / 3.11 / 3.10 when several are installed
for v in 3.12 3.13 3.11 3.10; do command -v python$v >/dev/null 2>&1 && { PY=$(command -v python$v); break; }; done
if ! "$PY" -c 'import sys; sys.exit(0 if sys.version_info[:2]>=(3,9) else 1)'; then
  echo "This program needs Python 3.9 or newer. Yours is: $("$PY" --version)"
  echo "Install Python 3.12 from https://www.python.org/downloads/ and try again."; exit 1
fi
if [ ! -x ".venv/bin/python" ]; then
  echo "First run: installing PyMuPDF and PySide6 (about 330 MB, needs internet, a few minutes)..."
  "$PY" -m venv .venv && .venv/bin/python -m pip install --upgrade pip >/dev/null 2>&1 \
    && .venv/bin/python -m pip install -r requirements.txt \
    || { echo "Setup failed. Check your internet connection and try again."; rm -rf .venv; exit 1; }
fi
.venv/bin/python -c "import pyhanko, tzdata" 2>/dev/null || { echo "Installing newly added packages (digital signatures)..."; .venv/bin/python -m pip install -r requirements.txt; }
exec .venv/bin/python main.py "$@"
